#!/bin/bash
# FilterBox — firstboot retry watchdog.
# Re-runs the first-boot automation when a previous attempt crashed or failed
# (completion marker absent). Never permanent: the attempt cap is a 24-hour
# budget, after which the watchdog resumes — a box that stays broken (or is
# fixed weeks later) must always get another chance, without SSH.
set -u
MARK=/root/filterbox-firstboot.marker
PART=/root/filterbox-firstboot.partial
CNT=/root/.fb-firstboot-retry-count
WIN=/root/.fb-firstboot-retry-window
SCRIPT=/boot/Automation_Custom_Script.sh
MAX=12
WINDOW=86400

[ -f /etc/filterbox/needs-setup ] && exit 0     # factory-reset box waits for the customer
# The customer already set a password / completed setup: never re-run finalize.
[ -f /etc/filterbox/wizard-done ] && exit 0
[ -s /etc/filterbox/panel-ftl.secret ] && exit 0
grep -q '"password_set"[[:space:]]*:[[:space:]]*true' /etc/filterbox/wizard-state.json 2>/dev/null && exit 0
[ -s "$MARK" ] && grep -q 'firstboot completed' "$MARK" 2>/dev/null && { rm -f "$PART" "$CNT" "$WIN"; exit 0; }
# An empty/truncated marker is not success: a power cut during the marker write
# used to look 'done' forever. Remove it and re-run.
[ -f "$MARK" ] && { echo "retry: empty/partial marker found — treating as not done"; rm -f "$MARK"; }
[ -f "$SCRIPT" ] || { echo "retry: automation script missing at $SCRIPT"; exit 0; }

now=$(date +%s)
# freshness: don't touch a run that may still be active. A FUTURE mtime (clock
# was ahead, then NTP stepped back) must be treated as stale, never as fresh —
# otherwise every tick skips until the wall clock reaches that date.
fresh=0
if [ -f "$PART" ]; then
  mt=$(stat -c %Y "$PART" 2>/dev/null || echo 0)
  case "$mt" in ''|*[!0-9]*) mt=0 ;; esac
  if [ "$mt" -le $((now + 300)) ] && [ $((now - mt)) -lt 600 ]; then fresh=1; fi
fi
if [ "$fresh" = "1" ]; then
  echo "retry: partial marker is fresh — an attempt may be running; skipping"
  exit 0
fi
# A lost partial must not disable recovery: recreate it only after the freshness
# decision (recreating first made every missing-partial tick skip as 'fresh').
if ! { [ -f "$PART" ] || echo "partial recovered $(date -Is)" > "$PART" 2>/dev/null; }; then
  echo "retry: cannot write partial marker — continuing anyway"
fi
# A live firstboot run releases the flock by design; use its pid file too, or the
# retry burns an attempt every 30 min while the run is merely slow.
if [ -f /run/filterbox-firstboot.pid ]; then
  OPID="$(cat /run/filterbox-firstboot.pid 2>/dev/null || true)"
  case "$OPID" in ''|*[!0-9]*) OPID=0 ;; esac
  if [ "$OPID" -gt 1 ] && kill -0 "$OPID" 2>/dev/null; then
    echo "retry: firstboot pid $OPID is alive — skipping without counting"
    exit 0
  fi
fi

# Do not charge an attempt when another run holds the lock (slow REPAIRs used to
# burn the whole daily budget on no-op ticks).
if exec 8>/run/filterbox-firstboot.lock 2>/dev/null; then
  if ! flock -n 8; then echo "retry: firstboot is active — skipping without counting"; exit 0; fi
  exec 8>&-
fi

start=$(cat "$WIN" 2>/dev/null || echo 0)
n=$(cat "$CNT" 2>/dev/null || echo 0)
n=$(printf '%s' "$n" | tr -cd '0-9'); [ -n "$n" ] || n=0
start=$(printf '%s' "$start" | tr -cd '0-9'); [ -n "$start" ] || start=0
# Initialise the window on first use. The old code clamped start to now but never
# wrote it, so after 12 attempts the budget could never expire (permanent stop).
if [ "$start" -eq 0 ] || [ "$start" -gt "$now" ] || [ "$start" -lt $((now - 30*86400)) ]; then
  start=$now
  printf '%s\n' "$start" > "$WIN" 2>/dev/null || start=0
fi
if [ "$n" -ge "$MAX" ]; then
  if [ "$start" -gt 0 ] && [ $((now - start)) -lt "$WINDOW" ]; then
    echo "retry: $n attempts used in this 24 h window — next attempt after the window"
    exit 0
  fi
  n=0; start=$now; printf '%s\n' "$start" > "$WIN" 2>/dev/null || true
fi
n=$((n + 1)); echo "$n" > "$CNT"
echo "retry: attempt $n/$MAX (window started $(date -Is -d "@$(cat "$WIN" 2>/dev/null || echo "$now")")) — re-running $SCRIPT"
# NOTE: no flock here on purpose — the automation script holds (and enforces) the
# single-instance lock itself; taking it here too would make the automation see the
# lock as busy (the fd is inherited across exec) and silently do nothing.
exec /usr/bin/bash "$SCRIPT"
