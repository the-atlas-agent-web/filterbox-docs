#!/usr/bin/env python3
"""fb-reset-button.py — physical control of the box (NanoPi RESET/RECOVERY key).

R3S-LTS: the case RESET button is a gpio-keys key (KEY_RESTART, code 408).
Zero2:   RESET is a hard reset line (no key event); the usable key is RECOVERY,
         wired to the SARADC as `adc-keys` — mainline DT maps it to KEY_VENDOR
         (355), FriendlyElec's vendor DT maps it to KEY_VOLUMEUP (115).

Behaviour (any configured key):

    short press (release before 5 s)  -> reboot the box
    hold >= 5 s                       -> factory reset, then reboot

Physical presence is the authorization: there is no unauthenticated reset
endpoint on the network. The reset itself lives in fb-factory-reset.sh, shared
with the password-authenticated dashboard action.

Override the accepted key codes with FB_RESET_KEY_CODES="408,355,115".

Stdlib only — the image has no evdev package.
"""
import fcntl
import glob
import os
import select
import struct
import subprocess
import sys
import time

EV_KEY = 1
KEY_RESTART = 408      # R3S-LTS RESET key
KEY_VENDOR = 355       # Zero2 RECOVERY (mainline DT)
KEY_VOLUMEUP = 115     # Zero2 RECOVERY (FriendlyElec vendor DT)
KEY_CODES = {int(c) for c in os.environ.get(
    'FB_RESET_KEY_CODES', f'{KEY_RESTART},{KEY_VENDOR},{KEY_VOLUMEUP}').split(',') if c.strip().isdigit()}
HOLD_SECONDS = float(os.environ.get('FB_RESET_HOLD_SECONDS', '5'))
INPUT_GLOB = os.environ.get('FB_INPUT_GLOB', '/dev/input/event*')
DEV_NAME_HINTS = tuple(s for s in os.environ.get(
    'FB_RESET_DEV_NAMES', 'gpio,adc,reset,key').split(',') if s)
EV_FMT = 'llHHi'
EV_SIZE = struct.calcsize(EV_FMT)
EVIOCGNAME = 0x81004506          # _IOC(_IOC_READ, 'E', 0x06, 256)

FB_LIB = os.path.dirname(os.path.abspath(__file__))
RESET_SCRIPT = os.environ.get('FB_RESET_SCRIPT', os.path.join(FB_LIB, 'fb-factory-reset.sh'))
LOG = os.environ.get('FB_RESET_BUTTON_LOG', '/var/log/filterbox/reset-button.log')


def log(msg):
    line = '%s %s\n' % (time.strftime('%Y-%m-%dT%H:%M:%S'), msg)
    try:
        os.makedirs(os.path.dirname(LOG), exist_ok=True)
        with open(LOG, 'a') as f:
            f.write(line)
    except Exception:
        pass
    sys.stderr.write(line)


def device_name(fd):
    try:
        return fcntl.ioctl(fd, EVIOCGNAME, b'\x00' * 256).split(b'\x00', 1)[0].decode('utf-8', 'replace')
    except Exception:
        return ''


def candidates():
    out = []
    for path in sorted(glob.glob(INPUT_GLOB)):
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
        except Exception:
            continue
        name = device_name(fd)
        out.append((path, fd, name))
    return out


def run(cmd):
    log('exec: ' + ' '.join(cmd))
    try:
        return subprocess.call(cmd, timeout=180)
    except Exception as e:
        log('exec failed: %s' % e)
        return 1


def do_reboot():
    log('short press — rebooting')
    run(['systemctl', 'reboot'])


def do_factory_reset():
    log('long press — factory reset')
    rc = run([RESET_SCRIPT, '--reason', 'button'])
    log('factory reset rc=%d — rebooting' % rc)
    run(['systemctl', 'reboot'])


def watch(devices):
    """Block on all candidate fds; track KEY_RESTART press duration."""
    pressed_at = None
    while True:
        try:
            ready, _, _ = select.select([fd for _, fd, _ in devices], [], [], 1.0)
        except Exception:
            return
        now = time.monotonic()
        # A hold that crosses the threshold fires without waiting for release.
        if pressed_at is not None and now - pressed_at >= HOLD_SECONDS:
            pressed_at = None
            do_factory_reset()
            return
        for fd in ready:
            try:
                data = os.read(fd, EV_SIZE * 64)
            except Exception:
                continue
            for off in range(0, len(data) - EV_SIZE + 1, EV_SIZE):
                _, _, etype, code, value = struct.unpack(EV_FMT, data[off:off + EV_SIZE])
                if etype != EV_KEY or code not in KEY_CODES:
                    continue
                if value == 1:                 # key down
                    pressed_at = time.monotonic()
                    log('RESET key down (code %d)' % code)
                elif value == 0 and pressed_at is not None:   # key up
                    held = time.monotonic() - pressed_at
                    pressed_at = None
                    log('RESET key up after %.1fs (code %d)' % (held, code))
                    if held < HOLD_SECONDS:
                        do_reboot()
                        return


def main():
    if '--simulate' in sys.argv:
        mode = sys.argv[sys.argv.index('--simulate') + 1] if len(sys.argv) > sys.argv.index('--simulate') + 1 else ''
        if mode == 'short':
            do_reboot()
        elif mode == 'long':
            do_factory_reset()
        else:
            print('usage: --simulate short|long')
            return 2
        return 0

    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    while True:
        devs = candidates()
        log('scan: ' + ', '.join('%s(%s)' % (p, n or '?') for p, _, n in devs))
        # gpio-keys (R3S RESET) or adc-keys (Zero2 RECOVERY) — keep any key device.
        picked = [(p, fd, n) for p, fd, n in devs
                  if not DEV_NAME_HINTS or any(h in n.lower() for h in DEV_NAME_HINTS)]
        for p, fd, n in devs:
            if (p, fd, n) not in picked:
                os.close(fd)
        if not picked:
            log('no key device found — rescanning in 60 s')
            time.sleep(60)
            continue
        log('watching: ' + ', '.join('%s(%s)' % (p, n or '?') for p, _, n in picked))
        try:
            watch(picked)
        finally:
            for _, fd, _ in picked:
                try:
                    os.close(fd)
                except Exception:
                    pass
        time.sleep(5)      # device vanished / reset reboot did not happen: rescan


if __name__ == '__main__':
    sys.exit(main())
