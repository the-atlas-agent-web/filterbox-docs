#!/bin/bash
# Complete an interrupted factory reset before the panel can serve setup.
# Runs before the panel, independently of FTL's start ordering, and retries every
# 5 minutes while `resetting` exists (a failed seed must not leave the previous
# owner's password valid on :8089 until the next reboot).
set -u
[ -f /etc/filterbox/resetting ] || exit 0
echo "completing factory reset (boot)"
rm -f /etc/filterbox/wizard-done
: > /etc/filterbox/needs-setup 2>/dev/null || true

# Credential commands need the FTL config daemon; start it without blocking on a
# full boot (systemctl may be absent in chroot tests).
systemctl start pihole-FTL >/dev/null 2>&1 || true
for _ in $(seq 1 20); do systemctl is-active --quiet pihole-FTL && break; sleep 1; done

fail() {
  echo "ERROR: $* — keeping resetting and blocking the FTL web UI"
  # Fail closed: the old password may still be valid on :8089. The panel on :80
  # stays usable for setup; the timer retries and starts FTL when it succeeds.
  systemctl stop pihole-FTL >/dev/null 2>&1 || true
  exit 1
}

# App passwords and TOTP survive SetWebPassword; clear them or the old owner
# keeps access / the new owner hits a TOTP prompt the panel cannot answer.
for kv in 'webserver.api.app_pwhash|' 'webserver.api.totp_secret|' 'webserver.api.app_sudo|false'; do
  k="${kv%%|*}"; v="${kv#*|}"
  pihole-FTL --config "$k" "$v" >/dev/null 2>&1 || fail "cannot clear $k"
done

before_hash=$(pihole-FTL --config webserver.api.pwhash 2>/dev/null || true)
pihole setpassword "$(head -c 24 /dev/urandom | base64 | tr -d '/+=')" >/dev/null 2>&1 || fail "password seed failed"
after_hash=$(pihole-FTL --config webserver.api.pwhash 2>/dev/null || true)
[ -n "$before_hash" ] && [ "$before_hash" = "$after_hash" ] && fail "password hash unchanged"

# Delete the stats DB only after FTL has stopped; unlinking it while FTL holds it
# open left the previous owner's query history visible in the advanced view.
systemctl stop pihole-FTL >/dev/null 2>&1 || true
rm -f /etc/filterbox/panel-ftl.secret \
      /etc/filterbox/wizard-state.json \
      /etc/pihole/pihole-FTL.db \
      /etc/pihole/pihole-FTL.db-wal \
      /etc/pihole/pihole-FTL.db-shm
systemctl start pihole-FTL >/dev/null 2>&1 || true
rm -f /etc/filterbox/resetting
# needs-setup stays: firstboot/retry must never finalize a reset box.
exit 0
