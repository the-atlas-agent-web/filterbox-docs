#!/bin/bash
# fb-memguard.sh — contain pihole-FTL memory growth (FilterBox).
#
# Context: FTL v6 can accumulate anonymous memory over long uptimes under heavy
# query load (observed ~650 MiB of anon over 12 days in our own house; upstream
# has a history of exactly such bugfixes). A 1 GB appliance must never be
# endangered by this, so containment is layered:
#   - HARD (systemd drop-in pihole-FTL.service.d/99-filterbox-memory.conf):
#     MemoryMax + Restart=always — worst case only FTL recycles, never the box.
#   - SOFT (this script, fb-memguard.timer every 15 min): graceful restart of
#     FTL BEFORE the cap ever matters, at a quiet moment (~3 s DNS blip).
set -u
ANON_MAX_MB="${FTL_ANON_MAX_MB:-200}"   # recycle when FTL anonymous memory exceeds this
AGE_MAX_D="${FTL_MAX_AGE_DAYS:-45}"     # ...or when the process is older than this
LOG=/var/log/filterbox/memguard.log
mkdir -p /var/log/filterbox
[ -f /etc/filterbox/resetting ] && { echo "$(date -Is) factory reset pending — memguard idle" >> "$LOG"; exit 0; }

PID=$(pidof pihole-FTL 2>/dev/null | awk '{print $1}')
if [ -z "$PID" ]; then
  if [ -f /etc/filterbox/resetting ]; then
    echo "$(date -Is) FTL not running but a factory reset is pending — not starting it" >> "$LOG"
    exit 0
  fi
  echo "$(date -Is) FTL not running — starting it" >> "$LOG"
  systemctl start pihole-FTL 2>/dev/null || echo "$(date -Is) !! start failed" >> "$LOG"
  exit 0
fi

ANON_KB=$(awk '/^Pss_Anon:/{print $2}' "/proc/$PID/smaps_rollup" 2>/dev/null)
[ -n "${ANON_KB:-}" ] || ANON_KB=0
AGE_SEC=$(ps -o etimes= -p "$PID" 2>/dev/null | tr -d ' '); [ -n "${AGE_SEC:-}" ] || AGE_SEC=0
AGE_D=$(( AGE_SEC / 86400 ))

if [ "$ANON_KB" -gt $(( ANON_MAX_MB * 1024 )) ] || [ "$AGE_D" -ge "$AGE_MAX_D" ]; then
  echo "$(date -Is) recycling FTL: anon=$((ANON_KB/1024))MiB (max ${ANON_MAX_MB}) age=${AGE_D}d (max ${AGE_MAX_D})" >> "$LOG"
  systemctl restart pihole-FTL
  sleep 6
  NEW=$(pidof pihole-FTL 2>/dev/null | head -1)
  if [ -n "$NEW" ]; then
    NA=$(awk '/^Pss_Anon:/{print $2}' "/proc/$NEW/smaps_rollup" 2>/dev/null); [ -n "${NA:-}" ] || NA=0
    echo "$(date -Is) FTL restarted (pid $NEW, anon=$((NA/1024))MiB)" >> "$LOG"
  else
    echo "$(date -Is) !! FTL did not come back after restart" >> "$LOG"
  fi
fi
exit 0
