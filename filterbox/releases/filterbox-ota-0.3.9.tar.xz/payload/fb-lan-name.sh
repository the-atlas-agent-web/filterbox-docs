#!/bin/bash
# fb-lan-name.sh — keep a plain-DNS name for the panel that works everywhere.
#
# mDNS (.local) is invisible to Android and unreliable behind some antivirus
# suites, so the box also answers a normal DNS name. Because the box is the
# LAN's resolver, every client (phone, tablet, TV) can use it without any
# per-device configuration. The record follows DHCP changes.
set -u
NAME_MAIN="${FB_DNS_NAME:-filterbox.lan}"
NAME_ALT="${FB_DNS_ALT:-filterbox}"
INTERVAL="${FB_DNS_INTERVAL:-30}"

log() { echo "$(date -Is) $*"; }

current_ip() {
  ip -4 -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -1
}

publish() {  # ip
  local ip="$1" cur new
  cur="$(pihole-FTL --config dns.hosts 2>/dev/null || echo '[]')"
  new="$(python3 - "$cur" "$ip" "$NAME_MAIN" "$NAME_ALT" <<'PY'
import json, sys
cur_raw, ip, *names = sys.argv[1:5]
try:
    cur = json.loads(cur_raw or "[]")
except Exception:
    cur = []
# keep records the owner added, replace only ours
keep = [e for e in cur if e.split() and e.split()[-1] not in names]
print(json.dumps(keep + [f"{ip} {n}" for n in names]))
PY
)" || { log "could not build record list"; return 1; }
  pihole-FTL --config dns.hosts "$new" >/dev/null 2>&1 || { log "dns.hosts update failed"; return 1; }
  pihole reloaddns >/dev/null 2>&1 || systemctl reload-or-restart pihole-FTL >/dev/null 2>&1 || true
  log "published $NAME_MAIN and $NAME_ALT -> $ip"
}

LAST=""
log "LAN name publisher starting ($NAME_MAIN, $NAME_ALT)"
while :; do
  ip="$(current_ip)"
  if [ -z "$ip" ]; then
    log "no IPv4 yet — waiting"
  elif [ "$ip" != "$LAST" ]; then
    if publish "$ip"; then LAST="$ip"; fi
  fi
  sleep "$INTERVAL"
done
