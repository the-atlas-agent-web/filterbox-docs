#!/bin/bash
# FilterBox — publish a friendly LAN name (default: filterbox.local → this box).
# Keeps the record alive and follows IP changes (DHCP renewals, cable moves).
set -u
NAME="${FB_ALIAS_NAME:-filterbox.local}"
log() { echo "$(date -Is) $*"; }
log "alias publisher starting for $NAME"
while :; do
  ip="$(ip -4 -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -1)"
  if [ -z "$ip" ]; then log "no IPv4 yet — waiting"; sleep 5; continue; fi
  avahi-publish -a -R "$NAME" "$ip" >/dev/null 2>&1 &
  pid=$!
  log "published $NAME -> $ip (pid $pid)"
  while kill -0 "$pid" 2>/dev/null; do
    sleep 30
    newip="$(ip -4 -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -1)"
    if [ -n "$newip" ] && [ "$newip" != "$ip" ]; then
      log "IP changed $ip -> $newip — republishing"
      kill "$pid" 2>/dev/null || true
      break
    fi
  done
  sleep 2
done
