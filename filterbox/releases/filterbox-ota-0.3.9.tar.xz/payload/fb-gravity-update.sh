#!/bin/bash
# fb-gravity-update — safe blocklist update with a last-known-good restore.
#
# Upstream's swap drops the live tables before renaming the new DB in; a crash
# or a 200-OK HTML "list" can therefore leave the box with zero domains while
# DNS keeps working (unfiltered, silently). This wrapper snapshots a validated
# DB first and restores it when the update truly damaged the result.
#
# Concurrency: pihole -g itself has NO global lock (it shares gravity.db_temp),
# so every caller must hold /run/filterbox-gravity.lock. firstboot and the
# repair script acquire the same lock around their direct pihole -g calls.
set -u
DB=/etc/pihole/gravity.db
BAK=/etc/pihole/gravity.lastgood.db
LOCK=/run/filterbox-gravity.lock
STATE=/run/filterbox/gravity-last.json
MIN=100000

mkdir -p /run/filterbox /var/log/filterbox 2>/dev/null || true
# A pending factory reset owns FTL credentials. Do not rebuild/restart FTL here:
# a restart would make the previous owner's old password valid again.
[ -f /etc/filterbox/resetting ] && { echo "factory reset pending — gravity update skipped"; exit 0; }
exec 9>"$LOCK" || exit 1
flock -n 9 || { echo "gravity update already running"; exit 0; }
export FB_GRAVITY_LOCK_HELD=1

count() { pihole-FTL sqlite3 "$1" 'SELECT COUNT(*) FROM gravity;' 2>/dev/null || echo 0; }
effective() { pihole-FTL sqlite3 "$1" 'SELECT COUNT(*) FROM vw_gravity;' 2>/dev/null || echo 0; }
valid() {
  [ -f "$1" ] || return 1
  [ "$(count "$1")" -ge "$MIN" ] || return 1
  [ "$(pihole-FTL sqlite3 "$1" 'PRAGMA quick_check;' 2>/dev/null | head -1)" = "ok" ] || return 1
  # FTL blocks through vw_gravity. A DB can have 4M raw rows but 50k effective
  # rows (most lists disabled); finish() requires 100k effective, so treat that
  # as damaged here too or setup can never complete.
  [ "$(effective "$1")" -ge "$MIN" ]
}

before=$(count "$DB")
# A clock before the build date makes TLS/list downloads fail; report it instead
# of poisoning the DB (the timer retries later, e.g. when NTP recovers).
if [ "$(date +%Y)" -lt 2025 ]; then
  echo "ERROR: system clock is not set ($(date -Is)) — skipping update"
  exit 75
fi
snapshot_ok=0
before_lists=""
if valid "$DB"; then
  if cp -f "$DB" "$BAK.tmp" 2>/dev/null && mv -f "$BAK.tmp" "$BAK" 2>/dev/null; then
    snapshot_ok=1
    before_lists=$(pihole-FTL sqlite3 -separator '|' "$DB" \
      'SELECT address,number FROM adlist WHERE enabled=1;' 2>/dev/null || true)
    echo "snapshot: $before domains"
  else
    rm -f "$BAK.tmp"
    echo "WARN: snapshot failed — no restore point for this run"
  fi
else
  echo "WARN: current gravity is not valid ($before domains) — no snapshot"
fi

rc=0
pihole -g || rc=$?
after=$(count "$DB")
damaged=0
[ "${after:-0}" -lt "$MIN" ] && damaged=1
[ "$(effective "$DB")" -lt "$MIN" ] && damaged=1

# A single major list can collapse (HTML/captive page accepted as 200 OK) while
# the total stays above MIN. Compare per-list counts with the snapshot.
collapsed_lists=""
if [ -n "$before_lists" ]; then
  after_lists=$(pihole-FTL sqlite3 -separator '|' "$DB" \
    'SELECT address,number FROM adlist WHERE enabled=1;' 2>/dev/null || true)
  while IFS='|' read -r addr num; do
    [ -n "${addr:-}" ] || continue
    [ "${num:-0}" -ge 10000 ] 2>/dev/null || continue
    new=$(printf '%s\n' "$after_lists" | awk -F'|' -v a="$addr" '$1==a{print $2; exit}')
    if [ -n "$new" ] && [ "$new" -lt $((num / 10)) ] 2>/dev/null; then
      echo "COLLAPSED: $addr $num -> $new"
      damaged=1
      collapsed_lists="$collapsed_lists$addr"$'\n'
    fi
  done <<< "$before_lists"
fi

# Restore only when the DB is actually damaged. A failed download leaves the live
# DB untouched; restoring then would roll back a perfectly good DB (and reset
# its mtime).
if [ "$damaged" = 1 ] && [ "$snapshot_ok" = 1 ] && valid "$BAK"; then
  echo "damaged DB ($after domains) — restoring last-known-good atomically"
  if cp -f "$BAK" "$DB.tmp" 2>/dev/null && valid "$DB.tmp"; then
    chown pihole:pihole "$DB.tmp" 2>/dev/null || true
    if ! mv -f "$DB.tmp" "$DB"; then
      echo "ERROR: restore rename failed"
      rm -f "$DB.tmp"
      rc=1
    fi
  else
    echo "ERROR: last-known-good copy failed verification"
    rm -f "$DB.tmp"
    rc=1
  fi
  after=$(count "$DB")
  pihole reloaddns >/dev/null 2>&1 || systemctl restart pihole-FTL >/dev/null 2>&1 || true
  # Quarantine a list that legitimately shrank >90%: disable it so the next run
  # is not permanently rolled back. Support can re-enable after checking.
  if [ -n "$collapsed_lists" ]; then
    while IFS= read -r addr; do
      [ -n "$addr" ] || continue
      pihole-FTL sqlite3 "$DB" "UPDATE adlist SET enabled=0 WHERE address='$addr';" 2>/dev/null || true
      echo "QUARANTINED list (enabled=0): $addr"
    done <<< "$collapsed_lists"
  fi
elif [ "$damaged" = 1 ]; then
  echo "ERROR: DB damaged and no valid last-known-good copy — filtering is degraded"
  rc=1
elif [ "$rc" -ne 0 ]; then
  echo "update failed rc=$rc but the live DB is intact ($after domains) — keeping it"
fi

if valid "$DB"; then rc=0; else rc=1; fi
printf '{"ts": %s, "before": %s, "after": %s, "rc": %s}\n' \
  "$(date +%s)" "${before:-0}" "${after:-0}" "$rc" > "$STATE.tmp" 2>/dev/null \
  && mv -f "$STATE.tmp" "$STATE" 2>/dev/null || true
exit "$rc"
