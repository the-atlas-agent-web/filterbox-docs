#!/bin/bash
# FilterBox — setup finisher. Spawned detached by fb-panel.py after /api/finish.
# Panel era: the panel owns :80 in BOTH modes (no port handover). This script:
#   1) retires any legacy wizard unit (boxes updated in place from the old build)
#   2) ensures the engine (pihole-FTL) is active on its side port
#   3) verifies the panel is serving, and logs the result
# The panel's FTL credential copy is written when the password is established
# (image seed, wizard set-password, panel login refresh, panel password change).
set -u
LOG=/var/log/filterbox/wizard-finish.log
mkdir -p /var/log/filterbox 2>/dev/null || true
exec >>"$LOG" 2>&1
echo "=== finisher $(date -Is) ==="
sleep 2   # give the HTTP response time to flush to the browser

# 1) legacy wizard unit cleanup (no-op when absent)
if systemctl list-unit-files 2>/dev/null | grep -q '^fb-wizard\.service'; then
  systemctl disable --now fb-wizard.service 2>/dev/null || true
  echo "legacy fb-wizard.service retired"
fi

# 2) engine must be up (the dashboard's data source, on its side port)
if ! systemctl is-active pihole-FTL >/dev/null 2>&1; then
  systemctl start pihole-FTL.service 2>/dev/null || true
  for i in 1 2 3 4 5; do
    systemctl is-active pihole-FTL >/dev/null 2>&1 && break
    sleep 2
  done
fi
echo "pihole-FTL active: $(systemctl is-active pihole-FTL 2>/dev/null || echo unknown)"

# 3) verify the panel serves on :80 (same process kept :80 through the switch)
P="${FB_PANEL_PORT:-80}"
DASH_OK=0
for i in 1 2 3 4 5 6; do
  if curl -fsS --max-time 3 "http://127.0.0.1:$P/api/health" >/dev/null 2>&1; then DASH_OK=1; break; fi
  sleep 2
done
if [ "$DASH_OK" = 1 ]; then
  echo ":80 serves the panel (health OK)"
else
  echo "WARN: panel health check failed on :$P — firstboot/repair will re-check"
fi
echo "=== finisher done $(date -Is) ==="
