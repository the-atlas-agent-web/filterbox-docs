#!/bin/bash
# fb-netwatch — keep the filterbox.local DNS record pointed at the live LAN IP.
# The record used to be written only at firstboot; a DHCP lease change left it
# stale (or pointing at another device), and Android has no mDNS fallback.
set -u
LIST=/etc/pihole/hosts/custom.list

# Use the interface that carries the default route, and its LAN address — the
# route-to-1.1.1.1 'src' can be a WAN/VPN address that LAN clients cannot reach.
IFACE=$(ip route show default 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | head -n1)
IP=""
if [ -n "$IFACE" ]; then
  IP=$(ip -4 -o addr show dev "$IFACE" scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -n1)
fi
[ -n "$IP" ] || IP=$(ip route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}')
[ -n "$IP" ] || exit 0

mkdir -p /etc/pihole/hosts 2>/dev/null || true
[ -f "$LIST" ] || : > "$LIST" 2>/dev/null || exit 0

# Rewrite ALL filterbox.local lines (case-insensitive, duplicates included) into
# a temp file first; only touch the real file when the content actually changes.
TMP=$(mktemp /etc/pihole/hosts/.fbnet.XXXXXX 2>/dev/null) || exit 0
grep -vi '[[:space:]]filterbox\.local[[:space:]]*$' "$LIST" > "$TMP" 2>/dev/null || : > "$TMP"
echo "$IP filterbox.local" >> "$TMP"
if cmp -s "$TMP" "$LIST"; then
  rm -f "$TMP"
  exit 0
fi
if ! mv -f "$TMP" "$LIST" 2>/dev/null; then
  rm -f "$TMP"
  logger -t fb-netwatch "cannot update $LIST (read-only/full?)" 2>/dev/null || true
  exit 1
fi
chown pihole:pihole "$LIST" 2>/dev/null || true
# FTL watches hostsdir via inotify; the reload is only needed to flush its cache.
pihole reloaddns >/dev/null 2>&1 || true
logger -t fb-netwatch "filterbox.local -> $IP" 2>/dev/null || true
