#!/bin/bash
# fb-factory-reset.sh — single source of truth for a factory reset.
#
# Clears ownership (dashboard password, app passwords, TOTP, claim state) and
# statistics. KEEPS filtering running, blocklists, and Wi-Fi credentials.
# Called by the panel (password-authenticated) and by the physical RESET button
# (5-second hold — physical presence is the authorization).
#
# Ordering invariants (learned in the reset audits):
#   1. reset/needs-setup markers are written ATOMICALLY before consent is removed,
#      so a power cut never leaves the previous owner's password valid;
#   2. credentials are cleared BEFORE the slow FTL stop;
#   3. the stats DB is deleted only while FTL is stopped;
#   4. the blocklists and coverage engine are never touched — the box keeps
#      filtering through a reset (fail-open principle applies to crashes, not
#      to an explicit handover).
set -u
LOG=/var/log/filterbox/factory-reset.log
mkdir -p /var/log/filterbox 2>/dev/null || true
exec >>"$LOG" 2>&1
echo "=== factory reset $(date -Is) reason=${1:-unknown} ==="

FB=/etc/filterbox
DONE=$FB/wizard-done
RESETTING=$FB/resetting
NEEDS=$FB/needs-setup
LOCK=/run/filterbox-reset.lock

fail() { echo "ERROR: $*"; exit 1; }
# Credential failures must fail CLOSED: leaving FTL up with the previous owner's
# password is worse than an outage. The boot-time reset-finish timer retries.
fail_closed() { echo "ERROR: $* — stopping FTL (fail closed)"; systemctl stop pihole-FTL >/dev/null 2>&1 || true; exit 1; }

# One reset at a time (a stuck button must not stack resets).
exec 9>"$LOCK"
flock -n 9 || { echo "another reset holds the lock — exiting"; exit 0; }

# 1) markers first (atomic: tmp + fsync + rename)
token="$(head -c 16 /dev/urandom | od -An -tx1 | tr -d ' \n')"
for p in "$RESETTING" "$NEEDS"; do
  printf '%s\n' "$token" > "$p.tmp" || fail "cannot write $p.tmp"
  sync
  mv -f "$p.tmp" "$p" || fail "cannot publish $p"
done

# 2) withdraw the dashboard claim
rm -f "$DONE" || true
[ -e "$DONE" ] && fail "cannot remove claim marker"

# FTL must be answering for setpassword/config (the button may fire while it is down).
systemctl start pihole-FTL >/dev/null 2>&1 || true
for _ in $(seq 1 20); do systemctl is-active --quiet pihole-FTL && break; sleep 1; done

# 3) FTL credentials — app passwords and TOTP survive `pihole setpassword`
for kv in 'webserver.api.app_pwhash|' 'webserver.api.totp_secret|' 'webserver.api.app_sudo|false'; do
  k="${kv%%|*}"; v="${kv#*|}"
  pihole-FTL --config "$k" "$v" >/dev/null 2>&1 || fail_closed "cannot clear $k"
done
before_hash="$(pihole-FTL --config webserver.api.pwhash 2>/dev/null || true)"
pihole setpassword "$(head -c 24 /dev/urandom | base64 | tr -d '/+=')" >/dev/null 2>&1 \
  || fail_closed "password seed failed"
after_hash="$(pihole-FTL --config webserver.api.pwhash 2>/dev/null || true)"
[ -n "$before_hash" ] && [ "$before_hash" = "$after_hash" ] && fail_closed "password hash unchanged"

# 4) ownership files (Wi-Fi credentials are deliberately kept: a Wi-Fi-only box
#    has no AP fallback, so deleting them would brick claiming forever).
rm -f "$FB/wizard-state.json" "$FB/panel-ftl.secret" "$FB/web-password.initial"

# 5) handover hygiene: re-enable quarantined lists, drop panel-added domains
pihole-FTL sqlite3 /etc/pihole/gravity.db \
  "UPDATE adlist SET enabled=1; DELETE FROM domainlist WHERE comment LIKE 'fb-panel:%';" \
  >/dev/null 2>&1 || echo "WARN: gravity cleanup skipped"

# 6) statistics (privacy for resale): delete only while FTL is stopped
systemctl stop pihole-FTL >/dev/null 2>&1 || true
rm -f /etc/pihole/pihole-FTL.db /etc/pihole/pihole-FTL.db-wal /etc/pihole/pihole-FTL.db-shm
systemctl start pihole-FTL >/dev/null 2>&1 || true

# 7) reset complete (not interrupted). needs-setup stays until the new owner
#    claims the dashboard; the claim page is served in the meantime.
rm -f "$RESETTING"
echo "reset complete — filtering continues, dashboard unclaimed"
exit 0
