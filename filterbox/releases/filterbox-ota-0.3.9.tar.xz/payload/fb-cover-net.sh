#!/bin/bash
# fb-cover-net.sh — netfilter half of the FilterBox coverage engine.
#
# apply:  enable forwarding + capture :53 (REDIRECT to local FTL), drop :853 (DoT),
#         block known DoH endpoint IPs; NOTRACK forwarded non-DNS traffic.
# remove: take all of it back out; VERIFIED (returns non-zero while anything remains).
# verify: exit 0 only if the full capture ruleset is installed and forwarding is on.
#
# No NAT/SNAT anywhere: the router keeps doing its own NAT; only DNS is touched.
# Rules are scoped to the LAN interface; packets addressed to the box itself are
# never NOTRACKed (so host firewalls/servicing keep working).

set -u
DOH_FILE="${FB_COVER_DOH_FILE:-/etc/filterbox/doh-ips.txt}"
DOH_PORT="${FB_COVER_DOH_PORT:-443}"
SYSBAK="${FB_COVER_RUN_DIR:-/run/fb-cover}/netsys.bak"

SAVED_IFACE=""
if [ -f "$SYSBAK" ]; then
  # shellcheck disable=SC1090
  . "$SYSBAK" 2>/dev/null || true
fi
LIVE_IFACE=$(ip route show default 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | head -n1)
# Apply/verify MUST follow the live LAN interface. SAVED_IFACE is only a
# fallback for removal when the default route has disappeared — pinning the
# interface to the first-ever value leaves a moved cable (eth0 -> eth1) with
# zero capture rules while the daemon still reports full.
IFACE="${FB_COVER_IFACE:-${LIVE_IFACE:-${SAVED_IFACE:-}}}"
[ -n "$IFACE" ] || { echo "fb-cover-net: no LAN interface" >&2; exit 2; }

fw() { iptables -w 5 "$@"; }

verify() {
  local ok=0
  fw -t nat -C PREROUTING -i "$IFACE" -j FBNAT 2>/dev/null || ok=1
  fw -t raw -C PREROUTING -i "$IFACE" -j FBRAW 2>/dev/null || ok=1
  fw -C FORWARD -i "$IFACE" -j FBFWD 2>/dev/null || ok=1
  fw -t nat -C FBNAT -p udp --dport 53 -j REDIRECT --to-ports 53 2>/dev/null || ok=1
  fw -t nat -C FBNAT -p tcp --dport 53 -j REDIRECT --to-ports 53 2>/dev/null || ok=1
  # encrypted-DNS blocking must still be in place, not just the jumps
  fw -t raw -C FBRAW -p udp --dport 53 -j RETURN 2>/dev/null || ok=1
  fw -t raw -C FBRAW -p tcp --dport 53 -j RETURN 2>/dev/null || ok=1
  fw -t raw -C FBRAW -p udp --dport 853 -j RETURN 2>/dev/null || ok=1
  fw -t raw -C FBRAW -p tcp --dport 853 -j RETURN 2>/dev/null || ok=1
  fw -t raw -C FBRAW -m addrtype ! --dst-type LOCAL -j CT --notrack 2>/dev/null || ok=1
  fw -C FBFWD -p udp --dport 853 -j DROP 2>/dev/null || ok=1
  fw -C FBFWD -p tcp --dport 853 -j DROP 2>/dev/null || ok=1
  fw -C FBFWD -j ACCEPT 2>/dev/null || ok=1
  # every valid DoH entry must still have both DROP rules (check per IP, not a count)
  local ip
  if [ -f "$DOH_FILE" ]; then
    while read -r line; do
      ip="${line%%#*}"; ip="${ip//[[:space:]]/}"
      [ -n "$ip" ] || continue
      valid_ipv4 "$ip" || continue
      fw -C FBFWD -d "$ip" -p tcp --dport "$DOH_PORT" -j DROP 2>/dev/null || ok=1
      fw -C FBFWD -d "$ip" -p udp --dport "$DOH_PORT" -j DROP 2>/dev/null || ok=1
    done < "$DOH_FILE"
  fi
  # the nat jump must be FIRST rule, or another PREROUTING rule can bypass capture
  # (-S prints the chain policy first, so look at the first -A line)
  fw -t nat -S PREROUTING 2>/dev/null | grep '^-A' | head -n1 | grep -q -- "-i $IFACE -j FBNAT" || ok=1
  # raw/filter ordering matters too: a foreign rule ahead of our jump can accept
  # or bypass traffic before DoT/DoH blocking is ever consulted.
  fw -t raw -S PREROUTING 2>/dev/null | grep '^-A' | head -n1 | grep -q -- "-i $IFACE -j FBRAW" || ok=1
  fw -S FORWARD 2>/dev/null | grep '^-A' | head -n1 | grep -q -- "-i $IFACE -j FBFWD" || ok=1
  [ "$(cat /proc/sys/net/ipv4/ip_forward 2>/dev/null)" = "1" ] || ok=1
  return $ok
}

_del_jumps() {  # table chain chainname — delete exact jump specs, any -i
  local t="$1" c="$2" n="$3" line ifc guard=0
  while [ $guard -lt 50 ]; do
    # Match the -j target anchored, then delete THAT exact spec (never by index:
    # an index can shift if another firewall manager changes rules concurrently).
    line=$(fw -t "$t" -S "$c" 2>/dev/null | grep -E -- "-j $n( |$)" | head -n1)
    [ -n "$line" ] || break
    ifc=$(printf '%s\n' "$line" | sed -n 's/.* -i \([^ ]*\).*/\1/p')
    if [ -n "$ifc" ]; then
      fw -t "$t" -D "$c" -i "$ifc" -j "$n" 2>/dev/null || {
        # A foreign manager may have added extra matches to our jump; delete the
        # whole spec exactly as printed instead of giving up (chain flushed empty
        # but jump left behind = permanent 'release incomplete').
        args=$(printf '%s\n' "$line" | sed -e 's/^-A [^ ]* //')
        # shellcheck disable=SC2086
        fw -t "$t" -D "$c" $args 2>/dev/null || break
      }
    else
      fw -t "$t" -D "$c" -j "$n" 2>/dev/null || break
    fi
    guard=$((guard+1))
  done
  return 0
}

_jump_left() {  # table chain chainname — 0 if a jump remains OR the ruleset is unreadable
  local t="$1" c="$2" n="$3" out rc
  out=$(fw -t "$t" -S "$c" 2>&1); rc=$?
  [ $rc -eq 0 ] || return 0          # cannot prove absence => report failure
  printf '%s\n' "$out" | grep -Eq -- "-j $n( |\$)" && return 0
  return 1
}

_doh_have() {  # number of installed DoH DROP rules for our port
  fw -S FBFWD 2>/dev/null | grep -Ec -- "--dport ${DOH_PORT} -j DROP" || true
}

_chain_empty() {  # table chain — true when absent or contains no rules
  ! fw -t "$1" -S "$2" 2>/dev/null | grep -q '^-A'
}

_flush_del() {  # table chain — flush; delete if empty (foreign refs are non-fatal)
  local t="$1" c="$2" rc
  fw -t "$t" -S "$c" >/dev/null 2>&1; rc=$?
  [ $rc -eq 1 ] && return 0          # chain absent
  if [ $rc -gt 1 ]; then bad=1; return 0; fi
  fw -t "$t" -F "$c" || bad=1
  if _chain_empty "$t" "$c"; then
    fw -t "$t" -X "$c" 2>/dev/null || \
      echo "fb-cover-net: note: $c still referenced by a foreign rule (empty, not filtering)" >&2
  else
    bad=1
  fi
}

remove() {
  local bad=0 rc
  _del_jumps nat PREROUTING FBNAT
  _del_jumps raw PREROUTING FBRAW
  _del_jumps filter FORWARD FBFWD
  # flush and delete the chains; a flush failure can leave REDIRECT live
  _flush_del nat FBNAT
  _flush_del raw FBRAW
  _flush_del filter FBFWD
  _jump_left nat PREROUTING FBNAT && bad=1
  _jump_left raw PREROUTING FBRAW && bad=1
  _jump_left filter FORWARD FBFWD && bad=1
  # ip_forward is deliberately NOT restored: a client that still resolves the
  # gateway to our MAC must keep working (unfiltered) until ARP/NUD heals.
  if [ -f "$SYSBAK" ]; then
    # shellcheck disable=SC1090
    . "$SYSBAK" 2>/dev/null || true
    [ -n "${OLD_RPF_ALL:-}" ] && sysctl -qw "net.ipv4.conf.all.rp_filter=$OLD_RPF_ALL" || true
    local rif="${SAVED_IFACE:-${IFACE}}"
    if [ -n "${OLD_RPF_IF:-}" ] && [ -e "/proc/sys/net/ipv4/conf/${rif}/rp_filter" ]; then
      sysctl -qw "net.ipv4.conf.${rif}.rp_filter=$OLD_RPF_IF" || true
    fi
    # Keep the backup while release is incomplete: next boot/retry still needs
    # SAVED_IFACE to find the interface after the default route is gone.
    [ $bad -eq 0 ] && rm -f "$SYSBAK"
  fi
  [ $bad -eq 0 ] || echo "fb-cover-net: remove incomplete" >&2
  return $bad
}

valid_ipv4() {
  local ip="$1" o
  case "$ip" in *[!0-9.]*|'') return 1 ;; esac
  [ "$(printf '%s' "$ip" | tr -cd '.' | wc -c)" = "3" ] || return 1
  IFS=. read -r a b c d <<<"$ip"
  for o in "$a" "$b" "$c" "$d"; do
    [ -n "$o" ] && [ "$o" -ge 0 ] 2>/dev/null && [ "$o" -le 255 ] 2>/dev/null || return 1
  done
  return 0
}

apply() {
  # Never apply onto a remembered interface: if the cable moved to another NIC,
  # rules on the old one capture nothing while the daemon reports full.
  if [ -z "${FB_COVER_IFACE:-}" ] && [ -z "$LIVE_IFACE" ]; then
    echo "fb-cover-net: no live LAN interface to apply on" >&2
    return 2
  fi
  mkdir -p "$(dirname "$SYSBAK")" 2>/dev/null || true
  if [ ! -f "$SYSBAK" ]; then
    {
      echo "OLD_IPF=$(cat /proc/sys/net/ipv4/ip_forward 2>/dev/null || echo 0)"
      echo "OLD_RPF_ALL=$(cat /proc/sys/net/ipv4/conf/all/rp_filter 2>/dev/null || echo 0)"
      echo "OLD_RPF_IF=$(cat "/proc/sys/net/ipv4/conf/${IFACE}/rp_filter" 2>/dev/null || echo 0)"
      echo "SAVED_IFACE=$IFACE"
    } > "$SYSBAK"
  else
    if grep -q '^SAVED_IFACE=' "$SYSBAK" 2>/dev/null; then
      sed -i "s|^SAVED_IFACE=.*|SAVED_IFACE=$IFACE|" "$SYSBAK" 2>/dev/null || true
    else
      echo "SAVED_IFACE=$IFACE" >> "$SYSBAK"
    fi
  fi
  sysctl -qw net.ipv4.ip_forward=1 || return 1
  sysctl -qw net.ipv4.conf.all.rp_filter=2 || return 1
  sysctl -qw "net.ipv4.conf.${IFACE}.rp_filter=2" || return 1

  # raw: NOTRACK forwarded traffic except DNS (53) and DoT (853); never touch
  # packets addressed to this host (LOCAL) — keeps conntrack usable for host services.
  fw -t raw -N FBRAW 2>/dev/null || true
  fw -t raw -F FBRAW || return 1
  _del_jumps raw PREROUTING FBRAW
  fw -t raw -I PREROUTING 1 -i "$IFACE" -j FBRAW || return 1
  fw -t raw -A FBRAW -p udp --dport 53 -j RETURN || return 1
  fw -t raw -A FBRAW -p tcp --dport 53 -j RETURN || return 1
  fw -t raw -A FBRAW -p udp --dport 853 -j RETURN || return 1
  fw -t raw -A FBRAW -p tcp --dport 853 -j RETURN || return 1
  fw -t raw -A FBRAW -m addrtype ! --dst-type LOCAL -j CT --notrack || return 1

  # nat: capture plain DNS — REDIRECT keeps the query's original destination
  # visible to the client (conntrack un-translation), so answers look normal.
  fw -t nat -N FBNAT 2>/dev/null || true
  fw -t nat -F FBNAT || return 1
  _del_jumps nat PREROUTING FBNAT
  fw -t nat -I PREROUTING 1 -i "$IFACE" -j FBNAT || return 1
  fw -t nat -A FBNAT -p udp --dport 53 -j REDIRECT --to-ports 53 || return 1
  fw -t nat -A FBNAT -p tcp --dport 53 -j REDIRECT --to-ports 53 || return 1

  # filter: block encrypted-DNS escapes on forwarded traffic, then ACCEPT the rest
  # (the appliance must not depend on the host's firewall policies).
  fw -N FBFWD 2>/dev/null || true
  fw -F FBFWD || return 1
  _del_jumps filter FORWARD FBFWD
  fw -I FORWARD 1 -i "$IFACE" -j FBFWD || return 1
  fw -A FBFWD -p udp --dport 853 -j DROP || return 1    # DoT
  fw -A FBFWD -p tcp --dport 853 -j DROP || return 1    # DoT
  if [ -f "$DOH_FILE" ]; then
    while read -r line; do
      ip="${line%%#*}"                # strip trailing comment
      ip="${ip//[[:space:]]/}"        # strip all whitespace
      [ -n "$ip" ] || continue
      if ! valid_ipv4 "$ip"; then
        echo "fb-cover-net: skipping invalid DoH entry: $ip" >&2
        continue
      fi
      fw -A FBFWD -d "$ip" -p tcp --dport "$DOH_PORT" -j DROP || return 1   # DoH
      fw -A FBFWD -d "$ip" -p udp --dport "$DOH_PORT" -j DROP || return 1   # DoH/QUIC
    done < "$DOH_FILE"
  fi
  fw -A FBFWD -j ACCEPT || return 1
  verify || { echo "fb-cover-net: apply verification failed" >&2; return 1; }
  return 0
}

status() {
  local have=0
  verify && have=1
  echo "{\"rules\": $have, \"iface\": \"$IFACE\"}"
  return 0
}

case "${1:-}" in
  apply)  apply ;;
  remove) remove ;;
  verify) verify ;;
  status) status ;;
  *) echo "usage: $0 apply|remove|verify|status" >&2; exit 2 ;;
esac
exit $?
