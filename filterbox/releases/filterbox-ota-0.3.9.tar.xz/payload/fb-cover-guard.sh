#!/bin/bash
# fb-cover-guard — independent failsafe (systemd timer, every ~20 s).
#
# If the coverage daemon is NOT active, this makes sure the LAN is not left
# pointing at us: send ARP corrections + remove the netfilter rules. Runs even
# if fb-cover crashed, was SIGKILLed, or failed to start.
# Idempotent; rate-limited to once per 30 s.

FB_COVER="${FB_COVER:-1}"
[ "$FB_COVER" = "0" ] && exit 0
DIR=/run/fb-cover
STAMP=$DIR/guard.stamp
mkdir -p "$DIR"

# 'activating' is a legitimate state (waiting for setup) — only act when the
# service is genuinely down.
st=$(systemctl is-active fb-cover.service 2>/dev/null || true)
case "$st" in
  active|activating|reloading) exit 0 ;;
esac

now=$(date +%s)
if [ -f "$STAMP" ]; then
  last=$(stat -c %Y "$STAMP" 2>/dev/null || echo 0)
  [ $((now - last)) -lt 30 ] && exit 0
fi
touch "$STAMP"

# Re-learn + correct from a fresh process; also strip rules no matter what.
python3 /usr/local/lib/filterbox/fb-cover.py --restore >/dev/null 2>&1
rrc=$?
# rc=4: a live daemon owns the lock (e.g. a manual run while systemd says
# inactive). Stripping its rules here would disable filtering mid-claim.
if [ "$rrc" = "4" ]; then
  logger -t fb-cover-guard "live daemon holds the lock — leaving its rules alone" 2>/dev/null || true
  exit 0
fi
/usr/local/lib/filterbox/fb-cover-net.sh remove >/dev/null 2>&1 || true
logger -t fb-cover-guard "fb-cover inactive — ran safety restore" 2>/dev/null || true
exit 0
