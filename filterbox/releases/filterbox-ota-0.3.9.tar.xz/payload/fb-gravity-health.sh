#!/bin/bash
# fb-gravity-health — periodic self-heal for the filtering data path.
# Restores a collapsed/corrupt gravity DB, un-wedges a crash-looping FTL, and
# restarts a hung panel. Takes the SAME global lock as the updater: restoring a
# DB while pihole -g is mid-swap was silently reverting completed updates.
set -u
# A pending factory reset owns FTL credentials and the stats DB. Health must not
# touch either: starting/restarting FTL here can make the old password valid.
[ -f /etc/filterbox/resetting ] && { echo "factory reset pending — health check skipped"; exit 0; }
DB=/etc/pihole/gravity.db
BAK=/etc/pihole/gravity.lastgood.db
MIN=100000
H=/run/filterbox/health.json
LOCK=/run/filterbox-gravity.lock

mkdir -p /run/filterbox 2>/dev/null || true
exec 9>"$LOCK" 2>/dev/null || true
if ! flock -n 9; then
  echo "gravity update in progress — health check skipped"
  exit 0
else
  export FB_GRAVITY_LOCK_HELD=1
  count() { pihole-FTL sqlite3 "$1" 'SELECT COUNT(*) FROM gravity;' 2>/dev/null || echo 0; }
  valid() {
    [ -f "$1" ] || return 1
    [ "$(count "$1")" -ge "$MIN" ] || return 1
    [ "$(pihole-FTL sqlite3 "$1" 'PRAGMA quick_check;' 2>/dev/null | head -1)" = "ok" ] || return 1
    [ "$(pihole-FTL sqlite3 "$1" 'SELECT COUNT(*) FROM vw_gravity;' 2>/dev/null || echo 0)" -ge "$MIN" ]
  }
  enabled_lists() { pihole-FTL sqlite3 "$DB" 'SELECT COUNT(*) FROM adlist WHERE enabled=1;' 2>/dev/null || echo 0; }
  effective() { pihole-FTL sqlite3 "$DB" 'SELECT COUNT(*) FROM vw_gravity;' 2>/dev/null || echo 0; }
  release_lock() { flock -u 9 2>/dev/null || true; exec 9>&- 2>/dev/null || true; }
  g=$(count "$DB")
  # All lists quarantined/disabled: the DB looks healthy by row count but blocks
  # nothing. Re-enable them, reload, and rebuild instead of restoring dead state.
  if [ "$g" -ge "$MIN" ] && [ "$(enabled_lists)" -eq 0 ]; then
    echo "all adlists disabled — re-enabling and rebuilding"
    pihole-FTL sqlite3 "$DB" 'UPDATE adlist SET enabled=1;' 2>/dev/null || true
    pihole reloaddns >/dev/null 2>&1 || true
    # Release OUR lock first: the updater takes the same lock and would otherwise
    # always no-op ("already running") and never rebuild.
    release_lock
    /usr/local/lib/filterbox/fb-gravity-update.sh || true
    g=$(count "$DB")
  fi
  # Require the failure to persist across a short re-read: a single sample taken
  # during the updater's DROP/mv window used to trigger a destructive restore.
  if ! valid "$DB"; then
    sleep 3
    g=$(count "$DB")
    if ! valid "$DB"; then
      echo "gravity invalid ($g domains) — self-heal"
      if valid "$BAK"; then
        if cp -f "$BAK" "$DB.tmp" 2>/dev/null && valid "$DB.tmp"; then
          chown pihole:pihole "$DB.tmp" 2>/dev/null || true
          mv -f "$DB.tmp" "$DB" || rm -f "$DB.tmp"
        else
          rm -f "$DB.tmp"
        fi
        pihole reloaddns >/dev/null 2>&1 || true
      else
        release_lock
        /usr/local/lib/filterbox/fb-gravity-update.sh || true
      fi
    fi
  fi
  flock -u 9 2>/dev/null || true
fi
g=$(pihole-FTL sqlite3 "$DB" 'SELECT COUNT(*) FROM vw_gravity;' 2>/dev/null || echo 0)

# FTL start limit: after 5 rapid failures systemd refuses to start it until
# reset-failed is called. Do that here so a transient crash can never become
# a permanent dead engine.
if ! systemctl is-active --quiet pihole-FTL; then
  if [ -f /etc/filterbox/resetting ]; then
    echo "factory reset pending — not starting FTL (old password must stay invalid)"
  else
    systemctl reset-failed pihole-FTL 2>/dev/null || true
    systemctl start pihole-FTL 2>/dev/null || true
  fi
fi

# Panel: bound but not serving is the dangerous state (user cannot finish setup).
panel=0
if ss -ltn 2>/dev/null | grep -qE '[:.]80\b' && \
   curl -fsS --max-time 3 -H 'Host: filterbox.local' http://127.0.0.1/ 2>/dev/null | grep -q 'FilterBox'; then
  panel=1
else
  systemctl reset-failed fb-panel.service 2>/dev/null || true
  systemctl restart fb-panel.service 2>/dev/null || true
  sleep 2
  if curl -fsS --max-time 3 -H 'Host: filterbox.local' http://127.0.0.1/ 2>/dev/null | grep -q 'FilterBox'; then panel=1; fi
fi

lists_age=-1
if [ -f "$DB" ]; then lists_age=$(( ($(date +%s) - $(stat -c %Y "$DB")) / 86400 )); fi
# Missed/failed weekly update? Retry every health tick until the DB is fresh.
if [ "$lists_age" -gt 8 ]; then
  echo "lists are ${lists_age}d old — running the update"
  /usr/local/lib/filterbox/fb-gravity-update.sh || true
  if [ -f "$DB" ]; then lists_age=$(( ($(date +%s) - $(stat -c %Y "$DB")) / 86400 )); fi
  g=$(pihole-FTL sqlite3 "$DB" 'SELECT COUNT(*) FROM vw_gravity;' 2>/dev/null || echo 0)
fi
printf '{"ts": %s, "ftl": %s, "panel": %s, "gravity": %s, "lists_age_days": %s}\n' \
  "$(date +%s)" "$(systemctl is-active --quiet pihole-FTL && echo true || echo false)" \
  "$([ "$panel" = 1 ] && echo true || echo false)" "${g:-0}" "$lists_age" > "$H.tmp" 2>/dev/null \
  && mv -f "$H.tmp" "$H" 2>/dev/null || true
