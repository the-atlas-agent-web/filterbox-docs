#!/usr/bin/env python3
"""fb-update — signed over-the-air updates for the FilterBox payload.

Payload only: our scripts, units, data and config assertions. OS, kernel and
Pi-hole packages are deliberately out of scope (those need a reflash or our own
signed .deb tier).

Security model
  * The trust anchor is an ed25519 signature over the manifest, verified with a
    public key baked into the image (/etc/filterbox/ota-pub.pem). TLS is only
    transport: a compromised CDN cannot push code.
  * The manifest pins the bundle's sha256; the bundle is verified before it is
    unpacked, and every tar member is validated (no absolute paths, no `..`,
    no symlinks/hardlinks, no device nodes).
  * Versions must increase. `revoked` in a manifest blocks a known-bad build.
  * Apply is atomic (tmp file + rename), keeps the previous release on disk and
    rolls back automatically when the health check fails.

Usage
  fb-update.py check      # fetch + verify manifest, report, change nothing
  fb-update.py apply      # fetch, verify, install, health check, rollback on fail
  fb-update.py status     # what is installed and when it last ran
  fb-update.py rollback   # go back to the previous release (manual)
"""
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.parse
import urllib.request

VERSION = '1.0'
PROTOCOL = 1          # bump only for incompatible manifest semantics
BASE = os.environ.get('FB_OTA_BASE', 'https://docs.maemetrics.com/filterbox')
PUBKEY = os.environ.get('FB_OTA_PUBKEY', '/etc/filterbox/ota-pub.pem')
ROOT = os.environ.get('FB_OTA_ROOT', '')          # test sandbox prefix
STATE_DIR = os.environ.get('FB_OTA_STATE', '/var/lib/filterbox/update')
LIVE = os.environ.get('FB_OTA_LIVE', '/usr/local/lib/filterbox')
RELEASES = os.environ.get('FB_OTA_RELEASES', '/opt/filterbox/releases')
UNIT_DIR = os.environ.get('FB_OTA_UNITS', '/etc/systemd/system')
def _conf(key, default=''):
    # Defined before root_path() on purpose: COHORT is computed at import time.
    path = os.path.join(ROOT, 'etc/filterbox/ota.conf') if ROOT else '/etc/filterbox/ota.conf'
    try:
        for line in open(path):
            if line.strip().startswith(key + '='):
                return line.split('=', 1)[1].strip()
    except OSError:
        pass
    return default


COHORT = os.environ.get('FB_OTA_COHORT') or _conf('COHORT', 'all')
MAX_MANIFEST = 256 * 1024
MAX_BUNDLE = 32 * 1024 * 1024
MAX_EXTRACT_BYTES = 256 * 1024 * 1024
MAX_MEMBERS = 5000
TIMEOUT = int(os.environ.get('FB_OTA_TIMEOUT', '30'))
MIN_FREE_MB = int(os.environ.get('FB_OTA_MIN_FREE_MB', '96'))
ALLOWED_SERVICES = ('fb-panel', 'fb-cover', 'fb-cover6', 'fb-lan-name', 'fb-avahi-alias')


def log(msg):
    line = '%s %s' % (time.strftime('%Y-%m-%dT%H:%M:%S'), msg)
    print(line, flush=True)
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        logfile = os.path.join(STATE_DIR, 'update.log')
        if os.path.exists(logfile) and os.path.getsize(logfile) > 512 * 1024:
            os.replace(logfile, logfile + '.1')
        with open(logfile, 'a') as fh:
            fh.write(line + '\n')
    except OSError:
        pass


def root_path(p):
    return os.path.join(ROOT, p.lstrip('/')) if ROOT else p


def fetch(url, limit, timeout=30, attempts=3):
    base = urllib.parse.urlsplit(BASE)
    last = None
    for attempt in range(attempts):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'FilterBox-OTA/%s' % VERSION})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                final = urllib.parse.urlsplit(resp.geturl())
                if (final.scheme, final.netloc) != (base.scheme, base.netloc):
                    raise RuntimeError('redirected off-origin: %s' % resp.geturl())
                if resp.status != 200:
                    raise RuntimeError('HTTP %s for %s' % (resp.status, url))
                data = resp.read(limit + 1)
            if len(data) > limit:
                raise RuntimeError('response too large: %s' % url)
            return data
        except Exception as e:
            last = e
            if attempt + 1 < attempts:
                time.sleep(2 * (attempt + 1))
    raise last


def verify_signature(manifest_bytes, sig_bytes):
    """ed25519 verify with the baked public key. Fail closed."""
    key = root_path(PUBKEY)
    if not os.path.exists(key):
        raise RuntimeError('no OTA public key at %s' % key)
    with tempfile.TemporaryDirectory() as td:
        m = os.path.join(td, 'manifest.json')
        s = os.path.join(td, 'manifest.sig')
        open(m, 'wb').write(manifest_bytes)
        open(s, 'wb').write(sig_bytes)
        r = subprocess.run(['openssl', 'pkeyutl', '-verify', '-rawin', '-pubin', '-inkey', key,
                            '-in', m, '-sigfile', s], capture_output=True, text=True)
    return r.returncode == 0


def vtuple(v):
    parts = []
    for p in str(v).split('.'):
        num = ''.join(ch for ch in p if ch.isdigit())
        parts.append(int(num or 0))
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def read_state():
    p = os.path.join(root_path(STATE_DIR), 'state.json')
    try:
        return json.load(open(p))
    except Exception:
        return {}


def write_state(**kw):
    d = read_state()
    d.update(kw)
    path = root_path(STATE_DIR)
    os.makedirs(path, exist_ok=True)
    tmp = os.path.join(path, '.state.tmp')
    with open(tmp, 'w') as fh:
        json.dump(d, fh, indent=1)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, os.path.join(path, 'state.json'))


def updates_enabled():
    """The wizard/Settings choice. Missing file means enabled (pilot default)."""
    conf = root_path('/etc/filterbox/ota.conf')
    try:
        for line in open(conf):
            if line.strip().startswith('UPDATE_ENABLED='):
                return line.split('=', 1)[1].strip().lower() not in ('0', 'false', 'no', 'off')
    except OSError:
        pass
    return True


def acquire_lock():
    """One update at a time: the timer and a manual run must never interleave."""
    os.makedirs(root_path(STATE_DIR), exist_ok=True)
    fh = open(os.path.join(root_path(STATE_DIR), 'lock'), 'w')
    try:
        fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return fh
    except OSError:
        fh.close()
        return None


def validate_manifest(man):
    """Reject a manifest that is signed but structurally unsafe or misdirected."""
    import re as _re
    if not isinstance(man, dict):
        raise ValueError('manifest is not an object')
    if not _re.fullmatch(r'\d+\.\d+\.\d+', str(man.get('version', ''))):
        raise ValueError('bad version')
    if not _re.fullmatch(r'[0-9a-f]{64}', str(man.get('sha256', ''))):
        raise ValueError('bad sha256')
    url, base = urllib.parse.urlsplit(str(man.get('url', ''))), urllib.parse.urlsplit(BASE)
    if (url.scheme, url.netloc) != (base.scheme, base.netloc):
        raise ValueError('bundle url escapes the configured origin: %s' % man.get('url'))
    files = man.get('files')
    if not isinstance(files, dict) or not files:
        raise ValueError('files map missing')
    for rel, digest in files.items():
        if rel.startswith('/') or '..' in rel.split('/') or not _re.fullmatch(r'[0-9a-f]{64}', str(digest)):
            raise ValueError('bad file entry: %s' % rel)
    return True


def installed_mismatches(man):
    """Self-heal input: which installed files do not match the signed release?"""
    bad = []
    for rel, want in man.get('files', {}).items():
        group, _, name = rel.partition('/')
        base = {'payload': LIVE, 'units': UNIT_DIR}.get(group)
        if not base or not name:
            continue
        path = os.path.join(root_path(base), name)
        try:
            got = hashlib.sha256(open(path, 'rb').read()).hexdigest()
        except OSError:
            got = ''
        if got != want:
            bad.append(rel)
    return bad


def current_version():
    # A reflashed or restored card must not be shadowed by stale state.
    try:
        v = open(os.path.join(root_path(LIVE), 'VERSION')).read().strip()
        if v:
            return v
    except OSError:
        pass
    return str(read_state().get('installed', '0.0.0'))


def safe_extract(blob, dest):
    """Extract a .tar.xz into dest after validating every member."""
    os.makedirs(dest, exist_ok=True)
    with tempfile.NamedTemporaryFile(suffix='.tar.xz', delete=False) as tf:
        tf.write(blob)
        tmp = tf.name
    try:
        with tarfile.open(tmp, 'r:xz') as tf:
            members = tf.getmembers()
            if len(members) > MAX_MEMBERS:
                raise RuntimeError('bundle has too many members: %d' % len(members))
            total = 0
            for m in members:
                total += max(m.size, 0)
                if total > MAX_EXTRACT_BYTES:
                    raise RuntimeError('bundle expands beyond the size cap')
                name = m.name
                if name.startswith('/') or '..' in name.split('/'):
                    raise RuntimeError('unsafe path in bundle: %s' % name)
                if m.issym() or m.islnk() or m.isdev() or m.isfifo():
                    raise RuntimeError('unsupported member type: %s' % name)
                if not (m.isfile() or m.isdir()):
                    raise RuntimeError('unsupported member: %s' % name)
            tf.extractall(dest)
    finally:
        os.unlink(tmp)


def staged_mismatches(src_dir, man):
    """A signed manifest with wrong per-file hashes must not be installed."""
    bad = []
    for rel, want in man.get('files', {}).items():
        path = os.path.join(src_dir, rel)
        try:
            got = hashlib.sha256(open(path, 'rb').read()).hexdigest()
        except OSError:
            bad.append(rel + ' (missing)')
            continue
        if got != want:
            bad.append(rel)
    return bad


def unexpected_files(src_dir, man):
    expected, found = set(man.get('files', {})), set()
    for group in ('payload', 'units'):
        d = os.path.join(src_dir, group)
        if os.path.isdir(d):
            for name in os.listdir(d):
                if os.path.isfile(os.path.join(d, name)):
                    found.add(group + '/' + name)
    return sorted(found - expected)


def install_files(src_dir, backup_dir):
    """Copy payload/ + units/ over the live tree atomically; returns touched files."""
    touched = []
    os.makedirs(backup_dir, exist_ok=True)
    for sub, target in (('payload', LIVE), ('units', UNIT_DIR)):
        base = os.path.join(src_dir, sub)
        if not os.path.isdir(base):
            continue
        for name in sorted(os.listdir(base)):
            src = os.path.join(base, name)
            if not os.path.isfile(src):
                continue
            dst = os.path.join(root_path(target), name)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            if os.path.exists(dst):
                shutil.copy2(dst, os.path.join(backup_dir, name))
            tmp = dst + '.fbnew'
            shutil.copy2(src, tmp)
            if name.endswith('.py'):
                chk = subprocess.run([sys.executable, '-m', 'py_compile', tmp],
                                     capture_output=True)
                if chk.returncode != 0:
                    os.unlink(tmp)
                    raise RuntimeError('payload %s does not compile' % name)
            os.chmod(tmp, 0o755 if name.endswith(('.sh', '.py')) else 0o644)
            os.replace(tmp, dst)
            touched.append((name, dst))
    return touched


def apply_config(src_dir):
    """Idempotent assertions on files we own. Never replaces a whole config."""
    path = os.path.join(src_dir, 'config.json')
    if not os.path.exists(path):
        return []
    spec = json.load(open(path))
    changes = []
    toml = root_path(spec.get('pihole_toml', '/etc/pihole/pihole.toml'))
    lines = spec.get('dnsmasq_lines') or []
    if lines and os.path.exists(toml):
        text = open(toml).read()
        import re
        m = re.search(r'^(\s*dnsmasq_lines\s*=\s*)\[(.*?)\]', text, re.M | re.S)
        if not m:
            raise RuntimeError('dnsmasq_lines not found in %s' % toml)
        existing = [x.strip().strip('"\'') for x in m.group(2).split(',') if x.strip()]
        wanted = existing + [x for x in lines if x not in existing]
        if wanted != existing:
            new = m.group(1) + '[' + ', '.join('"%s"' % x for x in wanted) + ']'
            open(toml + '.fbnew', 'w').write(text[:m.start()] + new + text[m.end():])
            os.replace(toml + '.fbnew', toml)
            changes.append('dnsmasq_lines += %s' % ', '.join(x for x in lines if x not in existing))
    return changes


def restart_services():
    if ROOT:
        return []
    # units may have changed; without this systemd keeps the old definitions
    subprocess.run(['systemctl', 'daemon-reload'], capture_output=True, timeout=60)
    done = []
    for unit in ALLOWED_SERVICES:
        r = subprocess.run(['systemctl', 'restart', unit], capture_output=True, text=True, timeout=90)
        if r.returncode == 0:
            done.append(unit)
    return done


def dns_ok():
    import socket, struct
    q = b'\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00' + b'\x07example\x03com\x00' + b'\x00\x01\x00\x01'
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(3)
        s.sendto(q, ('127.0.0.1', 53))
        data, _ = s.recvfrom(512)
        s.close()
        return len(data) > 12 and data[2] & 0x80  # QR set
    except Exception:
        return False


def http_ok(port=80):
    import socket
    try:
        s = socket.create_connection(('127.0.0.1', port), timeout=3)
        s.sendall(b'GET /api/health HTTP/1.0\r\nHost: localhost\r\n\r\n')
        data = s.recv(256)
        s.close()
        return b'200' in data.split(b'\r\n')[0]
    except Exception:
        return False


def updater_ok():
    """A self-update must leave a working updater behind."""
    path = os.path.join(root_path(LIVE), 'fb-update.py')
    if not os.path.exists(path):
        return True
    try:
        r = subprocess.run([sys.executable, path, 'status'], capture_output=True, timeout=30)
        return r.returncode == 0
    except Exception as e:
        log('updater self-test failed: %s' % e)
        return False


def health_check(seconds=90):
    forced = os.environ.get('FB_OTA_HEALTH')
    if forced == 'ok':
        return True
    if forced == 'fail':
        return False
    deadline = time.time() + seconds
    while time.time() < deadline:
        if dns_ok() and http_ok():
            return True
        time.sleep(3)
    return False


def rollback(prev, backup_dir, code=0):
    log('rolling back to %s' % prev)
    restored = 0
    try:
        if os.path.isdir(backup_dir):
            for name in os.listdir(backup_dir):
                src = os.path.join(backup_dir, name)
                dst = os.path.join(root_path(LIVE), name)
                try:
                    shutil.copy2(src, dst)
                    restored += 1
                except OSError as e:
                    log('rollback: could not restore %s: %s' % (name, e))
    except Exception as e:
        log('rollback failed: %s' % e)
    try:
        restart_services()
    except Exception as e:
        log('rollback restart failed: %s' % e)
    log('rollback restored %d file(s)' % restored)
    write_state(installed=prev, rolled_back_at=int(time.time()))
    return code


def cmd_check(apply_changes=False):
    lock = acquire_lock()
    if lock is None:
        log('another update is already running — exiting')
        return 0
    if not updates_enabled():
        log('automatic updates are disabled by the owner — nothing to do')
        return 0
    cur = current_version()
    try:
        manifest_bytes = fetch(BASE + '/update.json', MAX_MANIFEST, timeout=TIMEOUT)
        sig = fetch(BASE + '/update.json.sig', 4096, timeout=TIMEOUT)
    except Exception as e:
        log('check failed: %s' % e)
        return 2
    try:
        valid = verify_signature(manifest_bytes, sig)
    except Exception as e:
        log('signature check failed: %s — refusing' % e)
        return 3
    if not valid:
        log('SIGNATURE INVALID — refusing (fail closed)')
        return 3
    try:
        man = json.loads(manifest_bytes)
        validate_manifest(man)
    except Exception as e:
        log('manifest rejected: %s' % e)
        return 8
    proto = int(man.get('protocol', 1) or 1)
    if proto > PROTOCOL:
        log('manifest needs updater protocol %d, this box speaks %d — skipping' % (proto, PROTOCOL))
        return 11
    new = str(man.get('version', '0'))
    seq = int(man.get('sequence', 0) or 0)
    seen = int(read_state().get('sequence', 0) or 0)
    if seen and seq and seq < seen:
        log('manifest replay refused: sequence %d is older than %d' % (seq, seen))
        return 10
    if new in (man.get('revoked') or []):
        log('version %s is revoked by the manifest — refusing' % new)
        return 4
    repair = vtuple(new) == vtuple(cur)
    if vtuple(new) < vtuple(cur):
        log('up to date (%s)' % cur)
        write_state(last_check=int(time.time()), last_result='up-to-date')
        return 0
    if repair:
        bad = installed_mismatches(man)
        if not bad:
            log('up to date (%s); all files match' % cur)
            write_state(last_check=int(time.time()), last_result='up-to-date')
            return 0
        log('self-heal: %d installed file(s) differ from release %s: %s'
            % (len(bad), new, ', '.join(bad[:5])))
    floor = str(man.get('min_version', '0'))
    if not repair and vtuple(cur) < vtuple(floor):
        log('installed %s is older than min_version %s — manual reflash required' % (cur, floor))
        return 5
    cohort = man.get('cohort', 'all')
    if not repair and cohort not in ('all', COHORT):
        log('version %s is for cohort %r, this unit is %r — skipping' % (new, cohort, COHORT))
        write_state(last_check=int(time.time()), last_result='cohort-skip')
        return 0
    log('%s: %s -> %s (%s)' % ('repairing' if repair else 'update available',
                               cur, new, man.get('notes', '')[:120]))
    if not apply_changes:
        return 0
    try:
        os.makedirs(root_path(RELEASES), exist_ok=True)
        free = shutil.disk_usage(root_path(RELEASES)).free
    except OSError as e:
        log('cannot check free space (%s) — continuing' % e)
        free = 1 << 62
    if free < MIN_FREE_MB * 1024 * 1024:
        log('not enough free space (%d MB) — skipping' % (free // (1024 * 1024)))
        return 9
    try:
        blob = fetch(man['url'], MAX_BUNDLE, timeout=TIMEOUT)
    except Exception as e:
        log('download failed: %s' % e)
        return 6
    if hashlib.sha256(blob).hexdigest() != man['sha256']:
        log('BUNDLE HASH MISMATCH — refusing')
        return 7
    rel = os.path.join(root_path(RELEASES), new)
    shutil.rmtree(rel, ignore_errors=True)
    safe_extract(blob, rel)
    bad = staged_mismatches(rel, man)
    if bad:
        log('bundle does not match the signed file map: %s' % ', '.join(bad[:5]))
        return 7
    extra = unexpected_files(rel, man)
    if extra:
        log('bundle contains files the manifest does not list: %s' % ', '.join(extra[:5]))
        return 7
    backup = os.path.join(rel, '_backup')
    try:
        touched = install_files(rel, backup)
        changes = apply_config(rel)
    except Exception as e:
        log('install failed: %s' % e)
        return rollback(cur, backup, code=1)
    log('installed %d files%s' % (len(touched), ('; ' + '; '.join(changes)) if changes else ''))
    if not updater_ok():
        log('installed updater does not start — rolling back')
        return rollback(cur, backup, code=1)
    restart_services()
    if not health_check():
        log('HEALTH CHECK FAILED after update')
        return rollback(cur, backup, code=1)
    write_state(installed=new, sequence=seq, installed_at=int(time.time()),
                last_result='repaired' if repair else 'ok',
                previous=cur if not repair else read_state().get('previous'),
                last_check=int(time.time()))
    log('update complete: %s' % new)
    return 0


def main(argv):
    cmd = argv[1] if len(argv) > 1 else 'check'
    if cmd == 'check':
        return cmd_check(False)
    if cmd == 'apply':
        return cmd_check(True)
    if cmd == 'status':
        st = read_state()
        print(json.dumps({'version': current_version(), **st}, indent=1))
        return 0
    if cmd == 'rollback':
        st = read_state()
        prev = st.get('previous')
        if not prev:
            print('no previous release recorded')
            return 1
        return rollback(prev, os.path.join(root_path(RELEASES), st.get('installed', ''), '_backup'))
    print(__doc__)
    return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv))
