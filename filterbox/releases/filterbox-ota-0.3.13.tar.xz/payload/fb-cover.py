#!/usr/bin/env python3
# fb-cover — FilterBox "Gateway Claim" coverage engine.
#
# True plug-and-play whole-home DNS coverage WITHOUT router access:
#   * claims the LAN gateway IP via ARP (broadcast + targeted), so every device's
#     internet-bound traffic (and therefore every DNS query, including devices with
#     hardcoded resolvers) traverses this box;
#   * netfilter (see fb-cover-net.sh) redirects :53 to the local FTL and drops :853;
#   * fails OPEN: on unhealthy filter, or on shutdown/crash, the box sends ARP
#     corrections ("the gateway is really at the router's MAC") and drops its rules,
#     so the home falls back to plain unfiltered internet within seconds;
#   * on a total power cut the devices' neighbor caches expire on their own
#     (RFC4861 NUD, ~15-45 s) and the internet heals without any user action.
#
# Usage:
#   fb-cover.py            run as daemon (systemd Type=notify)
#   fb-cover.py --restore  one-shot: send ARP corrections, remove netfilter rules
#   fb-cover.py --status   print the current state JSON and exit
#
# Config via environment (/etc/filterbox/fb-cover.env, optional):
#   FB_COVER=0            disable (daemon and guard both no-op)
#   FB_COVER_CLAIM_INTERVAL / FB_COVER_TARGET_INTERVAL / FB_COVER_HEALTH_INTERVAL
#   FB_COVER_FAIL_N / FB_COVER_OK_N     transition thresholds (consecutive checks)
#   FB_COVER_PROBE        test domain for the DNS health probe (default example.com)
#   FB_COVER_NET_SH       path to fb-cover-net.sh
#
# Exit codes: 0 ok; 2 no usable default route/gateway; 3 another instance running.

import fcntl
import json
import os
import select
import signal
import socket
import struct
import subprocess
import sys
import threading
import time

VERSION = '0.2.0'
RUN_DIR = os.environ.get('FB_COVER_RUN_DIR', '/run/fb-cover')
STATE_FILE = os.path.join(RUN_DIR, 'state.json')
NET_SH = os.environ.get('FB_COVER_NET_SH', '/usr/local/lib/filterbox/fb-cover-net.sh')

CLAIM_INTERVAL = float(os.environ.get('FB_COVER_CLAIM_INTERVAL', '0.2'))  # keep the cache pinned; router replies race the claim
TARGET_INTERVAL = float(os.environ.get('FB_COVER_TARGET_INTERVAL', '10'))
HEALTH_INTERVAL = float(os.environ.get('FB_COVER_HEALTH_INTERVAL', '2'))
FAIL_N = int(os.environ.get('FB_COVER_FAIL_N', '2'))
OK_N = int(os.environ.get('FB_COVER_OK_N', '3'))
PROBE_DOMAIN = os.environ.get('FB_COVER_PROBE', 'example.com')
PROBE_TIMEOUT = float(os.environ.get('FB_COVER_PROBE_TIMEOUT', '2'))

ETH_P_ARP = 0x0806
ETH_P_ALL = 0x0003

_log_lock = threading.Lock()


def log(msg):
    with _log_lock:
        print('%s fb-cover: %s' % (time.strftime('%Y-%m-%dT%H:%M:%S'), msg), flush=True)


_tlog_last = {}


def tlog(key, msg, interval=60):
    """Log at most once per interval per key — keeps a down link from filling the journal."""
    now = time.time()
    if now - _tlog_last.get(key, 0) >= interval:
        _tlog_last[key] = now
        log(msg)


def mac_b(mac):
    return bytes.fromhex(mac.replace(':', ''))


def mac_s(b):
    return ':'.join('%02x' % x for x in b)


def _ioctl(iface, req, fmt):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        return fcntl.ioctl(s.fileno(), req, struct.pack('256s', iface.encode()[:15]))
    finally:
        s.close()


def if_ip(iface):
    return socket.inet_ntoa(_ioctl(iface, 0x8915, None)[20:24])


def if_mac(iface):
    return mac_s(_ioctl(iface, 0x8927, None)[18:24])


def default_route():
    """Return (iface, gateway_ip) from /proc/net/route, or (None, None)."""
    try:
        with open('/proc/net/route') as f:
            next(f)
            for line in f:
                p = line.split()
                if len(p) >= 3 and p[1] == '00000000':
                    gw = socket.inet_ntoa(struct.pack('<L', int(p[2], 16)))
                    return p[0], gw
    except Exception:
        pass
    return None, None


def arp_entry(ip):
    """Real MAC currently in the kernel ARP table for ip (or None)."""
    try:
        with open('/proc/net/arp') as f:
            next(f)
            for line in f:
                p = line.split()
                if len(p) >= 4 and p[0] == ip and p[2] != '0x0' and p[3] != '00:00:00:00:00:00':
                    return p[3].lower()
    except Exception:
        pass
    return None


def arp_devices(exclude=()):
    out = {}
    try:
        with open('/proc/net/arp') as f:
            next(f)
            for line in f:
                p = line.split()
                if len(p) >= 4 and p[2] != '0x0' and p[3] != '00:00:00:00:00:00' and p[0] not in exclude:
                    out[p[0]] = p[3].lower()
    except Exception:
        pass
    return out


def dns_query(server, name, timeout):
    """One UDP DNS query. Returns (rcode, ancount) or None (timeout/error)."""
    qid = os.urandom(2)
    q = qid + b'\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00'
    for part in name.split('.'):
        if part:
            q += bytes([len(part)]) + part.encode()
    q += b'\x00\x00\x01\x00\x01'
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(timeout)
    try:
        s.sendto(q, (server, 53))
        resp, _ = s.recvfrom(768)
        if len(resp) < 12:
            return None
        flags = struct.unpack('!H', resp[2:4])[0]
        return (flags & 0x000F, struct.unpack('!H', resp[6:8])[0])
    except Exception:
        return None
    finally:
        s.close()


LOCAL_PROBE = os.environ.get('FB_COVER_LOCAL_PROBE', 'pi.hole')


def _read_fwd():
    try:
        with open('/proc/sys/net/ipv4/ip_forward') as f:
            return f.read().strip()
    except Exception:
        return '1'


def dns_query_many(server, names, timeout):
    """Send every query at once and collect answers under ONE deadline.

    The socket is CONNECTED to the resolver and each reply must carry QR=1,
    QDCOUNT=1 and echo the exact question name — otherwise any LAN host that
    guesses the ephemeral port + 16-bit ID could fake a healthy engine."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    pending = {}
    out = {}
    try:
        sock.connect((server, 53))
        sock.setblocking(False)
    except Exception:
        sock.close()
        return out

    def qname_of(resp):
        i, labels = 12, []
        while i < len(resp):
            n = resp[i]
            if n == 0:
                return '.'.join(labels).lower()
            if n & 0xC0:
                return None          # compression in a question is not expected
            i += 1
            labels.append(resp[i:i + n].decode('ascii', 'ignore'))
            i += n
        return None

    try:
        for name in names:
            qid = os.urandom(2)
            pending[qid] = name
            q = qid + b'\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00'
            for part in name.split('.'):
                if part:
                    q += bytes([len(part)]) + part.encode()
            q += b'\x00\x00\x01\x00\x01'
            try:
                sock.send(q)
            except Exception:
                pending.pop(qid, None)
        end = time.time() + timeout
        while pending:
            left = end - time.time()
            if left <= 0:
                break
            r, _, _ = select.select([sock], [], [], left)
            if not r:
                break
            try:
                resp = sock.recv(768)
            except Exception:
                break
            if len(resp) < 12:
                continue
            name = pending.get(resp[:2])
            if name is None:
                continue
            flags = struct.unpack('!H', resp[2:4])[0]
            if not (flags & 0x8000) or struct.unpack('!H', resp[4:6])[0] != 1:
                continue                     # not a response to exactly one question
            if qname_of(resp) != name.lower():
                continue                     # answer for a different name
            pending.pop(resp[:2], None)
            out[name] = (flags & 0x000F, struct.unpack('!H', resp[6:8])[0])
    finally:
        sock.close()
    return out


def dns_probe(server, timeout):
    """Two signals, so a broken resolver cannot masquerade as healthy.

    1) FTL answers its own local name (pi.hole / filterbox.local) — no upstream,
       no blocklist, no DNSSEC involved. If FTL is dead or NXDOMAINs everything,
       this fails.
    2) A unique label under example.com (never cached, never blocklisted): the
       answer must be NOERROR (NODATA included) or NXDOMAIN. SERVFAIL/REFUSED/
       timeout => the house's DNS is not being served => fail open.

    All queries are sent concurrently under one deadline, so the worst-case
    probe costs `timeout`, not N×timeout.
    """
    nonce = 'fbprobe-%s.example.com' % os.urandom(6).hex()
    local_names = (LOCAL_PROBE, 'filterbox.local')
    res = dns_query_many(server, local_names + (nonce, 'example.com'), timeout)
    local_ok = any(res.get(n) and res[n][0] == 0 and res[n][1] > 0 for n in local_names)
    up = res.get(nonce)
    pub = res.get('example.com')
    # Third signal: a well-known public name must resolve with data. This closes
    # the 'resolver answers NXDOMAIN/NODATA for everything' blind spot while
    # remaining tolerant of normal filtering (NULL blocking returns 0.0.0.0).
    public_ok = bool(pub and pub[0] == 0 and pub[1] > 0)
    return bool(local_ok and public_ok and up and up[0] in (0, 3))


def sd_notify(msg):
    addr = os.environ.get('NOTIFY_SOCKET')
    if not addr:
        return
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        s.connect(addr)
        s.sendall(msg.encode())
        s.close()
    except Exception:
        pass


class Cover(object):
    def __init__(self):
        self.lock = threading.Lock()
        self.state = 'wait'          # wait | full | bypass
        self.reason = ''
        self.iface = None
        self.gw_ip = None
        self.gw_mac = None
        self.own_ip = None
        self.own_mac = None
        self.devices = {}            # ip -> mac (learned)
        self.since = time.time()
        self.fails = 0
        self.oks = 0
        self.stop = threading.Event()
        self.raw = None
        self._raw_lock = threading.Lock()
        self._wlock = threading.Lock()
        self._released = True
        self._last_targeted = {}     # ip -> last targeted op=1 claim

    # ---- net -------------------------------------------------------------
    def setup_iface(self):
        iface, gw = default_route()
        if not iface or not gw or gw == '0.0.0.0':
            return False
        try:
            own_ip = if_ip(iface)
            own_mac = if_mac(iface)
        except Exception as e:
            log('cannot read interface %s: %s' % (iface, e))
            return False
        new = None
        try:
            new = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(ETH_P_ARP))
            new.bind((iface, 0))
        except Exception as e:
            try:
                if new is not None:
                    new.close()
            except Exception:
                pass
            log('cannot open ARP socket on %s: %s' % (iface, e))
            return False
        gw_mac = self._arp_query_on(new, own_mac, own_ip, gw) or arp_entry(gw)
        if not gw_mac:
            try:
                new.close()
            except Exception:
                pass
            log('gateway MAC not learned for %s' % gw)
            return False
        with self._raw_lock:
            old = self.raw
            self.raw = new
        try:
            if old:
                old.close()
        except Exception:
            pass
        self.iface = iface
        self.own_ip = own_ip
        self.own_mac = own_mac
        self.gw_ip = gw
        self.gw_mac = gw_mac
        return True

    def _arp_query_on(self, sock, own_mac, own_ip, ip):
        """Ask the LAN who has ip on the given socket; catch the reply there."""
        try:
            frame = self._arp_frame(1, own_mac, own_ip, 'ff:ff:ff:ff:ff:ff', ip)
            sock.send(frame)
        except Exception:
            return None
        sock.settimeout(0.4)
        try:
            for _ in range(6):
                try:
                    data = sock.recv(2048)
                except socket.timeout:
                    continue
                except Exception:
                    break
                if len(data) >= 42 and data[12:14] == b'\x08\x06':
                    op = struct.unpack('!H', data[20:22])[0]
                    spa = socket.inet_ntoa(data[28:32])
                    if op == 2 and spa == ip:
                        return mac_s(data[22:28])
        finally:
            try:
                sock.settimeout(None)
            except Exception:
                pass
        return arp_entry(ip)

    def _arp_frame(self, op, sha, spa, tha, tpa, eth_src=None):
        """Build an ARP frame.

        eth_src is the Ethernet source MAC; sha is the ARP "sender hardware
        address". They are deliberately separate: for corrections we send FROM
        our port but CLAIM the gateway is at the router's MAC. Using the router
        MAC as eth_src would poison every switch CAM (router MAC learned on our
        port), which blackholes the LAN after bypass until the CAM ages out.
        """
        src = eth_src or self.own_mac or sha
        eth = mac_b(tha) + mac_b(src) + b'\x08\x06'
        body = struct.pack('!HHBBH', 1, 0x0800, 6, 4, op)
        body += mac_b(sha) + socket.inet_aton(spa) + mac_b(tha) + socket.inet_aton(tpa)
        return eth + body + b'\x00' * 18

    def arp_send(self, sha, spa, tha, tpa, eth_src=None, op=2):
        with self._raw_lock:
            sock = self.raw
            if not sock:
                return
            try:
                sock.send(self._arp_frame(op, sha, spa, tha, tpa, eth_src=eth_src))
            except Exception as e:
                now = time.time()
                if now - getattr(self, '_last_senderr', 0) > 30:
                    self._last_senderr = now
                    log('arp send error (throttled): %s' % e)

    # ---- claim / corrections --------------------------------------------
    def claim_burst(self, count=1):
        """Claim the gateway with gratuitous ARP REQUESTS (op=1).

        Unsolicited replies (op=2) are ignored by Linux clients holding a
        REACHABLE entry; a request updates their cache. The sniffer also answers
        their own gateway ARP probes, so the first query wins the race."""
        for _ in range(count):
            self.arp_send(self.own_mac, self.gw_ip, 'ff:ff:ff:ff:ff:ff', self.gw_ip, op=1)
            with self.lock:
                devs = list(self.devices.items())
            for ip, mac in devs:
                self.arp_send(self.own_mac, self.gw_ip, mac, ip, op=1)

    def corrections(self, count=3, force=False):
        """Tell the LAN the gateway really is the router again. Fire-and-forget.

        The Ethernet source stays OUR MAC; only the ARP payload advertises the
        router's MAC. If we spoofed eth_src, every switch would learn the router
        MAC on our port and, once bypass turns ip_forward off, blackhole the
        whole LAN until the CAM ages out (300 s on common switches)."""
        if not (self.gw_ip and self.own_mac):
            return
        with self.lock:
            st = self.state
        if st == 'bypass':
            # Never trust the cache in bypass: a router can change its MAC without
            # any ARP traffic, and re-advertising the old MAC blackholes the LAN.
            fresh = self._refresh_gw_mac(force=True)
            if not fresh:
                return    # never advertise a MAC we could not confirm
            self.gw_mac = fresh
        elif self.gw_mac:
            fresh = arp_entry(self.gw_ip)   # near-zero cost; survives router MAC changes
            if fresh:
                self.gw_mac = fresh
            else:
                fresh = self._refresh_gw_mac()
                if fresh:
                    self.gw_mac = fresh
        if not self.gw_mac:
            return
        for _ in range(count):
            if not force:
                with self.lock:
                    if self.state != 'bypass':
                        return    # re-engaged: stop sending router-MAC corrections
            self.arp_send(self.gw_mac, self.gw_ip, 'ff:ff:ff:ff:ff:ff', self.gw_ip,
                          eth_src=self.own_mac)
            with self.lock:
                devs = list(self.devices.items())
            for ip, mac in devs:
                self.arp_send(self.gw_mac, self.gw_ip, mac, ip, eth_src=self.own_mac)
            time.sleep(0.15)
        log('ARP corrections sent (%d bursts, %d devices)' % (count, len(self.devices)))

    def net(self, action):
        # Every netfilter batch can take seconds on a slow ARM box; ping the
        # watchdog before starting so a long-but-progressing tick cannot trip it.
        sd_notify('WATCHDOG=1')
        try:
            r = subprocess.run([NET_SH, action], capture_output=True, timeout=15)
            if r.returncode != 0:
                log('net %s rc=%d %s' % (action, r.returncode, r.stderr.decode()[:200]))
            return r.returncode == 0
        except Exception as e:
            log('net %s failed: %s' % (action, e))
            return False

    def _refresh_gw_mac(self, force=False):
        """Actively resolve the gateway MAC. A UDP send triggers kernel ARP; if
        that yields nothing, a raw ARP request does the job. force=True ignores
        the cache entirely (bypass: a stale entry is worse than no entry)."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                s.connect((self.gw_ip, 9))
                s.send(b'\x00')
            finally:
                s.close()
        except Exception:
            pass
        if not force:
            for _ in range(4):
                m = arp_entry(self.gw_ip)
                if m:
                    return m
                time.sleep(0.25)
        if not (self.iface and self.own_mac and self.own_ip):
            return None
        sock = None
        try:
            sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(ETH_P_ARP))
            sock.bind((self.iface, 0))
            sock.settimeout(0.4)
            sock.send(self._arp_frame(1, self.own_mac, self.own_ip,
                                      'ff:ff:ff:ff:ff:ff', self.gw_ip))
            end = time.time() + 1.2
            while time.time() < end:
                try:
                    data = sock.recv(2048)
                except socket.timeout:
                    continue
                if len(data) >= 42 and data[12:14] == b'\x08\x06':
                    op = struct.unpack('!H', data[20:22])[0]
                    spa = socket.inet_ntoa(data[28:32])
                    if op == 2 and spa == self.gw_ip:
                        return mac_s(data[22:28])
        except Exception:
            return None
        finally:
            try:
                if sock:
                    sock.close()
            except Exception:
                pass
        return None

    # ---- state -----------------------------------------------------------
    def set_state(self, state, reason='', publish=True):
        with self.lock:
            changed = state != self.state
            old_reason = self.reason
            self.state = state
            if changed or reason:
                self.reason = reason
            if changed:
                self.since = time.time()
            reason_changed = reason != old_reason
        if changed:
            log('state -> %s (%s)' % (state, reason or '-'))
        if (changed or reason_changed) and publish:
            self.write_state()

    def write_state(self):
        try:
            os.makedirs(RUN_DIR, exist_ok=True)
            with self.lock:
                data = {
                    'state': self.state,
                    'reason': self.reason,
                    'devices': len(self.devices),
                    'iface': self.iface,
                    'own_ip': self.own_ip,
                    'gateway': self.gw_ip,
                    'since': int(self.since),
                    'ts': int(time.time()),
                    'released': bool(getattr(self, '_released', True)),
                    'version': VERSION,
                }
            with self._wlock:   # single writer at a time; os.replace = atomic publish
                tmp = STATE_FILE + '.tmp'
                with open(tmp, 'w') as f:
                    json.dump(data, f)
                os.replace(tmp, STATE_FILE)
        except Exception:
            pass

    def go_full(self):
        # No consent gate: the box filters from power-on. A factory reset must not
        # leave the home unfiltered — the reset only clears ownership/statistics.
        now = time.time()
        if now < getattr(self, '_next_full_attempt', 0):
            return
        if not self.setup_iface():
            self._next_full_attempt = now + 10
            self._released = bool(self.net('remove'))
            self.set_state('bypass', 'iface/gateway setup failed')
            return
        if not self.net('apply'):
            self._next_full_attempt = now + 10
            # If the release cannot be verified, keep retrying it — never claim
            # "internet is open" while capture rules may still be installed.
            self._released = bool(self.net('remove'))
            self.set_state('bypass', 'netfilter apply failed')
            return
        if _read_fwd() != '1':
            # apply succeeded but forwarding is still off (hostile writer): do not
            # filter while the LAN cannot be forwarded.
            self._next_full_attempt = now + 10
            self._released = bool(self.net('remove'))
            self.set_state('bypass', 'ip_forward is off')
            return
        # Consent is implicit: the appliance exists to filter, and claim starts as
        # soon as the route and resolver are healthy.
        self._next_full_attempt = 0
        self._released = False
        self.claim_burst(2)
        self.set_state('full', 'healthy')
        self.write_state()   # relearn may change iface/ip without a state change

    def go_bypass(self, reason):
        # Stop claiming first, then drop rules. 'bypass' is published only AFTER
        # release so the panel can never say 'internet is open' while capture
        # rules are still installed.
        self.set_state('bypass', reason, publish=False)
        self._released = bool(self.net('remove'))
        self.write_state()
        if not self._released:
            log('RELEASE FAILED — will keep retrying until the rules are gone')
        threading.Thread(target=self.corrections, args=(3,), daemon=True).start()
        # repeat truthful corrections for a few seconds (devices re-probing are also
        # answered correctly by the sniffer; this covers devices that don't re-probe)
        threading.Thread(target=self._corrections_tail, daemon=True).start()

    def _corrections_tail(self):
        for delay in (2, 3, 4, 5, 6):
            time.sleep(delay)
            with self.lock:
                state = self.state
            if state != 'bypass':
                return
            self.corrections(1)

    # ---- loops -----------------------------------------------------------
    def _remember(self, ip, mac):
        # Bounded device table: an ARP flood with spoofed sender IPs must not
        # grow the table to 65k and turn every 3 s claim burst into a flood.
        with self.lock:
            if ip not in self.devices and len(self.devices) >= 512:
                return
            self.devices[ip] = mac

    def learn_loop(self):
        """Supervised ARP sniffer + /proc poll -> device bookkeeping, probe answers.

        Bound to ETH_P_ARP (not ETH_P_ALL: copying every forwarded frame would burn
        the CPU and overflow the socket buffer). Rebinds if the interface changes and
        never dies silently.
        """
        sniffer = None
        bound = None
        while not self.stop.is_set():
            try:
                if sniffer is None or bound != self.iface:
                    if sniffer is not None:
                        try:
                            sniffer.close()
                        except Exception:
                            pass
                    sniffer = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(ETH_P_ARP))
                    try:
                        sniffer.setsockopt(getattr(socket, 'SOL_PACKET', 263), 23, 1)  # PACKET_IGNORE_OUTGOING
                    except Exception:
                        pass
                    try:
                        sniffer.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 262144)
                    except Exception:
                        pass
                    sniffer.bind((self.iface, 0))
                    sniffer.setblocking(False)
                    bound = self.iface
                    tlog('bind', 'ARP sniffer bound to %s' % bound, 120)
                try:
                    data = sniffer.recv(2048)
                except BlockingIOError:
                    # poll /proc at 1 Hz, but wake 50x/s so an ARP request for the
                    # gateway is answered in milliseconds, not after a 1 s sleep
                    if time.time() - getattr(self, '_last_proc_poll', 0) >= 1.0:
                        self._last_proc_poll = time.time()
                        for ip, mac in arp_devices(exclude=(self.gw_ip, self.own_ip)).items():
                            self._remember(ip, mac)
                    time.sleep(0.02)
                    continue
                if len(data) >= 42 and data[12:14] == b'\x08\x06':
                    op = struct.unpack('!H', data[20:22])[0]
                    spa = socket.inet_ntoa(data[28:32])
                    sha = mac_s(data[22:28])
                    tpa = socket.inet_ntoa(data[38:42])
                    if spa not in (self.gw_ip, self.own_ip) and sha != self.own_mac:
                        self._remember(spa, sha)
                        # A router reply to the same probe can land after ours;
                        # a targeted op=1 keeps the client pointed at the box.
                        with self.lock:
                            state = self.state
                        if state == 'full':
                            now = time.time()
                            if now - self._last_targeted.get(spa, 0) >= 0.5:
                                self._last_targeted[spa] = now
                                self.arp_send(self.own_mac, self.gw_ip, sha, spa, op=1)
                    if op == 1 and tpa == self.gw_ip and sha != self.own_mac:
                        # someone probes for the gateway — answer correctly for our state:
                        # full  -> claim (we are the gateway); bypass -> truthful correction
                        with self.lock:
                            state = self.state
                        if state == 'full':
                            self.arp_send(self.own_mac, self.gw_ip, sha, spa)
                            # Follow with a request: a client that already has the
                            # router marked REACHABLE ignores an unsolicited reply.
                            time.sleep(0.015)
                            self.arp_send(self.own_mac, self.gw_ip, sha, spa, op=1)
                            self._extra_claim = True
                        elif state == 'bypass' and self.gw_mac:
                            self.arp_send(self.gw_mac, self.gw_ip, sha, spa,
                                          eth_src=self.own_mac)
                    elif op == 1 and spa == self.gw_ip and sha != self.own_mac and tpa != self.gw_ip:
                        # The router just answered a client's gateway ARP probe.
                        # Re-claim that client ~20 ms later, or its traffic escapes
                        # to the router until the next periodic burst.
                        with self.lock:
                            state = self.state
                        if state == 'full':
                            time.sleep(0.02)
                            with self.lock:
                                cmac = self.devices.get(tpa)
                            if cmac:
                                # tha must be the CLIENT's MAC; passing the router's
                                # MAC sent the claim to the router and left the client
                                # on the router path until the next periodic burst.
                                self.arp_send(self.own_mac, self.gw_ip, cmac, tpa, op=1)
            except Exception as e:
                tlog('sniff', 'sniffer error: %s — rebinding' % e, 30)
                try:
                    if sniffer is not None:
                        sniffer.close()
                except Exception:
                    pass
                sniffer = None
                bound = None
                time.sleep(1.0)

    def claim_loop(self):
        last_target = 0
        while not self.stop.is_set():
            with self.lock:
                state = self.state
                extra = getattr(self, '_extra_claim', False)
                self._extra_claim = False
            if state == 'full':
                self.claim_burst(2 if extra else 1)
            time.sleep(CLAIM_INTERVAL)
            self.write_state()
            with self.lock:          # re-read AFTER the sleep: a bypass may have happened
                state = self.state
            if state == 'full' and time.time() - last_target >= TARGET_INTERVAL:
                last_target = time.time()
                with self.lock:
                    devs = list(self.devices.items())
                for ip, mac in devs:
                    self.arp_send(self.own_mac, self.gw_ip, mac, ip, op=1)

    def health_loop(self):
        tick = 0
        verify_every = max(1, int(round(10.0 / max(HEALTH_INTERVAL, 1.0))))
        while not self.stop.is_set():
            tick += 1
            iface, gw = default_route()
            route_ok = bool(iface and gw and gw != '0.0.0.0')
            cur_ip = None
            if route_ok:
                try:
                    cur_ip = if_ip(iface)
                except Exception:
                    cur_ip = None
            # Relearn on ANY material change — gateway, interface, or our own
            # DHCP address — from any state. A stale own_ip otherwise strands a
            # bypassed daemon forever (its probe targets an address it no longer has).
            changed = route_ok and (
                iface != self.iface or gw != self.gw_ip
                or (cur_ip and cur_ip != self.own_ip))
            if changed:
                now = time.time()
                if now >= getattr(self, '_next_relearn', 0):
                    log('network changed: iface=%s ip=%s gw=%s (was %s/%s/%s) — relearning'
                        % (iface, cur_ip, gw, self.iface, self.own_ip, self.gw_ip))
                    self._next_relearn = now + 5
                    self.go_full()
            if not route_ok and not getattr(self, '_route_lost', False):
                self._route_lost = True
                log('default route is gone — waiting for the network to come back')
            elif route_ok:
                self._route_lost = False

            probe_ip = self.own_ip or cur_ip or '127.0.0.1'   # LAN path, not just loopback
            ok = route_ok and dns_probe(probe_ip, PROBE_TIMEOUT)
            with self.lock:
                if ok:
                    self.oks += 1
                    self.fails = 0
                else:
                    self.fails += 1
                    self.oks = 0
                fails, oks, state = self.fails, self.oks, self.state
            if state in ('wait', 'error') and oks >= OK_N:
                # 'error' must not latch: a boot-time WAN/DNSSEC failure would
                # otherwise leave the box unfiltered forever.
                self.go_full()
            elif state in ('wait', 'error') and fails >= FAIL_N * 5 and self.reason != 'setup':
                # resolver dead after setup: don't sit silently in 'wait'
                self.set_state('error', 'filter engine not answering')
            elif state == 'full' and fails >= FAIL_N:
                self.go_bypass('health probe failed %dx' % fails)
            elif state == 'bypass':
                # keep the LAN pointed at the real router while bypassed; also
                # refreshes a silently-changed router MAC every 10 s
                if time.time() - getattr(self, '_last_bypass_corr', 0) > 10:
                    self._last_bypass_corr = time.time()
                    threading.Thread(target=self.corrections, args=(1,), daemon=True).start()
                if oks >= OK_N:
                    self.go_full()

            with self.lock:
                state = self.state
            # Release retry whenever we intend to be released. No route_ok gate:
            # the net script remembers its interface from apply time, so removal
            # must still be attempted after the default route disappears.
            if state != 'full' and not getattr(self, '_released', True):
                if self.net('remove'):
                    self._released = True
                    self.write_state()
                    log('release completed on retry')
                else:
                    tlog('relretry', 'release retry failed — will retry', 60)
            if state == 'full':
                # A router MAC change while full leaves kernel neighbour entries
                # REACHABLE on the old MAC: every forwarded packet blackholes while
                # the UI says covered. Probe actively every ~10 s and repair.
                if tick % 5 == 0:
                    fresh = self._refresh_gw_mac(force=True)
                    with self.lock:
                        old = self.gw_mac
                    if fresh and old and fresh != old:
                        log('gateway MAC changed: %s -> %s — repairing' % (old, fresh))
                        try:
                            # nud reachable (not permanent): the kernel must still be
                            # able to revalidate this entry if the router changes again.
                            subprocess.run(['ip', 'neigh', 'replace', str(self.gw_ip),
                                            'lladdr', str(fresh), 'dev', str(self.iface),
                                            'nud', 'reachable'],
                                           capture_output=True, timeout=5)
                        except Exception:
                            pass
                        with self.lock:
                            self.gw_mac = fresh
                        self.claim_burst(1)
                # forwarding off (a third party wrote ip_forward=0) blackholes the
                # LAN even though our rules are intact — judge only by /proc.
                if _read_fwd() == '1':
                    self._fwd_fail = 0
                else:
                    self.net('apply')
                    if _read_fwd() == '1':
                        self._fwd_fail = 0
                        self.claim_burst(1)
                    else:
                        self._fwd_fail = getattr(self, '_fwd_fail', 0) + 1
                        tlog('fwd', 'could not restore ip_forward (%d)' % self._fwd_fail, 30)
                        if self._fwd_fail >= 3:
                            self.go_bypass('cannot restore ip_forward')
                            with self.lock:
                                state = self.state   # bypass now: never verify/apply below
                if state == 'full' and tick % verify_every == 0:
                    if not self.net('verify'):
                        log('capture rules missing/partial — reapplying')
                        if not self.net('apply'):
                            self.go_bypass('could not restore capture rules')
                        else:
                            self.claim_burst(1)
            time.sleep(HEALTH_INTERVAL)
            sd_notify('WATCHDOG=1')   # health loop is the critical path, not the claim loop

    def run(self):
        os.makedirs(RUN_DIR, exist_ok=True)
        self.set_state('wait', 'starting')
        # Tell systemd we started immediately: claim follows as soon as the
        # resolver answers (no customer action gates filtering).
        sd_notify('READY=1')
        if not self.setup_iface():
            log('interface/gateway setup failed — exiting (route=%s gw_mac=%s)' % (self.iface, self.gw_mac))
            self.set_state('error', 'setup failed')
            return 2
        log('iface=%s own=%s gw=%s (%s) v%s' % (self.iface, self.own_ip, self.gw_ip, self.gw_mac, VERSION))
        threading.Thread(target=self.learn_loop, daemon=True).start()
        threading.Thread(target=self.claim_loop, daemon=True).start()
        sd_notify('WATCHDOG=1')
        try:
            self.health_loop()
        finally:
            self.shutdown()
        return 0

    def shutdown(self):
        self.stop.set()
        log('shutting down — releasing claim')
        if self.state == 'full':
            self.corrections(3, force=True)
        ok = self.net('remove')
        self._released = bool(ok)
        self.set_state('off' if ok else 'error',
                       'stopped' if ok else 'release incomplete')
        try:
            if self.raw:
                self.raw.close()
        except Exception:
            pass


def do_restore():
    """One-shot: corrections + rules off. Safe even if the daemon is dead — but
    refuses to run while a live daemon owns the lock (stripping its rules silently
    would disable filtering while the box keeps claiming)."""
    os.makedirs(RUN_DIR, exist_ok=True)
    try:
        lk = open(os.path.join(RUN_DIR, 'lock'), 'w')
        fcntl.flock(lk, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        log('a live daemon is running — refusing to strip its rules (use systemctl stop)')
        return 4
    c = Cover()
    if c.setup_iface():
        with c.lock:
            c.devices = arp_devices(exclude=(c.gw_ip, c.own_ip))
        c.corrections(3, force=True)
    else:
        log('restore: no route — skipping ARP corrections')
    rc = c.net('remove')
    try:
        os.makedirs(RUN_DIR, exist_ok=True)
        tmp = STATE_FILE + '.tmp'
        with open(tmp, 'w') as f:
            json.dump({'state': 'off' if rc else 'error',
                       'reason': 'restore' if rc else 'restore incomplete',
                       'devices': 0, 'released': bool(rc),
                       'ts': int(time.time()), 'since': int(time.time()),
                       'version': VERSION}, f)
        os.replace(tmp, STATE_FILE)
    except Exception:
        pass
    return 0 if rc else 1


def do_status():
    try:
        with open(STATE_FILE) as f:
            print(f.read())
    except Exception:
        print(json.dumps({'state': 'unknown'}))
    return 0


def main():
    # release/status paths must work even if the feature is configured off
    if '--restore' in sys.argv:
        return do_restore()
    if '--status' in sys.argv:
        return do_status()
    if os.environ.get('FB_COVER', '1') not in ('1', 'yes', 'true', 'on'):
        log('disabled via FB_COVER env')
        return 0

    os.makedirs(RUN_DIR, exist_ok=True)
    lock = open(os.path.join(RUN_DIR, 'lock'), 'w')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        log('another instance is running')
        return 3

    c = Cover()

    def _sig(_signum, _frame):
        c.stop.set()

    signal.signal(signal.SIGTERM, _sig)
    signal.signal(signal.SIGINT, _sig)
    return c.run()


if __name__ == '__main__':
    sys.exit(main())
