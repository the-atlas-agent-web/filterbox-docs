#!/usr/bin/env python3
"""fb-diag — anonymous diagnostic reports for the FilterBox.

What it collects (only if the owner opted in):
  * versions, model, kernel, uptime, memory, disk
  * service states and restart counts for FilterBox units
  * coverage-engine state, firewall rule counts, IPv4/IPv6/DNS probes
  * OTA state and the last error lines (priority err only) from our units

What it never collects:
  * the query log, blocklists, visited domains, client names or MACs
  * passwords, keys, Wi-Fi credentials, full configuration files
  * raw journal output: only error-level lines, scrubbed

Every report carries a random installation id generated on the box — not derived
from hardware — so reports can be correlated without identifying anyone.

Usage:
  fb-diag.py preview   # print exactly what would be sent
  fb-diag.py send      # send if the owner opted in (rate-limited)
"""
import json
import os
import re
import socket
import subprocess
import sys
import time
import urllib.request

SCHEMA = 1
URL = os.environ.get('FB_DIAG_URL', 'https://diag.maemetrics.com/report')
ROOT = os.environ.get('FB_DIAG_ROOT', '')
LIVE = os.environ.get('FB_OTA_LIVE', '/usr/local/lib/filterbox')
STATE = os.environ.get('FB_DIAG_STATE', '/var/lib/filterbox/diag')
CONF = '/etc/filterbox/diag.conf'
MIN_INTERVAL = int(os.environ.get('FB_DIAG_MIN_INTERVAL', str(20 * 3600)))
MAX_BYTES = 48 * 1024
MAX_ERROR_LINES = 60


def p(path):
    return os.path.join(ROOT, path.lstrip('/')) if ROOT else path


def sh(cmd, timeout=6):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (r.stdout or '').strip()
    except Exception:
        return ''


DOMAIN_RE = re.compile(r'\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,24}\b')
MAC_RE = re.compile(r'\b(?:[0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}\b')
IPV6_RE = re.compile(r'\b(?:[0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}\b')
IPV4_RE = re.compile(r'\b\d{1,3}(?:\.\d{1,3}){3}\b')
HOST_RE = re.compile(r'\b(?:filterbox|DietPi)[a-zA-Z0-9-]*\b')


def scrub(text):
    """Remove anything that could identify a person or their browsing."""
    text = MAC_RE.sub('<mac>', text)
    text = IPV6_RE.sub('<ipv6>', text)
    text = IPV4_RE.sub('<ip>', text)
    text = DOMAIN_RE.sub('<domain>', text)
    text = HOST_RE.sub('<host>', text)
    return text


def enabled():
    conf = p(CONF)
    try:
        for line in open(conf):
            if line.strip().startswith('DIAG_ENABLED='):
                return line.split('=', 1)[1].strip().lower() not in ('0', 'false', 'no', 'off')
    except OSError:
        pass
    return False          # opt-in only: absent means no


def install_id():
    path = os.path.join(p(STATE), 'id')
    try:
        value = open(path).read().strip()
        if value:
            return value
    except OSError:
        pass
    import uuid
    value = uuid.uuid4().hex
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as fh:
        fh.write(value + '\n')
    return value


def services():
    out = {}
    for unit in ('fb-panel', 'fb-cover', 'fb-cover6', 'fb-lan-name', 'pihole-FTL',
                 'avahi-daemon', 'fb-update.timer'):
        state = sh(['systemctl', 'is-active', unit]) or 'unknown'
        restarts = sh(['systemctl', 'show', '-p', 'NRestarts', '--value', unit]) or '?'
        out[unit] = {'active': state, 'restarts': restarts}
    return out


def system():
    mem = {}
    try:
        for line in open('/proc/meminfo'):
            k, v = line.split(':', 1)
            if k in ('MemTotal', 'MemAvailable'):
                mem[k] = int(v.split()[0]) // 1024
    except OSError:
        pass
    try:
        load = open('/proc/loadavg').read().split()[:3]
    except OSError:
        load = []
    try:
        up = float(open('/proc/uptime').read().split()[0])
    except OSError:
        up = 0
    try:
        du = os.statvfs(p('/'))
        disk = {'total_mb': du.f_blocks * du.f_frsize // 1048576,
                'free_mb': du.f_bavail * du.f_frsize // 1048576}
    except OSError:
        disk = {}
    model = ''
    try:
        model = open('/proc/device-tree/model').read().strip('\x00').strip()
    except OSError:
        pass
    version = ''
    try:
        version = open(p(os.path.join(LIVE, 'VERSION'))).read().strip()
    except OSError:
        pass
    return {
        'version': version,
        'model': model,
        'kernel': os.uname().release,
        'uptime_s': int(up),
        'load': load,
        'memory_mb': mem,
        'disk_mb': disk,
    }


def dns_probes():
    """Fixed, well-known names only — never a client's real lookup."""
    def dig(name, rrtype):
        t0 = time.time()
        out = sh(['dig', '+time=2', '+tries=1', '@127.0.0.1', name, rrtype, '+short'])
        return {'answer': out.splitlines()[0] if out else '',
                'ms': int((time.time() - t0) * 1000)}
    probes = {
        'blocked_example': dig('doubleclick.net', 'A'),
        'filtered_example': dig('ads.google.com', 'A'),
        'control_a': dig('example.com', 'A'),
        'control_aaaa': dig('example.com', 'AAAA'),
    }
    probes['blocking_active'] = probes['blocked_example']['answer'] == '0.0.0.0'
    probes['aaaa_filtered'] = probes['control_aaaa']['answer'] == ''
    return probes


def network():
    v4 = sh(['ip', '-4', '-o', 'addr', 'show', 'scope', 'global'])
    v6 = sh(['ip', '-6', '-o', 'addr', 'show', 'scope', 'global'])
    routes4 = sh(['ip', '-4', 'route', 'show', 'default'])
    routes6 = sh(['ip', '-6', 'route', 'show', 'default'])
    return {
        'has_global_ipv4': bool(v4),
        'has_global_ipv6': bool(v6),
        'has_ipv6_default_route': bool(routes6),
        'has_ipv4_default_route': bool(routes4),
        # counts only: addresses themselves are identifying
        'ipv4_addr_count': len(v4.splitlines()),
        'ipv6_addr_count': len(v6.splitlines()),
    }


def coverage():
    try:
        raw = open(p('/run/fb-cover/state.json')).read()
        st = json.loads(raw)
    except Exception:
        return {'state': 'missing'}
    return {k: st.get(k) for k in ('state', 'reason', 'devices', 'released', 'version')}


def firewall():
    def count(table, chain, prefix):
        out = sh(['iptables'] + (['-t', table] if table else []) + ['-S', chain])
        return sum(1 for line in out.splitlines() if prefix in line)
    return {'nat_rules': count('nat', 'PREROUTING', 'FBNAT'),
            'fwd_rules': count(None, 'FORWARD', 'FBFWD'),
            'fwd6_rules': count(None, 'FORWARD', 'FBFWD6')}


def ota_state():
    try:
        st = json.load(open(os.path.join(p(STATE), '..', 'update', 'state.json')))
    except Exception:
        return {}
    return {k: st.get(k) for k in ('installed', 'last_result', 'last_check', 'rolled_back_at')}


def errors():
    fake = os.environ.get('FB_DIAG_JOURNAL_FILE')
    if fake:
        try:
            out = open(fake, errors='replace').read()
        except OSError:
            out = ''
        lines = [scrub(x)[:400] for x in out.splitlines() if x.strip()]
        return lines[-MAX_ERROR_LINES:]
    out = sh(['journalctl', '-u', 'fb-panel', '-u', 'fb-cover', '-u', 'fb-cover6', '-u',
              'fb-lan-name', '-u', 'pihole-FTL', '-u', 'fb-update', '-p', 'err', '--since',
              '-24h', '-o', 'cat', '--no-pager'], timeout=10)
    lines = [scrub(x)[:400] for x in out.splitlines() if x.strip()]
    return lines[-MAX_ERROR_LINES:]


def deep_scrub(value):
    """Final-pass scrubber over every string in the report."""
    if isinstance(value, str):
        return scrub(value)[:400]
    if isinstance(value, list):
        return [deep_scrub(v) for v in value]
    if isinstance(value, dict):
        return {k: deep_scrub(v) for k, v in value.items()}
    return value


def build():
    report = {
        'schema': SCHEMA,
        'install_id': install_id(),
        'generated': int(time.time()),
        'system': system(),
        'services': services(),
        'network': network(),
        'dns': dns_probes(),
        'coverage': coverage(),
        'firewall': firewall(),
        'ota': ota_state(),
        'errors': errors(),
    }
    # Every string field goes through the scrubber, including coverage.reason
    # and ota.last_result (they previously bypassed it).
    report = deep_scrub(report)
    blob = json.dumps(report, ensure_ascii=False).encode()
    if len(blob) > MAX_BYTES:                     # never grow without bound
        report['errors'] = report['errors'][-10:]
        blob = json.dumps(report, ensure_ascii=False).encode()
    return report, blob


def main(argv):
    cmd = argv[1] if len(argv) > 1 else 'preview'
    report, blob = build()
    if cmd == 'preview':
        print(json.dumps(report, indent=1, ensure_ascii=False))
        print('\n%d bytes' % len(blob), file=sys.stderr)
        return 0
    if cmd != 'send':
        print(__doc__)
        return 2
    if not enabled():
        print('diagnostics are not enabled by the owner — nothing sent')
        return 0
    os.makedirs(p(STATE), exist_ok=True)
    stamp = os.path.join(p(STATE), 'last_sent')
    try:
        last = int(open(stamp).read().strip())
    except Exception:
        last = 0
    if time.time() - last < MIN_INTERVAL:
        print('rate-limited: last report %d s ago' % (time.time() - last))
        return 0
    req = urllib.request.Request(URL, data=blob, method='POST',
                                 headers={'Content-Type': 'application/json',
                                          'User-Agent': 'FilterBox-Diag/1'})
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            if resp.status >= 300:
                print('rejected: HTTP %s' % resp.status)
                return 1
    except Exception as e:
        print('send failed: %s' % e)
        return 1
    with open(stamp, 'w') as fh:
        fh.write(str(int(time.time())))
    print('sent %d bytes' % len(blob))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
