#!/usr/bin/env python3
"""fb-cover6.py — IPv6 DNS coverage companion for FilterBox.

Why this exists: fb-cover claims the router's IPv4 address via ARP, but modern
routers also advertise an IPv6 DNS server (RDNSS in Router Advertisements), and
operating systems prefer IPv6. Queries to that address never reach the box, so
the home looks "filtered" while browsers resolve through the router.

Mechanism (proven in tests/netns/ipv6-coverage-test.sh):
  1. Listen for Router Advertisements and collect RDNSS addresses.
  2. Claim each (non-link-local) address as /128 `nodad` on the LAN interface:
     the kernel then answers Neighbour Solicitations for it and delivers traffic
     addressed to it to the local resolver (Pi-hole FTL listens on ::).
  3. Announce the claim to known clients with a sourced NS (`ping -6 -I A`),
     which updates their neighbour cache to our MAC.
  4. On release/exit remove the addresses (fail open: clients fall back to the
     router when their NDP cache expires, ~30 s).

Commands: run [--iface IF] | --status | --restore
State: /run/fb-cover6/state.json   Lock: /run/fb-cover6.lock
Stdlib only (the image has no scapy).
"""
import fcntl
import json
import os
import re
import signal
import socket
import struct
import subprocess
import sys
import time

RUN_DIR = os.environ.get('FB_COVER6_RUN_DIR', '/run/fb-cover6')
STATE = os.path.join(RUN_DIR, 'state.json')
LOCK = '/run/fb-cover6.lock'
LOG = os.environ.get('FB_COVER6_LOG', '/var/log/filterbox/cover6.log')
ANNOUNCE_EVERY = float(os.environ.get('FB_COVER6_ANNOUNCE_SEC', '8'))
RA_STALE = float(os.environ.get('FB_COVER6_RA_STALE_SEC', '900'))
MAX_NEIGH = 64

IPPROTO_ICMPV6 = 58
ICMP6_RA = 134
OPT_RDNSS = 25
IPV6_RECVPKTINFO = 49
IPV6_RECVHOPLIMIT = 51
IPV6_HOPLIMIT = 52
RA_OPT_LIFETIME_ZERO = 0

stop = False


def log(msg):
    line = '%s %s\n' % (time.strftime('%Y-%m-%dT%H:%M:%S'), msg)
    try:
        os.makedirs(os.path.dirname(LOG), exist_ok=True)
        with open(LOG, 'a') as f:
            f.write(line)
    except Exception:
        pass
    sys.stderr.write(line)


def run(cmd, timeout=10):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except Exception as e:
        log('exec failed %r: %s' % (cmd, e))
        return None


def default_iface():
    """LAN interface = the one carrying the IPv4 default route (same as fb-cover)."""
    try:
        with open('/proc/net/route') as f:
            for line in f.readlines()[1:]:
                p = line.split()
                if len(p) > 2 and p[1] == '00000000' and int(p[2], 16) != 0:
                    return p[0]
    except Exception:
        pass
    return None


def iface_index(iface):
    try:
        return socket.if_nametoindex(iface)
    except Exception:
        return 0


def claimed_addrs(iface):
    r = run(['ip', '-6', 'addr', 'show', 'dev', iface, 'scope', 'global'])
    out = set()
    if not r or r.returncode != 0:
        return out
    for m in re.finditer(r'inet6\s+([0-9a-fA-F:]+)/128', r.stdout):
        out.add(m.group(1))
    return out


def add_addr(iface, addr):
    if addr in claimed_addrs(iface):
        return True
    r = run(['ip', '-6', 'addr', 'add', addr + '/128', 'dev', iface, 'nodad'])
    ok = bool(r and r.returncode == 0)
    log('claim %s on %s: %s' % (addr, iface, 'ok' if ok else (r.stderr.strip() if r else 'exec failed')))
    return ok


def del_addr(iface, addr):
    r = run(['ip', '-6', 'addr', 'del', addr + '/128', 'dev', iface])
    log('release %s on %s: rc=%s' % (addr, iface, r.returncode if r else 'exec failed'))


def neighbours(iface):
    r = run(['ip', '-6', 'neigh', 'show', 'dev', iface])
    out = []
    if not r or r.returncode != 0:
        return out
    for line in r.stdout.splitlines():
        p = line.split()
        if not p:
            continue
        addr = p[0]
        if addr.startswith('fe80') or addr.startswith('ff'):   # skip link-local/multicast
            continue
        if 'FAILED' in line or 'INCOMPLETE' in line:
            continue
        out.append(addr)
        if len(out) >= MAX_NEIGH:
            break
    return out


def iface_mac(iface):
    try:
        return bytes.fromhex(open('/sys/class/net/%s/address' % iface).read().strip().replace(':', ''))
    except Exception:
        return None


def announce_na(iface, addr):
    """Unsolicited NA for addr to all-nodes: flips every client's cache at once.

    This is the IPv6 analogue of the gratuitous ARP claim. Binding the raw
    socket to the claimed address makes the kernel use it as the source.
    """
    mac = iface_mac(iface)
    if not mac:
        return
    idx = socket.if_nametoindex(iface)
    s = None
    try:
        s = socket.socket(socket.AF_INET6, socket.SOCK_RAW, IPPROTO_ICMPV6)
        s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_MULTICAST_HOPS, 255)
        s.bind((addr, 0, 0, idx))
        # NA: type 136, code 0, checksum (kernel fills for raw ICMPv6),
        # flags = Override (0x20000000), target address, TLLA option.
        body = struct.pack('!BBH', 136, 0, 0)
        body += struct.pack('!I', 0x20000000)
        body += socket.inet_pton(socket.AF_INET6, addr)
        body += struct.pack('!BB', 2, 1) + mac
        s.sendto(body, ('ff02::1', 0, 0, idx))
    except Exception as e:
        log('NA announce %s failed: %s' % (addr, e))
    finally:
        if s:
            try:
                s.close()
            except Exception:
                pass


def announce(iface, addr):
    """Multicast NA (all clients) + unicast NS to known neighbours (belt+braces)."""
    # Burst: the router may answer a client's NS at the same time; send a few
    # NAs back-to-back so the box wins the race at least once.
    for _ in range(3):
        announce_na(iface, addr)
        time.sleep(0.15)
    for t in neighbours(iface):
        run(['ping', '-6', '-I', addr, '-c', '1', '-W', '1', t], timeout=3)


def default_v6_gateways():
    """Link-local addresses of the kernel's IPv6 default gateway(s).

    An RA is only trusted when it comes from this set: accepting any link-local
    source lets a LAN host advertise an RDNSS we then claim, or withdraw the
    real one so filtering silently stops while the panel still says Covered.
    """
    try:
        out = subprocess.run(['ip', '-6', 'route', 'show', 'default'],
                             capture_output=True, text=True, timeout=5).stdout
        return set(re.findall(r'via (fe80:[0-9a-fA-F:]+)', out))
    except Exception:
        return set()


def parse_ra(data, ifindex):
    """Return (rdnss_addresses, withdrawn_addresses, lifetime) from an RA."""
    if len(data) < 16 or data[0] != ICMP6_RA:
        return [], [], 0
    # ICMPv6 header: type, code, cksum, cur hop limit, flags, router lifetime(2),
    # reachable(4), retrans(4); options follow at offset 16.
    router_lifetime = struct.unpack('!H', data[6:8])[0]
    off = 16
    addrs = []
    withdrawn = []
    life = 0
    while off + 2 <= len(data):
        otype = data[off]
        olen = data[off + 1] * 8
        if olen == 0 or off + olen > len(data):
            break
        if otype == OPT_RDNSS and olen >= 24:
            lifetime = struct.unpack('!I', data[off + 4:off + 8])[0]
            n = (olen - 8) // 16
            for i in range(n):
                a = socket.inet_ntop(socket.AF_INET6, data[off + 8 + i * 16: off + 24 + i * 16])
                if lifetime > 0:
                    addrs.append(a)
                    life = lifetime
                else:
                    withdrawn.append(a)      # RDNSS withdrawn: stop claiming
        off += olen
    return addrs, withdrawn, life or router_lifetime


def write_state(state, iface, addrs, extra=None):
    os.makedirs(RUN_DIR, exist_ok=True)
    doc = {'state': state, 'iface': iface, 'addrs': sorted(addrs),
           'ts': int(time.time())}
    if extra:
        doc.update(extra)
    tmp = STATE + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(doc, f)
    os.replace(tmp, STATE)


def restore(iface=None):
    iface = iface or default_iface()
    if not iface:
        return 1
    for a in claimed_addrs(iface):
        del_addr(iface, a)
    write_state('off', iface, set())
    return 0


def service_loop(iface=None):
    global stop
    iface = iface or default_iface()
    if not iface:
        log('no default-route interface — waiting')
        write_state('wait', '', set())
        return 2

    os.makedirs(RUN_DIR, exist_ok=True)
    lockf = open(LOCK, 'w')
    try:
        fcntl.flock(lockf, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except Exception:
        log('another instance holds %s — exiting' % LOCK)
        return 3

    sock = socket.socket(socket.AF_INET6, socket.SOCK_RAW, IPPROTO_ICMPV6)
    sock.setsockopt(socket.IPPROTO_IPV6, IPV6_RECVPKTINFO, 1)
    sock.setsockopt(socket.IPPROTO_IPV6, IPV6_RECVHOPLIMIT, 1)
    sock.settimeout(2.0)
    try:
        sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 1)
    except Exception:
        pass

    seen = {}          # addr -> last RA time
    claimed = set()
    last_announce = 0.0
    log('starting on %s' % iface)
    write_state('wait', iface, set())

    def on_term(signum, frame):
        global stop
        stop = True
    signal.signal(signal.SIGTERM, on_term)
    signal.signal(signal.SIGINT, on_term)

    while not stop:
        now = time.time()
        try:
            data, anc, flags, src = sock.recvmsg(4096, 1024)
            ifindex = 0
            hoplimit = -1
            for level, typ, cdata in anc:
                if level == socket.IPPROTO_IPV6 and typ == IPV6_RECVPKTINFO and len(cdata) >= 4:
                    ifindex = struct.unpack('I', cdata[:4])[0]     # native endian
                elif level == socket.IPPROTO_IPV6 and typ == IPV6_HOPLIMIT and len(cdata) >= 4:
                    hoplimit = struct.unpack('i', cdata[:4])[0]    # native endian
            # RFC 4861: RAs must originate from a link-local address with hop limit 255.
            # Without these checks any LAN host could make us claim an arbitrary address.
            if hoplimit != 255 or not str(src[0]).startswith('fe80'):
                log('RA ignored: src=%s hoplimit=%s' % (src[0], hoplimit))
                continue
            gateways = default_v6_gateways()
            if not gateways:
                log('RA ignored: no IPv6 default route yet')
                continue
            if str(src[0]) not in gateways:
                log('RA ignored: src=%s is not the IPv6 default gateway' % src[0])
                continue
            if ifindex and ifindex != iface_index(iface):
                continue
            addrs, withdrawn, life = parse_ra(data, ifindex)
            for a in withdrawn:
                seen.pop(a, None)
            for a in addrs:
                if a.startswith('fe80'):
                    continue          # link-local RDNSS: unsupported for now
                seen[a] = now
        except socket.timeout:
            pass
        except Exception as e:
            log('RA read error: %s' % e)

        # expire stale advertisements
        for a in list(seen):
            if now - seen[a] > RA_STALE:
                del seen[a]

        # claim new addresses
        for a in sorted(seen):
            if a not in claimed and add_addr(iface, a):
                claimed.add(a)
        # release addresses the router no longer advertises
        for a in sorted(claimed):
            if a not in seen:
                del_addr(iface, a)
                claimed.discard(a)

        if claimed:
            if now - last_announce >= ANNOUNCE_EVERY:
                for a in sorted(claimed):
                    announce(iface, a)
                last_announce = now
            write_state('full' if claimed else 'wait', iface, claimed)
        else:
            write_state('wait', iface, set())

    log('stopping — releasing %d address(es)' % len(claimed))
    for a in sorted(claimed):
        del_addr(iface, a)
    write_state('off', iface, set())
    try:
        sock.close()
    except Exception:
        pass
    return 0


def main():
    args = sys.argv[1:]
    if '--status' in args:
        try:
            with open(STATE) as f:
                print(f.read().strip())
        except Exception:
            print(json.dumps({'state': 'off'}))
        return 0
    if '--restore' in args:
        return restore()
    iface = None
    if '--iface' in args:
        i = args.index('--iface')
        if i + 1 < len(args):
            iface = args[i + 1]
    return service_loop(iface)


if __name__ == '__main__':
    sys.exit(main())
