#!/usr/bin/env python3
"""fb-update — signed over-the-air updates for the FilterBox payload.

Payload only: our scripts, units, data and config assertions. OS, kernel and
Pi-hole packages are deliberately out of scope (those need a reflash or our own
signed .deb tier).

Security model
  * The trust anchor is an ed25519 signature over the manifest, verified with a
    public key baked into the image (/etc/filterbox/ota-pub.pem). TLS is only
    transport: a compromised CDN cannot push code.
  * The manifest pins the bundle's sha256; the bundle is verified before it is
    unpacked, and every tar member is validated (no absolute paths, no `..`,
    no symlinks/hardlinks, no device nodes).
  * Versions must increase. `revoked` in a manifest blocks a known-bad build.
  * Apply is atomic (tmp file + rename), keeps the previous release on disk and
    rolls back automatically when the health check fails.

Usage
  fb-update.py check      # fetch + verify manifest, report, change nothing
  fb-update.py apply      # fetch, verify, install, health check, rollback on fail
  fb-update.py status     # what is installed and when it last ran
  fb-update.py rollback   # go back to the previous release (manual)
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.request

VERSION = '1.0'
BASE = os.environ.get('FB_OTA_BASE', 'https://docs.maemetrics.com/filterbox')
PUBKEY = os.environ.get('FB_OTA_PUBKEY', '/etc/filterbox/ota-pub.pem')
ROOT = os.environ.get('FB_OTA_ROOT', '')          # test sandbox prefix
STATE_DIR = os.environ.get('FB_OTA_STATE', '/var/lib/filterbox/update')
LIVE = os.environ.get('FB_OTA_LIVE', '/usr/local/lib/filterbox')
RELEASES = os.environ.get('FB_OTA_RELEASES', '/opt/filterbox/releases')
UNIT_DIR = os.environ.get('FB_OTA_UNITS', '/etc/systemd/system')
COHORT = os.environ.get('FB_OTA_COHORT', 'pilot')
MAX_MANIFEST = 256 * 1024
MAX_BUNDLE = 32 * 1024 * 1024
ALLOWED_SERVICES = ('fb-panel', 'fb-cover', 'fb-cover6', 'fb-lan-name', 'fb-avahi-alias')


def log(msg):
    line = '%s %s' % (time.strftime('%Y-%m-%dT%H:%M:%S'), msg)
    print(line, flush=True)
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(os.path.join(STATE_DIR, 'update.log'), 'a') as fh:
            fh.write(line + '\n')
    except OSError:
        pass


def root_path(p):
    return os.path.join(ROOT, p.lstrip('/')) if ROOT else p


def fetch(url, limit, timeout=30):
    req = urllib.request.Request(url, headers={'User-Agent': 'FilterBox-OTA/%s' % VERSION})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        if resp.status != 200:
            raise RuntimeError('HTTP %s for %s' % (resp.status, url))
        data = resp.read(limit + 1)
    if len(data) > limit:
        raise RuntimeError('response too large: %s' % url)
    return data


def verify_signature(manifest_bytes, sig_bytes):
    """ed25519 verify with the baked public key. Fail closed."""
    key = root_path(PUBKEY)
    if not os.path.exists(key):
        raise RuntimeError('no OTA public key at %s' % key)
    with tempfile.TemporaryDirectory() as td:
        m = os.path.join(td, 'manifest.json')
        s = os.path.join(td, 'manifest.sig')
        open(m, 'wb').write(manifest_bytes)
        open(s, 'wb').write(sig_bytes)
        r = subprocess.run(['openssl', 'pkeyutl', '-verify', '-rawin', '-pubin', '-inkey', key,
                            '-in', m, '-sigfile', s], capture_output=True, text=True)
    return r.returncode == 0


def vtuple(v):
    parts = []
    for p in str(v).split('.'):
        num = ''.join(ch for ch in p if ch.isdigit())
        parts.append(int(num or 0))
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def read_state():
    p = os.path.join(root_path(STATE_DIR), 'state.json')
    try:
        return json.load(open(p))
    except Exception:
        return {}


def write_state(**kw):
    d = read_state()
    d.update(kw)
    path = root_path(STATE_DIR)
    os.makedirs(path, exist_ok=True)
    tmp = os.path.join(path, '.state.tmp')
    with open(tmp, 'w') as fh:
        json.dump(d, fh, indent=1)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, os.path.join(path, 'state.json'))


def updates_enabled():
    """The wizard/Settings choice. Missing file means enabled (pilot default)."""
    conf = root_path('/etc/filterbox/ota.conf')
    try:
        for line in open(conf):
            if line.strip().startswith('UPDATE_ENABLED='):
                return line.split('=', 1)[1].strip().lower() not in ('0', 'false', 'no', 'off')
    except OSError:
        pass
    return True


def current_version():
    st = read_state()
    if st.get('installed'):
        return st['installed']
    try:
        return open(os.path.join(root_path(LIVE), 'VERSION')).read().strip()
    except OSError:
        return '0.0.0'


def safe_extract(blob, dest):
    """Extract a .tar.xz into dest after validating every member."""
    os.makedirs(dest, exist_ok=True)
    with tempfile.NamedTemporaryFile(suffix='.tar.xz', delete=False) as tf:
        tf.write(blob)
        tmp = tf.name
    try:
        with tarfile.open(tmp, 'r:xz') as tf:
            for m in tf.getmembers():
                name = m.name
                if name.startswith('/') or '..' in name.split('/'):
                    raise RuntimeError('unsafe path in bundle: %s' % name)
                if m.issym() or m.islnk() or m.isdev() or m.isfifo():
                    raise RuntimeError('unsupported member type: %s' % name)
                if not (m.isfile() or m.isdir()):
                    raise RuntimeError('unsupported member: %s' % name)
            tf.extractall(dest)
    finally:
        os.unlink(tmp)


def install_files(src_dir, backup_dir):
    """Copy payload/ + units/ over the live tree atomically; returns touched files."""
    touched = []
    os.makedirs(backup_dir, exist_ok=True)
    for sub, target in (('payload', LIVE), ('units', UNIT_DIR)):
        base = os.path.join(src_dir, sub)
        if not os.path.isdir(base):
            continue
        for name in sorted(os.listdir(base)):
            src = os.path.join(base, name)
            if not os.path.isfile(src):
                continue
            dst = os.path.join(root_path(target), name)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            if os.path.exists(dst):
                shutil.copy2(dst, os.path.join(backup_dir, name))
            tmp = dst + '.fbnew'
            shutil.copy2(src, tmp)
            os.chmod(tmp, 0o755 if name.endswith(('.sh', '.py')) else 0o644)
            os.replace(tmp, dst)
            touched.append((name, dst))
    return touched


def apply_config(src_dir):
    """Idempotent assertions on files we own. Never replaces a whole config."""
    path = os.path.join(src_dir, 'config.json')
    if not os.path.exists(path):
        return []
    spec = json.load(open(path))
    changes = []
    toml = root_path(spec.get('pihole_toml', '/etc/pihole/pihole.toml'))
    lines = spec.get('dnsmasq_lines') or []
    if lines and os.path.exists(toml):
        text = open(toml).read()
        import re
        m = re.search(r'^(\s*dnsmasq_lines\s*=\s*)\[(.*?)\]', text, re.M | re.S)
        if not m:
            raise RuntimeError('dnsmasq_lines not found in %s' % toml)
        existing = [x.strip().strip('"\'') for x in m.group(2).split(',') if x.strip()]
        wanted = existing + [x for x in lines if x not in existing]
        if wanted != existing:
            new = m.group(1) + '[' + ', '.join('"%s"' % x for x in wanted) + ']'
            open(toml + '.fbnew', 'w').write(text[:m.start()] + new + text[m.end():])
            os.replace(toml + '.fbnew', toml)
            changes.append('dnsmasq_lines += %s' % ', '.join(x for x in lines if x not in existing))
    return changes


def restart_services():
    if ROOT:
        return []
    done = []
    for unit in ALLOWED_SERVICES:
        r = subprocess.run(['systemctl', 'restart', unit], capture_output=True, text=True, timeout=90)
        if r.returncode == 0:
            done.append(unit)
    return done


def dns_ok():
    import socket, struct
    q = b'\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00' + b'\x07example\x03com\x00' + b'\x00\x01\x00\x01'
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(3)
        s.sendto(q, ('127.0.0.1', 53))
        data, _ = s.recvfrom(512)
        s.close()
        return len(data) > 12 and data[2] & 0x80  # QR set
    except Exception:
        return False


def http_ok(port=80):
    import socket
    try:
        s = socket.create_connection(('127.0.0.1', port), timeout=3)
        s.sendall(b'GET /api/health HTTP/1.0\r\nHost: localhost\r\n\r\n')
        data = s.recv(256)
        s.close()
        return b'200' in data.split(b'\r\n')[0]
    except Exception:
        return False


def health_check(seconds=90):
    forced = os.environ.get('FB_OTA_HEALTH')
    if forced == 'ok':
        return True
    if forced == 'fail':
        return False
    deadline = time.time() + seconds
    while time.time() < deadline:
        if dns_ok() and http_ok():
            return True
        time.sleep(3)
    return False


def rollback(prev, backup_dir):
    log('rolling back to %s' % prev)
    if os.path.isdir(backup_dir):
        for name in os.listdir(backup_dir):
            src = os.path.join(backup_dir, name)
            dst = os.path.join(root_path(LIVE), name)
            shutil.copy2(src, dst)
    restart_services()
    write_state(installed=prev, rolled_back_at=int(time.time()))
    return 0


def cmd_check(apply_changes=False):
    if not updates_enabled():
        log('automatic updates are disabled by the owner — nothing to do')
        return 0
    cur = current_version()
    try:
        manifest_bytes = fetch(BASE + '/update.json', MAX_MANIFEST)
        sig = fetch(BASE + '/update.json.sig', 4096)
    except Exception as e:
        log('check failed: %s' % e)
        return 2
    if not verify_signature(manifest_bytes, sig):
        log('SIGNATURE INVALID — refusing (fail closed)')
        return 3
    man = json.loads(manifest_bytes)
    new = str(man.get('version', '0'))
    if new in (man.get('revoked') or []):
        log('version %s is revoked by the manifest — refusing' % new)
        return 4
    if vtuple(new) <= vtuple(cur):
        log('up to date (%s)' % cur)
        write_state(last_check=int(time.time()), last_result='up-to-date')
        return 0
    floor = str(man.get('min_version', '0'))
    if vtuple(cur) < vtuple(floor):
        log('installed %s is older than min_version %s — manual reflash required' % (cur, floor))
        return 5
    cohort = man.get('cohort', 'all')
    if cohort not in ('all', COHORT):
        log('version %s is for cohort %r, this unit is %r — skipping' % (new, cohort, COHORT))
        write_state(last_check=int(time.time()), last_result='cohort-skip')
        return 0
    log('update available: %s -> %s (%s)' % (cur, new, man.get('notes', '')[:120]))
    if not apply_changes:
        return 0
    try:
        blob = fetch(man['url'], MAX_BUNDLE)
    except Exception as e:
        log('download failed: %s' % e)
        return 6
    if hashlib.sha256(blob).hexdigest() != man['sha256']:
        log('BUNDLE HASH MISMATCH — refusing')
        return 7
    rel = os.path.join(root_path(RELEASES), new)
    shutil.rmtree(rel, ignore_errors=True)
    safe_extract(blob, rel)
    backup = os.path.join(rel, '_backup')
    touched = install_files(rel, backup)
    changes = apply_config(rel)
    log('installed %d files%s' % (len(touched), ('; ' + '; '.join(changes)) if changes else ''))
    restart_services()
    if not health_check():
        log('HEALTH CHECK FAILED after update')
        return rollback(cur, backup)
    write_state(installed=new, installed_at=int(time.time()), last_result='ok',
                previous=cur, last_check=int(time.time()))
    log('update complete: %s' % new)
    return 0


def main(argv):
    cmd = argv[1] if len(argv) > 1 else 'check'
    if cmd == 'check':
        return cmd_check(False)
    if cmd == 'apply':
        return cmd_check(True)
    if cmd == 'status':
        st = read_state()
        print(json.dumps({'version': current_version(), **st}, indent=1))
        return 0
    if cmd == 'rollback':
        st = read_state()
        prev = st.get('previous')
        if not prev:
            print('no previous release recorded')
            return 1
        return rollback(prev, os.path.join(root_path(RELEASES), st.get('installed', ''), '_backup'))
    print(__doc__)
    return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv))
