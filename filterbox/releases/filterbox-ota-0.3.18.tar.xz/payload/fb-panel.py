#!/usr/bin/python3
# FilterBox Panel — the product's single front door on :80 (filterbox.local).
#
# Two modes, one service:
#   CLAIM MODE     (no /etc/filterbox/wizard-done): the optional dashboard setup.
#                  Filtering is ALREADY running — this page only creates the
#                  dashboard password. Closing it changes nothing.
#   DASHBOARD MODE (marker present): the FilterBox dashboard; live stats come
#     from the local FTL REST API (Pi-hole/FTL are the backend engine).
#
# Supersedes fb-wizard.py (which stays in-tree until the v0.1.5 cutover so the
# existing wizard test-suite remains meaningful; API surface stays compatible).
#
# Endpoints:
#   GET  /                 → claim page (unclaimed) / dashboard (claimed)
#   GET  /settings         → settings page (dashboard mode; 302 → / when unclaimed)
#   GET  /api/status       → JSON: hostname, IPs, links, wifi, probes, done flag
#   GET  /api/panel/stats  → dashboard payload (summary + history + top + blocking)
#   POST /api/password     → {password}          → pihole setpassword (min 8 chars)
#   GET  /api/wifi/scan    → JSON list of SSIDs (only when a wifi device exists)
#   POST /api/wifi/connect → {ssid, psk}         → wpa_supplicant + dhcp (best effort)
#   POST /api/finish       → requires password set → marker + detached finisher
#   GET  /api/health       → {ok:true} (for the image tests)
#
# M2 panel actions (dashboard mode only; session cookie + CSRF token + Origin/Host check):
#   POST /api/panel/login    → {password} → Set-Cookie + {token}
#   POST /api/panel/logout   → drop the session
#   POST /api/panel/pause    → {minutes: 30|60|"indefinite"} → FTL blocking disable
#   POST /api/panel/resume   → FTL blocking enable
#   POST /api/panel/password → {current,new} → pihole setpassword + secret sync
#   POST /api/panel/reboot   → detached reboot
#   POST /api/panel/reset    → {password,confirm:"RESET"} → factory reset (spec §6.1)
#
# CLI:  fb-panel.py --check   → print the status JSON and exit (used by firstboot/QA)
#
# All actions idempotent; every failure path returns a JSON error the UI can
# show, never a crash.
import json, os, re, secrets, socket, struct, subprocess, sys, threading, time, html, hmac, sqlite3, fcntl
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, urlencode

VERSION = '0.0.0'
def _version():
    import re as _re
    # The OTA payload version is the installed truth; build-manifest is the
    # image base and only a fallback (a reflashed box has no payload VERSION).
    for path, pat in (('/usr/local/lib/filterbox/VERSION', r'(\S+)'),
                      ('/etc/filterbox/build-manifest', r'filterbox_ver=(\S+)'),
                      ('/root/filterbox-build/VERSION', r'(\S+)')):
        try:
            m = _re.search(pat, open(path).read())
            if m: return m.group(1)
        except Exception:
            pass
    return '0.0.0'
VERSION = _version()
DONE_MARKER = os.environ.get('FB_DONE_MARKER', '/etc/filterbox/wizard-done')
SETUP_ACTIVE = os.environ.get('FB_SETUP_ACTIVE', '/run/filterbox/setup-active')


def mark_setup_active():
    """Tell fb-update a customer is in the wizard; it defers updates while fresh.

    An update restarts fb-panel and would drop the customer's step and typed
    password mid-configuration. The wizard heartbeats /api/ping every 30 s, so
    the marker stays fresh for as long as the page is open.
    """
    try:
        os.makedirs(os.path.dirname(SETUP_ACTIVE), exist_ok=True)
        with open(SETUP_ACTIVE, 'a'):
            pass
        os.utime(SETUP_ACTIVE, None)
    except Exception:
        pass


def clear_setup_active():
    try:
        os.remove(SETUP_ACTIVE)
    except Exception:
        pass
PORT = int(os.environ.get('FB_PANEL_PORT', os.environ.get('FB_WIZARD_PORT', '80')))
LOG = '/var/log/filterbox/wizard.log'
SETUP_STATE = '/etc/filterbox/wizard-state.json'   # {"password_set": bool}
PROBE_BLOCKED = 'doubleclick.net'      # expected 0.0.0.0 when the filter is live
PROBE_CLEAN = 'example.com'

# FTL backend API — Pi-hole/FTL are the engine; this panel is the face.
FTL_HOST = os.environ.get('FB_FTL_HOST', '127.0.0.1')
FTL_PORT = int(os.environ.get('FB_FTL_PORT', '8089'))
FTL_SECRET = '/etc/filterbox/panel-ftl.secret'     # password copy for API auth (0600)
NEEDS_SETUP = '/etc/filterbox/needs-setup'          # factory-reset box waiting for the customer
RESET_STATE = '/etc/filterbox/resetting'            # reset in progress: old secret is not proof

# Panel sessions (M2): HttpOnly cookie + CSRF double-submit + login backoff.
SESSION_COOKIE = 'fb_session'
SESSION_TTL = 1800              # 30-min sliding expiry
SESSION_MAX = 12 * 3600         # absolute session lifetime
_sessions = {}                  # token -> {'exp','created','ip'}
_sess_lock = threading.Lock()
_login_fail = {}              # ip -> [fail_count, blocked_until]

os.makedirs('/var/log/filterbox', exist_ok=True)
_lock = threading.Lock()
_rl = {}   # ip -> [timestamps]

def log(msg):
    line = time.strftime('%Y-%m-%dT%H:%M:%S ') + msg
    try:
        with open(LOG, 'a') as f: f.write(line + '\n')
    except Exception: pass
    print(line, flush=True)

def sh(cmd, timeout=30, input=None):
    """Run a command, never raise; return (rc, stdout, stderr)."""
    try:
        p = subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True,
                           text=True, timeout=timeout, input=input)
        return p.returncode, p.stdout.strip(), p.stderr.strip()
    except Exception as e:
        return 1, '', str(e)

def state():
    try:
        with open(SETUP_STATE) as f: return json.load(f)
    except Exception:
        return {'password_set': False}

def save_state(st):
    tmp = SETUP_STATE + '.tmp'
    with open(tmp, 'w') as f: json.dump(st, f)
    os.replace(tmp, SETUP_STATE)

def json_state():
    """Everything the wizard UI shows, in one payload. Read-only."""
    out = {'done': os.path.exists(DONE_MARKER), 'version': VERSION,
           'password_set': state().get('password_set', False),
           'hostname': socket.gethostname(), 'ips': [], 'ethernet': [], 'wifi': [],
           'protection': {'active': False, 'blocked_example': PROBE_BLOCKED, 'detail': ''},
           'coverage': _coverage_state(),
           'internet': {'up': False, 'detail': ''}}
    try:
        for iface in sorted(os.listdir('/sys/class/net')):
            if iface == 'lo': continue
            try:
                carrier = open(f'/sys/class/net/{iface}/carrier').read().strip()
            except OSError:
                # A down interface (eth1 on the R3S is normally down) returns
                # EINVAL for carrier; that must not abort enumeration or leak
                # an errno into the customer status payload.
                carrier = '0'
            addrs = sh(f"ip -4 -o addr show dev {iface} scope global")
            ip = ''
            if addrs[0] == 0:
                m = re.search(r'inet (\d+\.\d+\.\d+\.\d+)', addrs[1])
                ip = m.group(1) if m else ''
            if ip: out['ips'].append({'iface': iface, 'ip': ip})
            ent = {'name': iface, 'carrier': carrier == '1', 'ip': ip}
            if os.path.exists(f'/sys/class/net/{iface}/wireless'):
                st = sh(f'iw dev {iface} link')
                ent['connected'] = (st[0] == 0 and 'Not connected' not in st[1])
                out['wifi'].append(ent)
            elif iface.startswith(('eth', 'en')):
                out['ethernet'].append(ent)
    except Exception as e:
        print(f'iface scan: {e}', file=sys.stderr)
    # filtering probe: ask the LOCAL resolver for a known-bad domain
    for host, key, want_zero in ((PROBE_BLOCKED, 'protection', True), (PROBE_CLEAN, 'internet', False)):
        try:
            ans = dns_a(host, '127.0.0.1')
            if key == 'protection':
                blocked = any(a == '0.0.0.0' for a in ans)
                out['protection']['active'] = blocked
                out['protection']['detail'] = f"{host} → {','.join(ans) if ans else 'no answer'}"
            else:
                out['internet']['up'] = bool(ans)
                out['internet']['detail'] = f"{host} → {','.join(ans) if ans else 'no answer'}"
        except Exception as e:
            if key == 'protection': out['protection']['detail'] = f'probe failed: {e}'
            else: out['internet']['detail'] = f'probe failed: {e}'
    if os.environ.get('FB_DEV_PROTECTION_ACTIVE') == '1':
        # Dev/screenshot harness only; production never sets this.
        out['protection'] = {'active': True, 'blocked_example': PROBE_BLOCKED,
                             'detail': f'{PROBE_BLOCKED} → 0.0.0.0'}
    if os.environ.get('FB_DEV_INTERNET_UP') == '1':
        out['internet'] = {'up': True, 'detail': f'{PROBE_CLEAN} → 203.0.113.10'}
    if os.environ.get('FB_DEV_HOSTNAME'):
        out['hostname'] = os.environ['FB_DEV_HOSTNAME']
    if os.environ.get('FB_DEV_IPS'):
        # Dev/screenshot harness only: show the customer-facing LAN IP, not
        # the host's docker/tailscale interfaces.
        out['ips'] = [{'iface': 'eth0', 'ip': x.strip()}
                      for x in os.environ['FB_DEV_IPS'].split(',') if x.strip()]
        out['ethernet'] = [{'name': 'eth0', 'carrier': True,
                            'ip': out['ips'][0]['ip'] if out['ips'] else ''}]
    return out

def dns_a(host, server, timeout=3.0):
    """Minimal DNS A query (stdlib socket). Raises on failure."""
    tid = struct.pack('>H', os.getpid() & 0xffff)
    flags = struct.pack('>H', 0x0100)
    qname = b''.join(bytes([len(p)]) + p.encode() for p in host.split('.')) + b'\x00'
    pkt = tid + flags + struct.pack('>HHHH', 1, 0, 0, 0) + qname + struct.pack('>HH', 1, 1)
    fam = socket.AF_INET6 if ':' in server else socket.AF_INET
    arg = (server, 53) if fam == socket.AF_INET else (server, 53, 0, 0)
    s = socket.socket(fam, socket.SOCK_DGRAM); s.settimeout(timeout)
    try:
        s.sendto(pkt, arg)
        data, _ = s.recvfrom(2048)
    finally:
        s.close()
    if data[:2] != tid: raise ValueError('tid mismatch')
    ancount = struct.unpack('>H', data[6:8])[0]
    rcode = data[3] & 0x0f
    if rcode == 3: return []          # NXDOMAIN = resolvable answer, no A
    if rcode != 0: raise ValueError(f'rcode={rcode}')
    off = 12
    while True:                       # skip question (labels or compression ptr)
        l = data[off]
        if l == 0: off += 1; break
        if l & 0xc0: off += 2; break
        off += l + 1
    off += 4                          # qtype + qclass
    out = []
    for _ in range(ancount):
        if data[off] & 0xc0 == 0xc0: off += 2
        else:
            while data[off] != 0: off += data[off] + 1
            off += 1
        rtype = struct.unpack('>H', data[off:off+2])[0]; off += 2
        off += 2                      # class
        off += 4                      # ttl
        rdlen = struct.unpack('>H', data[off:off+2])[0]; off += 2
        if rtype == 1 and rdlen == 4:
            out.append('.'.join(str(b) for b in data[off:off+4]))
        off += rdlen
    return out

# ------------------------------------------------------------ FTL backend ---
# Pi-hole/FTL are the engine. The dashboard reads live data via FTL's local
# REST API; sessions are short-lived (~30 min) and renewed transparently.
# Credential: a root-only copy of the admin password (written by the wizard
# finisher), kept in sync whenever the password is changed from the panel.
_ftl_lock = threading.Lock()
_ftl_session = {'sid': '', 'exp': 0.0}

def _ftl_password():
    pw = os.environ.get('FB_FTL_PASSWORD', '')
    if pw: return pw
    try:
        with open(FTL_SECRET) as f: return f.read().strip()
    except Exception:
        return ''

def _ftl_auth():
    pw = _ftl_password()
    if not pw:
        raise RuntimeError('no API credential yet')
    import http.client
    conn = http.client.HTTPConnection(FTL_HOST, FTL_PORT, timeout=8)
    conn.request('POST', '/api/auth', json.dumps({'password': pw}),
                 {'Content-Type': 'application/json'})
    d = json.loads(conn.getresponse().read() or b'{}')
    conn.close()
    sess = d.get('session') or {}
    if not sess.get('valid') or not sess.get('sid'):
        raise RuntimeError(sess.get('message') or 'auth failed')
    with _ftl_lock:
        _ftl_session['sid'] = sess['sid']
        _ftl_session['exp'] = time.time() + max(60, int(sess.get('validity', 1800)) - 120)
    return _ftl_session['sid']

def ftl(path, params=None, method='GET', body=None):
    """Call the FTL API with a live session; re-auth on expiry/401. Raises on failure."""
    import http.client
    for _attempt in (1, 2):
        with _ftl_lock:
            sid = _ftl_session['sid'] if time.time() < _ftl_session['exp'] else ''
        if not sid:
            sid = _ftl_auth()
        qs = ('?' + urlencode(params)) if params else ''
        hdr = {'sid': sid}
        payload = None
        if body is not None:
            payload = json.dumps(body); hdr['Content-Type'] = 'application/json'
        conn = http.client.HTTPConnection(FTL_HOST, FTL_PORT, timeout=8)
        conn.request(method, path + qs, payload, hdr)
        r = conn.getresponse()
        raw = r.read()
        conn.close()
        if r.status == 401 and _attempt == 1:
            with _ftl_lock:
                _ftl_session['sid'] = ''; _ftl_session['exp'] = 0
            continue
        if r.status >= 400:
            raise RuntimeError(f'FTL {path} -> {r.status}')
        return json.loads(raw or b'{}')
    raise RuntimeError('FTL auth loop')

_ftl_auth_transport_error = False

def _ftl_auth_pw(pw):
    """Try ONE auth with the given password; returns sid on success else None.
    Doubles as the login/reset credential check (FTL is the verifier).
    Sets _ftl_auth_transport_error when FTL itself is unreachable, so callers
    can distinguish 'wrong password' from 'engine down'."""
    global _ftl_auth_transport_error
    _ftl_auth_transport_error = False
    if not isinstance(pw, str) or not pw:
        return None
    import http.client
    try:
        conn = http.client.HTTPConnection(FTL_HOST, FTL_PORT, timeout=8)
        conn.request('POST', '/api/auth', json.dumps({'password': pw}),
                     {'Content-Type': 'application/json'})
        d = json.loads(conn.getresponse().read() or b'{}')
        conn.close()
        sess = d.get('session') or {}
        if sess.get('valid') and sess.get('sid'):
            with _ftl_lock:
                _ftl_session['sid'] = sess['sid']
                _ftl_session['exp'] = time.time() + max(60, int(sess.get('validity', 1800)) - 120)
            return sess['sid']
    except Exception as e:
        _ftl_auth_transport_error = True
        log(f'ftl auth probe failed: {e}')
    return None

def _secret_matches(pw):
    """Fallback credential check when FTL is down: compare against our own
    root-only copy. Without this, a dead engine makes the correct password look
    wrong and locks the admin out (six attempts -> 429)."""
    try:
        with open(FTL_SECRET) as f:
            return hmac.compare_digest(str(pw), f.read().strip())
    except Exception:
        return False

def ftl_set_blocking(enable, timer=None):
    """FTL blocking control. Request contract (verified live + OpenAPI):
    boolean `blocking` + optional `timer` in SECONDS (null/omitted = permanent)."""
    return ftl('/api/dns/blocking', method='POST', body={'blocking': bool(enable), 'timer': timer})

def _uptime():
    try:
        return int(float(open('/proc/uptime').read().split()[0]))
    except Exception:
        return 0

# -------------------------------------------------------------- sessions ---
def new_session(ip=''):
    tok = secrets.token_hex(32)
    now = time.time()
    with _sess_lock:
        _sessions[tok] = {'exp': now + SESSION_TTL, 'created': now,
                          'ip': ip_key(ip) if ip else ''}
    return tok

def session_check(tok, ip=''):
    with _sess_lock:
        s = _sessions.get(tok or '')
        now = time.time()
        if not s or now > s['exp']:
            return False
        # Absolute lifetime: a stolen cookie cannot be renewed forever.
        if now > s.get('created', now) + SESSION_MAX:
            return False
        # Bind the session to the client it was issued to.
        if s.get('ip') and ip and ip_key(ip) != s['ip']:
            return False
        s['exp'] = now + SESSION_TTL      # sliding renewal
        return True

def session_drop(tok):
    with _sess_lock:
        _sessions.pop(tok or '', None)

def login_blocked(ip):
    f = _login_fail.get(ip_key(ip))
    return bool(f and time.time() < f[1])

def login_failed(ip):
    key = ip_key(ip)
    with _lock:
        f = _login_fail.get(key) or [0, 0.0]
        f[0] += 1
        if f[0] >= 5:
            f[1] = time.time() + min(900, 60 * (2 ** (f[0] - 5)))
        _login_fail[key] = f
        if len(_login_fail) > 1024:
            now = time.time()
            for k in [k for k, v in _login_fail.items() if now >= v[1]][:512]:
                _login_fail.pop(k, None)
    log(f'login failed from {ip} (count={f[0]})')

def login_ok(ip):
    _login_fail.pop(ip_key(ip), None)

_setup_hits = {}
_setup_hits_lock = threading.Lock()

def ip_key(ip):
    """Group IPv6 clients by /64 — one /64 must not multiply the attempt budget.
    IPv4-mapped IPv6 (::ffff:a.b.c.d, what a dual-stack socket reports for IPv4
    clients) must be keyed as the IPv4 address, or every LAN client shares ::/64."""
    try:
        import ipaddress
        a = ipaddress.ip_address(ip)
        if a.version == 6 and getattr(a, 'ipv4_mapped', None) is not None:
            a = a.ipv4_mapped
        if a.version == 6:
            return str(ipaddress.ip_network((a, 64), strict=False))
        return str(a)
    except Exception:
        return ip

def setup_rate_limited(ip, limit=30, window=60):
    """Setup mode is unauthenticated by nature; at minimum cap the rate so one
    LAN host cannot brute-force/lock the wizard in a loop. IPv6 clients are
    grouped by /64 so rotating privacy addresses does not reset the budget."""
    now = time.time()
    key = ip_key(ip)
    with _setup_hits_lock:
        if len(_setup_hits) > 1024:
            # Prune expired buckets; never wipe the whole limiter (a host with
            # many source addresses could otherwise reset everyone's budget).
            for k in [k for k, v in _setup_hits.items()
                      if not v or now - max(v) >= window]:
                _setup_hits.pop(k, None)
            if len(_setup_hits) > 2048:
                for k in list(_setup_hits)[:1024]:
                    _setup_hits.pop(k, None)
        arr = [t for t in _setup_hits.get(key, []) if now - t < window]
        if len(arr) >= limit:
            _setup_hits[key] = arr
            return True
        arr.append(now)
        _setup_hits[key] = arr
        return False

def _local_host_names():
    names = {'filterbox.local', 'filterbox.lan', 'filterbox', 'localhost', '127.0.0.1', '::1', '0.0.0.0'}
    h = socket.gethostname()
    names.update({h, h + '.local', h + '.lan'})
    try:
        for ip in socket.gethostbyname_ex(h)[2]:
            names.add(ip)
    except Exception:
        pass
    try:
        rc, out, _ = sh('ip -4 -o addr show scope global')
        if rc == 0:
            names.update(re.findall(r'inet (\d+\.\d+\.\d+\.\d+)', out))
        rc, out, _ = sh('ip -6 -o addr show scope global')
        if rc == 0:
            names.update(re.findall(r'inet6 ([0-9a-fA-F:]+)/', out))
    except Exception:
        pass
    return {n.lower() for n in names}

def origin_ok(host_hdr, origin_hdr, fetch_site=None):
    """Host allow-list; when an Origin header is present it must match too.
    Guards the LAN device against DNS-rebinding style cross-origin POSTs.
    Sec-Fetch-Site is honoured when browsers send it (cross-site never passes)."""
    allowed = _local_host_names()
    host = (host_hdr or '').rsplit(':', 1)[0].strip('[]').lower()
    if not host or host not in allowed:
        return False
    if fetch_site and fetch_site.lower() not in ('same-origin', 'none'):
        return False
    if origin_hdr:
        org = (urlparse(origin_hdr).hostname or '').lower()
        if org not in allowed:
            return False
    return True

# --------------------------------------------------------------- actions ---
def _write_secret(pw):
    """Keep the root-only credential copy in sync with the true password
    (written at set-password time, refreshed on every successful login)."""
    try:
        fd = os.open(FTL_SECRET, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'w') as f:
            f.write(pw + '\n')
        return True
    except Exception as e:
        log(f'panel-ftl.secret write failed: {e}')
        return False

def change_password(current, new):
    if not _ftl_auth_pw(current) and not (_ftl_auth_transport_error and _secret_matches(current)):
        return False, "That's not the current password — try again."
    if not isinstance(new, str) or len(new) < 8:
        return False, 'Password must be at least 8 characters.'
    if len(new) > 128:
        return False, 'Password is too long (max 128 characters).'
    rc, _, err = sh(['pihole', 'setpassword', new], timeout=60)
    if rc != 0:
        log(f'setpassword failed rc={rc} err={err[:200]}')
        return False, 'Something went wrong — try again.'
    _write_secret(new)
    with _sess_lock:
        _sessions.clear()                 # a password change revokes every session
    _ftl_auth_pw(new)                     # re-establish the module's FTL session
    log('admin password changed via panel')
    return True, ''

def _services_available():
    return os.path.isdir('/run/systemd/system') and sh(['systemctl', '--version'])[0] == 0

def _spawn_reboot(delay=2):
    if os.environ.get('FB_PANEL_DEV'):
        raise RuntimeError('dev mode — reboot suppressed')
    if not _services_available():
        raise RuntimeError('no systemd here')
    sh(f'setsid /bin/sh -c "sleep {delay}; systemctl reboot" >/dev/null 2>&1 &')

def do_reboot():
    try:
        _spawn_reboot()
        log('reboot requested via panel')
        return True, ''
    except Exception as e:
        log(f'reboot failed: {e}')
        return False, "Couldn't start the restart — check that the box is powered, then try again."

def factory_reset(password, confirm):
    """Spec §6.1: wipe ownership + statistics; filtering keeps running.
    The shell script is the single implementation — the physical RESET button
    (5 s hold) runs the same code, so the two paths cannot drift."""
    if str(confirm).strip() != 'RESET':
        return False, 'Type RESET exactly to confirm.'
    if not _ftl_auth_pw(password) and not (_ftl_auth_transport_error and _secret_matches(password)):
        return False, "That password doesn't match — try again."
    log('factory reset initiated via panel')
    script = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fb-factory-reset.sh')
    if not os.path.exists(script):
        script = '/usr/local/lib/filterbox/fb-factory-reset.sh'
    rc, out, err = sh([script, '--reason', 'panel'], timeout=240)
    if rc != 0:
        log(f'factory reset script rc={rc} err={err[:200]}')
        return False, "Reset couldn't finish — try again."
    # Feedback + a clean slate: the wipe is already complete on disk, so a power
    # cut during this reboot cannot restore the previous owner's credentials.
    try:
        _spawn_reboot(delay=3)
    except Exception as e:
        log(f'reset: reboot failed: {e}')
    return True, ''

_ftl_version_cache = {'v': '', 't': 0.0}

def ftl_version():
    if _ftl_version_cache['v'] and time.time() - _ftl_version_cache['t'] < 3600:
        return _ftl_version_cache['v']
    try:
        d = ftl('/api/info/version')
        v = ((d.get('version') or {}).get('ftl') or {}).get('local') or {}
        _ftl_version_cache['v'] = str(v.get('version') or '')
        _ftl_version_cache['t'] = time.time()
    except Exception:
        pass
    return _ftl_version_cache['v']

def _coverage_state():
    """Read the coverage engine's state file. Independent of FTL: the card must
    still render when the filter API is down — that is exactly when it matters.
    Values are clamped: a corrupt or hostile file must never render 'covered'."""
    try:
        with open('/run/fb-cover/state.json') as f:
            cv = json.load(f)
        now = int(time.time())
        ts = int(cv.get('ts', 0) or 0)
        if ts > now + 60:
            ts = 0            # a future ts must never look fresh (unknown state)
        st = str(cv.get('state', 'unknown'))
        if st not in ('wait', 'full', 'bypass', 'error', 'off', 'unknown'):
            st = 'unknown'
        return {'state': st,
                'reason': str(cv.get('reason', ''))[:120],
                'devices': max(0, min(4096, int(cv.get('devices', 0) or 0))),
                'ts': ts,
                'since': min(int(cv.get('since', 0) or 0), now + 60),
                'released': bool(cv.get('released', True))}
    except Exception:
        return None

def _panel_stats_uncached():
    """One payload for the dashboard. Never raises — reports engine state instead."""
    out = {'version': VERSION, 'engine': {'ok': True, 'error': ''},
           'hostname': socket.gethostname(), 'now': int(time.time()),
           'uptime_seconds': _uptime(), 'ftl_version': ftl_version(),
           'coverage': _coverage_state()}
    try:
        s = ftl('/api/stats/summary')
        q = s.get('queries', {}) or {}
        g = s.get('gravity', {}) or {}
        out['totals'] = {
            'queries': int(q.get('total', 0)),
            'blocked': int(q.get('blocked', 0)),
            'pct': round(float(q.get('percent_blocked', 0.0)), 1),
            'gravity': int(g.get('domains_being_blocked', 0)),
            'unique_domains': int(q.get('unique_domains', 0)),
            'cached': int(q.get('cached', 0)),
            'forwarded': int(q.get('forwarded', 0)),
            'frequency': round(float(q.get('frequency', 0.0)), 2),
        }
        out['types'] = {str(k): int(v) for k, v in (q.get('types') or {}).items()}
        try:
            b = ftl('/api/dns/blocking')
            out['blocking'] = {'status': b.get('blocking', 'unknown'), 'timer': b.get('timer')}
        except Exception:
            out['blocking'] = {'status': 'unknown', 'timer': None}
        now = int(time.time()); frm = now - 7 * 86400
        try:
            # long-term endpoint: /api/history is a fixed trailing-24h set (no
            # params); the true 7-day chart needs /api/history/database (verified)
            h = ftl('/api/history/database', {'from': frm, 'until': now})
            series = h.get('history', []) or []
            if len(series) > 84:                      # downsample to <=84 bars
                k = (len(series) + 83) // 84
                agg = []
                for i in range(0, len(series), k):
                    chunk = series[i:i + k]
                    agg.append({'timestamp': chunk[0].get('timestamp', 0),
                                'blocked': sum(int(c.get('blocked', 0)) for c in chunk),
                                'total': sum(int(c.get('total', 0)) for c in chunk)})
                series = agg
            out['history'] = [{'t': c.get('timestamp', 0), 'b': int(c.get('blocked', 0)),
                               'q': int(c.get('total', 0))} for c in series]
        except Exception as e:
            out['history'] = []; out['history_error'] = str(e)[:120]
        try:
            t = ftl('/api/stats/top_domains', {'blocked': 'true', 'count': 6})
            out['top_blocked'] = [{'domain': d.get('domain', ''), 'count': int(d.get('count', 0))}
                                  for d in (t.get('domains') or [])]
        except Exception:
            out['top_blocked'] = []
        try:
            # trailing-24h set (no params) — feeds the "Today" chart
            h24 = ftl('/api/history')
            out['history24'] = [{'t': int(c.get('timestamp', 0)), 'q': int(c.get('total', 0)),
                                 'b': int(c.get('blocked', 0))} for c in (h24.get('history') or [])]
        except Exception:
            out['history24'] = []
        try:
            ta = ftl('/api/stats/top_domains', {'blocked': 'false', 'count': 6})
            out['top_allowed'] = [{'domain': d.get('domain', ''), 'count': int(d.get('count', 0))}
                                  for d in (ta.get('domains') or [])]
        except Exception:
            out['top_allowed'] = []
        try:
            tc = ftl('/api/stats/top_clients', {'count': 6})
            out['top_clients'] = [{'name': (c.get('name') or c.get('ip') or '?'),
                                   'ip': c.get('ip') or '', 'count': int(c.get('count', 0))}
                                  for c in (tc.get('clients') or [])]
        except Exception:
            out['top_clients'] = []
        try:
            up = ftl('/api/stats/upstreams')
            tot_up = sum(int(u.get('count', 0)) for u in (up.get('upstreams') or []))
            out['upstreams'] = [{'name': u.get('name') or u.get('ip') or '?',
                                 'ip': u.get('ip') or '', 'count': int(u.get('count', 0)),
                                 'pct': round(100.0 * int(u.get('count', 0)) / tot_up, 1) if tot_up else 0.0}
                                for u in (up.get('upstreams') or [])[:4]]
        except Exception:
            out['upstreams'] = []
    except Exception as e:
        out['engine'] = {'ok': False, 'error': str(e)[:160]}
    # liveness probes via the LOCAL resolver (these work even if the API is down)
    try:
        ans = dns_a(PROBE_BLOCKED, '127.0.0.1')
        out['protection_active'] = any(a == '0.0.0.0' for a in ans)
    except Exception:
        out['protection_active'] = None
    try:
        out['internet_up'] = bool(dns_a(PROBE_CLEAN, '127.0.0.1'))
    except Exception:
        out['internet_up'] = None
    if os.environ.get('FB_DEV_INTERNET_UP') == '1':
        # Dev/screenshot harness only; production never sets this.
        out['internet_up'] = True
    cv = out.get('coverage')
    if cv:
        # Coverage exists: "active" requires the engine to be claiming AND fresh.
        # bypass/off/error/wait/unknown all mean the home is not covered, even if
        # FTL still answers this box's own probe.
        fresh = (time.time() - int(cv.get('ts') or 0)) <= 90
        out['protection_active'] = bool(out.get('protection_active')) and \
            cv.get('state') == 'full' and fresh and not bool(cv.get('released', True))
    else:
        # New images always write coverage state; its absence means "unknown",
        # never "active".
        try:
            vv = tuple(int(x) for x in VERSION.split('.')[:2])
        except Exception:
            vv = (0, 0)
        if vv >= (0, 2):
            out['protection_active'] = False
    try:
        h = json.load(open('/run/filterbox/health.json'))
        out['health'] = h if isinstance(h, dict) else None
    except Exception:
        out['health'] = None
    # A collapsed list set or a missing/stale health report must never render
    # "Protection: active". Apply after a setup grace so the first minutes do
    # not flash a false alarm while the health timer is still starting.
    try:
        marker_age = time.time() - os.path.getmtime(DONE_MARKER)
    except Exception:
        marker_age = 0
    h = out.get('health') or {}
    try:
        h_age = time.time() - int(h.get('ts') or 0)
    except Exception:
        h_age = 10 ** 9
    grav = int(((out.get('totals') or {}).get('gravity') or h.get('gravity') or 0) or 0)
    try:
        lists_age = int(h.get('lists_age_days'))
    except Exception:
        lists_age = -1
    out['lists_ok'] = bool(h) and 0 <= h_age < 43200 and grav >= 100000 and lists_age <= 9
    if out.get('protection_active') and marker_age > 900 and not out['lists_ok']:
        out['protection_active'] = False
    try:
        marker_age = time.time() - os.path.getmtime(DONE_MARKER)
    except Exception:
        marker_age = 99999
    out['coverage_starting'] = bool(out.get('coverage') is None and
                                   os.path.exists(DONE_MARKER) and marker_age < 180)
    return out

# ---------------------------------------------------------------- actions ---
_stats_cache = {'ts': 0.0, 'data': None, 'mtime': None}
_stats_cache_lock = threading.Lock()
_stats_compute_lock = threading.Lock()

def _state_mtime():
    try:
        return os.stat('/run/fb-cover/state.json').st_mtime_ns
    except Exception:
        return None

def stats_invalidate():
    with _stats_cache_lock:
        _stats_cache['ts'] = 0
        _stats_cache['data'] = None

def panel_stats():
    """Cached, single-flight wrapper: 40 concurrent dashboard tabs must not turn
    into 40 × (2 DNS probes + 8 FTL calls) and wedge the panel. The coverage
    file's mtime invalidates the cache immediately, so state transitions are
    never hidden behind the TTL."""
    now = time.time()
    mt = _state_mtime()
    with _stats_cache_lock:
        cached = _stats_cache['data']
        if cached is not None and now - _stats_cache['ts'] < 3 and mt == _stats_cache['mtime']:
            return cached
    if not _stats_compute_lock.acquire(timeout=3):
        return cached or {'version': VERSION, 'engine': {'ok': False, 'error': 'busy'},
                          'hostname': socket.gethostname(), 'now': int(now),
                          'uptime_seconds': _uptime(), 'coverage': _coverage_state(),
                          'totals': None, 'protection_active': False}
    try:
        with _stats_cache_lock:
            cached = _stats_cache['data']
            if cached is not None and time.time() - _stats_cache['ts'] < 3 and _state_mtime() == _stats_cache['mtime']:
                return cached
        out = _panel_stats_uncached()
        with _stats_cache_lock:
            _stats_cache['ts'] = time.time()
            _stats_cache['data'] = out
            _stats_cache['mtime'] = _state_mtime()
        return out
    finally:
        _stats_compute_lock.release()

def _reset_token():
    try:
        with open(RESET_STATE) as f:
            return f.read().strip()
    except Exception:
        return ''

CRED_LOCK = '/run/filterbox-credentials.lock'

def set_password(pw):
    if not isinstance(pw, str) or len(pw) < 8:
        return False, 'Password must be at least 8 characters.'
    if len(pw) > 128:
        return False, 'Password is too long (max 128 characters).'
    # Serialize with firstboot's credential step. Its check-then-set window used
    # to race this call: finalize could overwrite the customer's password after
    # they set it (the baked password then wins and the owner is locked out).
    try:
        lk = open(CRED_LOCK, 'a+')
        fcntl.flock(lk.fileno(), fcntl.LOCK_EX)
    except Exception:
        lk = None
    try:
        rc, out, err = sh(['pihole', 'setpassword', pw], timeout=60)
        if rc != 0:
            log(f'setpassword failed rc={rc} err={err[:200]}')
            return False, 'Could not set the password (service not ready?). Try again in a moment.'
        st = state(); st['password_set'] = True
        tok = _reset_token()
        if tok:
            # Prove this password was set AFTER the reset began. A clock step-back made
            # the old mtime comparison reject every new password forever.
            st['reset_token'] = tok  # type: ignore[assignment]
        save_ok = True
        try:
            # Save the state marker BEFORE the secret: firstboot treats either as
            # proof of customer setup, and the state write is the one that closes
            # the check-then-set window even if the panel dies right after this.
            save_state(st)
        except Exception as e:
            save_ok = False
            log(f'password set but state could not be saved: {e}')
        _write_secret(pw)                 # the panel's own FTL API credential copy
        if not save_ok and not os.path.exists(FTL_SECRET):
            return False, 'Could not save the password — check the box and try again.'
    finally:
        if lk is not None:
            try:
                fcntl.flock(lk.fileno(), fcntl.LOCK_UN)
                lk.close()
            except Exception:
                pass
    log('password set via wizard')
    return True, ''

def wifi_scan():
    ifaces = [e['name'] for e in json_state().get('wifi', [])]
    if not ifaces:
        return False, 'No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.', []
    iface = ifaces[0]
    sh(f'ip link set {iface} up')
    rc, out, err = sh(f'iw dev {iface} scan', timeout=45)
    if rc != 0:
        return False, f'Wi-Fi scan failed on {iface}. You can still use Ethernet.', []
    seen = {}
    ssid = sig = None
    for ln in out.splitlines():
        m = re.match(r'^\s*SSID: (.+)$', ln)
        if m: ssid = m.group(1)
        m = re.match(r'^\s*signal: (-?[\d.]+) dBm', ln)
        if m: sig = m.group(1)
        if ssid and sig and ssid not in seen:
            seen[ssid] = sig
    nets = [{'ssid': k, 'signal': v} for k, v in sorted(seen.items(), key=lambda x: -float(x[1] or -999))]
    return True, '', nets[:40]

def wifi_connect(ssid, psk):
    if not ssid or not isinstance(psk, str) or len(psk) < 8:
        return False, 'Pick a network and enter its password (at least 8 chars).'
    # An SSID is attacker-controlled (a rogue AP chooses it). wpa_passphrase does
    # not escape it, so a crafted SSID could inject directives into the config.
    if any(c in str(ssid) for c in '\n\r"\\'):
        return False, 'That network name is not supported — choose another network.'
    ifaces = [e['name'] for e in json_state().get('wifi', [])]
    if not ifaces:
        return False, 'No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.'
    iface = ifaces[0]
    conf = '/etc/wpa_supplicant/wpa_supplicant.conf'
    sh(['mkdir', '-p', '/etc/wpa_supplicant'])
    rc, out, err = sh(['wpa_passphrase', ssid, psk])
    if rc != 0:
        return False, 'Wi-Fi tools are not available on this box.'
    block = out
    try:
        cur = open(conf).read() if os.path.exists(conf) else 'ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev\nupdate_config=1\n'
        # drop any previous block for this ssid, then append
        cur = re.sub(r'network=\{[^}]*ssid="%s"[^}]*\}\n?' % re.escape(ssid), '', cur)
        open(conf, 'w').write(cur + ('\n' if not cur.endswith('\n') else '') + block + '\n')
    except Exception as e:
        return False, f'Could not update Wi-Fi config: {e}'
    log(f'wifi: configured {ssid} on {iface}')
    rc1, _, e1 = sh(f'wpa_cli -i {iface} reconfigure', timeout=15)
    if rc1 != 0:
        sh(f'wpa_supplicant -B -i {iface} -c {conf}', timeout=20)
    time.sleep(4)
    sh(f'dhclient -4 -1 {iface}', timeout=45) or sh(f'ifup {iface}', timeout=45)
    time.sleep(2)
    st = sh(f'ip -4 -o addr show dev {iface} scope global')
    if st[0] == 0 and 'inet ' in st[1]:
        return True, f'Connected to {ssid}.'
    return False, 'Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.'

OTA_CONF = '/etc/filterbox/ota.conf'
DIAG_CONF = '/etc/filterbox/diag.conf'


def set_updates_enabled(enabled):
    """Record the owner's choice and follow it with the timer."""
    try:
        os.makedirs(os.path.dirname(OTA_CONF), exist_ok=True)
        tmp = OTA_CONF + '.tmp'
        with open(tmp, 'w') as fh:
            fh.write('UPDATE_ENABLED=%d\n' % (1 if enabled else 0))
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, OTA_CONF)
    except OSError as e:
        log(f'ota.conf write failed: {e}')
        return False
    if not os.environ.get('FB_PANEL_DEV'):
        try:
            subprocess.run(['systemctl', 'enable' if enabled else 'disable', '--now',
                            'fb-update.timer'], capture_output=True, timeout=30)
        except Exception as e:
            log(f'fb-update.timer toggle failed: {e}')
    return True


def set_diag_enabled(enabled):
    """Diagnostics are opt-in: the wizard writes the owner's choice here."""
    try:
        os.makedirs(os.path.dirname(DIAG_CONF), exist_ok=True)
        tmp = DIAG_CONF + '.tmp'
        with open(tmp, 'w') as fh:
            fh.write('DIAG_ENABLED=%d\n' % (1 if enabled else 0))
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, DIAG_CONF)
    except OSError as e:
        log(f'diag.conf write failed: {e}')
        return False
    if not os.environ.get('FB_PANEL_DEV'):
        try:
            subprocess.run(['systemctl', 'enable' if enabled else 'disable', '--now',
                            'fb-diag.timer'], capture_output=True, timeout=30)
        except Exception as e:
            log(f'fb-diag.timer toggle failed: {e}')
    return True


def updates_enabled():
    try:
        for line in open(OTA_CONF):
            if line.strip().startswith('UPDATE_ENABLED='):
                return line.split('=', 1)[1].strip().lower() not in ('0', 'false', 'no', 'off')
    except OSError:
        pass
    return True


def finish(ip):
    # A pending reset must complete first: finishing setup here would clear the
    # reset markers and skip the stats-DB wipe, leaving the old owner's history.
    if os.path.exists(RESET_STATE):
        return False, 'This box is resetting — keep it powered and try again in a minute.'
    if os.path.exists(DONE_MARKER):
        # A pre-reset marker must never be consent while reset markers exist: the
        # box is in setup, and returning success here silently kept the dashboard.
        if os.path.exists(RESET_STATE) or os.path.exists(NEEDS_SETUP):
            try:
                os.remove(DONE_MARKER)
            except Exception:
                pass
            return False, 'This box is resetting — reload the page in a moment.'
        # Idempotent repair: a previous start may have failed transiently.
        sh('systemctl start --no-block fb-cover', timeout=10)
        return True, ''
    st = state()
    tok = _reset_token()
    resetting = bool(tok)
    state_ok = bool(st.get('password_set')) and (not resetting or (bool(st.get('reset_token')) and st.get('reset_token') == tok))
    secret_ok = os.path.exists(FTL_SECRET) and not resetting
    if not state_ok and not secret_ok:
        return False, 'Set an admin password first.'
    # Truth gate: do not tell the customer "all set" while the list database is
    # empty. Firstboot normally filled it; a failed firstboot must stay in setup
    # instead of showing a protected dashboard with nothing blocked.
    try:
        db = sqlite3.connect('file:/etc/pihole/gravity.db?mode=ro', uri=True, timeout=10)
        n = int(db.execute('SELECT COUNT(*) FROM vw_gravity').fetchone()[0])
        db.close()
    except Exception:
        n = 0
    if n < 100000:
        return False, 'Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.'
    tmp = DONE_MARKER + '.tmp'
    with open(tmp, 'w') as f:
        f.write(f'wizard completed {time.strftime("%Y-%m-%dT%H:%M:%S")} from {ip}\n')
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, DONE_MARKER)          # atomic: a partial marker is never consent
    clear_setup_active()                  # setup is done; updates may restart the panel again
    for f in (NEEDS_SETUP, RESET_STATE, '/etc/filterbox/web-password.initial'):
        try:
            os.remove(f)
        except Exception:
            pass
    # Consent now exists: start the coverage engine (it waits for this marker).
    # --no-block: never let a slow/crash-looping unit stall the wizard's response.
    sh('systemctl start --no-block fb-cover', timeout=10)
    log(f'wizard completed from {ip} — the panel will serve the dashboard from now on')
    # Detached finisher: let this response flush, then finalize in the background
    # (the panel keeps :80 through the switch — no handover needed any more).
    sh('setsid /bin/bash /usr/local/lib/filterbox/fb-wizard-finish.sh '
       '>/var/log/filterbox/wizard-finish.log 2>&1 &')
    return True, ''

# ------------------------------------------------------------------- http ---
PAGE = r"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>FilterBox — Setup</title><style>
:root{--bg:#0b1020;--card:#141a2e;--ink:#eef1f8;--mut:#9aa3bb;--acc:#5b8cff;--acc2:#8a5bff;--ok:#2ecc71;--warn:#f0a43c;--bad:#ff5c5c;--line:#242c48}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;font:17px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Inter,"Noto Sans",sans-serif;background:radial-gradient(1200px 600px at 50% -10%,#1b2450 0,var(--bg) 55%);color:var(--ink);min-height:100vh}
.wrap{max-width:520px;margin:0 auto;padding:10px 20px 48px}
.topbar{position:sticky;top:0;z-index:30;display:flex;justify-content:flex-end;align-items:center;padding:6px 0 8px;margin:0 0 6px;background:var(--bg);box-shadow:0 8px 18px rgba(11,16,32,.75)}
.topbar .langpick{margin:0;max-width:190px;width:auto}
.topbar .langsel{padding:8px 32px 8px 12px;font-size:13.5px;border-radius:11px;background-color:#141a2e;border:1px solid var(--line);color-scheme:dark}
option{background:#141a2e;color:var(--ink)}
.logo{display:flex;align-items:center;gap:12px;justify-content:center;margin:6px 0 20px}
.logo .hex{width:42px;height:42px}
.logo b{font-size:22px;letter-spacing:.4px}.logo b i{font-style:normal;color:var(--acc)}
.steps{display:flex;gap:8px;justify-content:center;margin:6px 0 22px}
.dot{width:34px;height:5px;border-radius:3px;background:var(--line)}
.dot.on{background:linear-gradient(90deg,var(--acc),var(--acc2))}
.card{background:linear-gradient(180deg,rgba(255,255,255,.035),rgba(255,255,255,0)),var(--card);border:1px solid var(--line);border-radius:18px;padding:22px 20px;margin:0 0 16px;box-shadow:0 10px 30px rgba(0,0,0,.35)}
h1{font-size:24px;margin:2px 0 8px}h2{font-size:19px;margin:0 0 10px}
p{margin:6px 0 14px;color:var(--mut)}
p.tight{margin:2px 0 10px}
label{display:block;font-size:14px;color:var(--mut);margin:0 0 6px}
input[type=password],input[type=text]{width:100%;padding:15px 14px;border-radius:12px;border:1px solid var(--line);background:#0e1428;color:var(--ink);font-size:17px;outline:none}
input:focus{border-color:var(--acc)}
.btn{display:block;width:100%;padding:16px;border:0;border-radius:14px;font-size:18px;font-weight:650;color:#fff;background:linear-gradient(100deg,var(--acc),var(--acc2));margin-top:14px;cursor:pointer}
.btn[disabled]{opacity:.45}
.btn.ghost{background:#0e1428;border:1px solid var(--line);color:var(--ink);font-weight:500}
.row{display:flex;align-items:center;gap:10px;margin:10px 0}
.pill{display:inline-flex;align-items:center;gap:7px;padding:7px 12px;border-radius:999px;background:#0e1428;border:1px solid var(--line);font-size:14px}
.pill .st{width:9px;height:9px;border-radius:50%;background:var(--bad)}
.pill .st.ok{background:var(--ok)}
.pill .st.wait{background:var(--warn)}
.pill .st.bad{background:var(--bad)}
.mut{color:var(--mut);font-size:14px}
.err{color:#ffb4b4;background:#33121a;border:1px solid #5c2230;border-radius:12px;padding:11px 13px;margin-top:12px;display:none;font-size:15px}
.checkline{display:flex;gap:11px;align-items:flex-start;margin:16px 0 2px;padding:13px 14px;background:#0e1428;border:1px solid var(--line);border-radius:13px;cursor:pointer;font-size:15px;line-height:1.4}
.checkline input{width:20px;height:20px;margin:1px 0 0;accent-color:#5b8cff;flex:none}
.checkline span{color:var(--mut)}
.checkline b{color:var(--ink);font-weight:650}
.okmsg{color:#c8ffd9;background:#0e2b1b;border:1px solid #1e5c39;border-radius:12px;padding:11px 13px;margin-top:12px;display:none;font-size:15px}
.net{padding:14px;border:1px solid var(--line);border-radius:13px;margin:8px 0;display:flex;justify-content:space-between;align-items:center;cursor:pointer;background:#0e1428}
.net:active{border-color:var(--acc)}
.net small{color:var(--mut)}
.hidden{display:none!important}
.foot{text-align:center;color:var(--mut);font-size:13px;margin-top:10px}
.spin{display:inline-block;width:18px;height:18px;border:3px solid rgba(255,255,255,.25);border-top-color:#fff;border-radius:50%;animation:r 1s linear infinite;vertical-align:-3px}
@keyframes r{to{transform:rotate(360deg)}}
</style></head><body><div class="wrap">
<div class="topbar"><div class="langpick"><!--FB-LANG-PICK--></div></div>
<div class="logo"><svg class="hex" viewBox="0 0 48 48" fill="none"><path d="M24 3 43 13.5v21L24 45 5 34.5v-21L24 3Z" stroke="url(#g)" stroke-width="3"/><path d="M16 24l6 6 11-12" stroke="#5b8cff" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/><defs><linearGradient id="g" x1="5" y1="3" x2="43" y2="45"><stop stop-color="#5b8cff"/><stop offset="1" stop-color="#8a5bff"/></linearGradient></defs></svg><b>Filter<i>Box</i></b></div>
<div class="steps" id="steps"><div class="dot on" id="d1"></div><div class="dot" id="d2"></div><div class="dot" id="d3"></div></div>

<div class="card" id="card-welcome">
  <h1>Your filter box is online 🎉</h1>
  <p id="w-sub">Filtering is already running for your whole home.</p>
  <div class="row"><span class="pill"><span class="st wait" id="p-st"></span><span id="p-txt">Protection…</span></span></div>
  <div class="row"><span class="pill"><span class="st wait" id="i-st"></span><span id="i-txt">Internet…</span></span></div>
  <p class="mut" id="w-ips"></p>
  <p class="mut">The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.</p>
  <button class="btn" id="btn-start">Set up the dashboard</button>
</div>

<div class="card hidden" id="card-pass">
  <h2>Choose your dashboard password</h2>
  <p class="tight">This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.</p>
  <label for="pw1">Password (at least 8 characters)</label>
  <input type="password" id="pw1" autocomplete="new-password">
  <label for="pw2" style="margin-top:12px">Repeat password</label>
  <input type="password" id="pw2" autocomplete="new-password">
  <div class="err" id="pass-err"></div>
  <label class="checkline" for="upd-toggle">
    <input type="checkbox" id="upd-toggle" checked>
    <span><b>Keep the box updated automatically</b><br>Security fixes and filtering improvements only — no personal data leaves the box.</span>
  </label>
  <label class="checkline" for="diag-toggle">
    <input type="checkbox" id="diag-toggle">
    <span><b>Share anonymous diagnostic reports</b><br>Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.</span>
  </label>
  <button class="btn" id="btn-pass">Save password</button>
</div>

<div class="card hidden" id="card-wifi">
  <h2>Internet connection</h2>
  <p id="wifi-lead">Choose how this box reaches the internet.</p>
  <div class="row"><span class="pill"><span class="st ok" id="eth-st"></span><span id="eth-txt">Ethernet</span></span></div>
  <div id="wifi-block" class="hidden">
    <button class="btn ghost" id="btn-scan">Scan for Wi-Fi networks</button>
    <div id="nets"></div>
    <div class="hidden" id="psk-block">
      <label for="psk" id="psk-label">Wi-Fi password</label>
      <input type="password" id="psk">
      <button class="btn" id="btn-join">Connect</button>
    </div>
  </div>
  <div class="err" id="wifi-err"></div>
  <div class="okmsg" id="wifi-ok"></div>
  <button class="btn" id="btn-wifi-next">Continue</button>
</div>

<div class="card hidden" id="card-done">
  <h1>You're all set 🛡️</h1>
  <p>Filtering is already running for your whole home — the dashboard shows how it's going.</p>
  <p class="mut">Opening your dashboard… <span class="spin"></span></p>
  <p class="mut" id="done-alt"></p>
  <button class="btn" id="btn-admin">Open dashboard</button>
</div>

<div class="card hidden" id="card-already">
  <h1>Setup already complete</h1>
  <p>This box has already been set up. Head to the dashboard to see how it's doing.</p>
  <button class="btn" id="btn-admin2">Open dashboard</button>
</div>

<div class="foot">FilterBox v<span id="ver"></span> · your data stays on this device</div>
</div>
<script>
const $ = s => document.querySelector(s);
async function api(path, body){
  const r = await fetch(path, body ? {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)} : {});
  let j; try{ j = await r.json(); }catch(e){ j = {ok:false, error:'Bad response'}; }
  return j;
}
let ST = {};
let CUR_CARD = 'card-welcome';
function show(card, step){ CUR_CARD = card; ['card-welcome','card-pass','card-wifi','card-done','card-already'].forEach(c=>$('#'+c).classList.add('hidden')); $('#'+card).classList.remove('hidden'); if(step){[1,2,3].forEach(n=>$('#d'+n).classList.remove('on')); for(let n=1;n<=step;n++) $('#d'+n).classList.add('on');} window.scrollTo(0,0); }
function fbLangChange(sel){
  // Keep the wizard where it is: the language switch reloads with ?lang=.
  try{ sessionStorage.setItem('fb-wizard-card', CUR_CARD); }catch(e){}
  location.href = '?lang=' + encodeURIComponent(sel.value);
}
function setPill(id, ok, text){ const el=$('#'+id); el.classList.remove('ok','wait','bad'); el.classList.add(ok===true?'ok':(ok===false?'bad':'wait')); }
async function refresh(){
  ST = await api('/api/status');
  $('#ver').textContent = ST.version || $('#ver').textContent;
  if(ST.done){ show('card-already'); return; }
  const CV = ST.coverage || {};
  // "Whole home" is only true when the filter is actually claiming the LAN
  // AND the local resolver is blocking. FTL alone must never assert it.
  const covered = (CV.state === 'full') && (ST.protection.active === true);
  const active = covered;
  setPill('p-st', active, '');
  $('#p-txt').textContent = active ? 'Protection: active' : (CV.state === 'bypass' ? 'Protection: paused' : 'Protection: warming up');
  setPill('i-st', ST.internet.up, '');
  $('#i-txt').textContent = ST.internet.up ? 'Internet: connected' : 'Internet: not yet';
  const ips = (ST.ips||[]).map(i=>i.ip).join(', ');
  $('#w-ips').textContent = ips ? ('This box: ' + ST.hostname + ' — ' + ips) : '';
  $('#w-sub').textContent = covered ? 'Filtering is already running for your whole home.' : (CV.state === 'bypass' ? 'Protection is paused — filtering is off.' : 'Protection is starting — no action needed.');
  $('#eth-st').classList.toggle('ok', (ST.ethernet||[]).some(e=>e.carrier));
  $('#eth-txt').textContent = (ST.ethernet||[]).some(e=>e.carrier) ? 'Ethernet: cable connected' : 'Ethernet: no cable detected';
  $('#wifi-block').classList.toggle('hidden', !(ST.wifi||[]).length);
  $('#wifi-lead').textContent = (ST.wifi||[]).length ? 'Wi-Fi is available on this box — you can use it, or keep Ethernet.' : 'This box filters through its network cable — nothing to configure here.';
  // A language switch reloads the page. Restore the step the customer was on so
  // changing language never sends them back to the start of the wizard.
  try{
    const saved = sessionStorage.getItem('fb-wizard-card');
    if(saved === 'card-pass') show('card-pass', 2);
    else if(saved === 'card-wifi') show('card-wifi', 3);
  }catch(e){}
}
$('#btn-start').onclick = ()=> show('card-pass', 2);
$('#btn-pass').onclick = async ()=>{
  const pw1=$('#pw1').value, pw2=$('#pw2').value, err=$('#pass-err');
  err.style.display='none';
  if(pw1.length<8){ err.textContent='Password needs at least 8 characters.'; err.style.display='block'; return; }
  if(pw1!==pw2){ err.textContent='The two passwords don’t match.'; err.style.display='block'; return; }
  $('#btn-pass').disabled=true; $('#btn-pass').innerHTML='<span class="spin"></span> Saving…';
  const j = await api('/api/password', {password: pw1});
  $('#btn-pass').disabled=false; $('#btn-pass').textContent='Save password';
  if(!j.ok){ err.textContent=j.error||'Something went wrong.'; err.style.display='block'; return; }
  ST.password_set = true;
  if((ST.wifi||[]).length){ show('card-wifi', 3); } else { await doFinish(); }
};
$('#btn-scan').onclick = async ()=>{
  $('#btn-scan').innerHTML='<span class="spin"></span> Scanning…';
  const j = await api('/api/wifi/scan');
  $('#btn-scan').textContent='Scan again';
  const box=$('#nets'); box.innerHTML='';
  if(!j.ok){ $('#wifi-err').textContent=j.error; $('#wifi-err').style.display='block'; return; }
  (j.networks||[]).forEach(n=>{
    const d=document.createElement('div'); d.className='net';
    d.innerHTML='<span>'+n.ssid.replace(/</g,'&lt;')+'</span><small>'+n.signal+' dBm</small>';
    d.onclick=()=>{ $('#psk-block').classList.remove('hidden'); $('#psk-label').textContent='Password for “'+n.ssid+'”'; $('#psk').dataset.ssid=n.ssid; $('#psk').focus(); };
    box.appendChild(d);
  });
  if(!(j.networks||[]).length) box.innerHTML='<p class="mut">No networks found. Try again, or keep using Ethernet.</p>';
};
$('#btn-join').onclick = async ()=>{
  const ssid=$('#psk').dataset.ssid, psk=$('#psk').value;
  $('#btn-join').innerHTML='<span class="spin"></span> Connecting…';
  const j = await api('/api/wifi/connect', {ssid, psk});
  $('#btn-join').textContent='Connect';
  $('#wifi-ok').style.display='none'; $('#wifi-err').style.display='none';
  if(j.ok){ $('#wifi-ok').textContent=j.message||'Connected.'; $('#wifi-ok').style.display='block'; }
  else { $('#wifi-err').textContent=j.error||'Could not connect.'; $('#wifi-err').style.display='block'; }
};
$('#btn-wifi-next').onclick = doFinish;
async function doFinish(){
  $('#pass-err').style.display='none'; $('#wifi-err').style.display='none';
  const j = await api('/api/finish', {
    updates: !!($('#upd-toggle') && $('#upd-toggle').checked),
    diagnostics: !!($('#diag-toggle') && $('#diag-toggle').checked)
  });
  if(!j.ok){
    const box = CUR_CARD === 'card-wifi' ? $('#wifi-err') : $('#pass-err');
    if(box){ box.textContent = j.error || 'Not ready yet.'; box.style.display = 'block'; }
    return;
  }
  show('card-done', 3);
  $('#ver').textContent = ST.version || $('#ver').textContent;
  const admin = '/';
  $('#btn-admin').onclick = ()=> location.href = admin;
  setTimeout(()=>{ location.href = admin; }, 8000);
}
$('#btn-admin').onclick = ()=> location.href='/';
$('#btn-admin2').onclick = ()=> location.href='/';
refresh();
// Keep the update guard fresh while the customer is on this page: fb-update
// defers its restart while /run/filterbox/setup-active is recent.
setInterval(()=>{ fetch('/api/ping').catch(()=>{}); }, 30000);
</script></body></html>"""

LOGIN_PAGE = r"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>FilterBox — Sign in</title><style>
:root{--bg:#0b1020;--card:#141a2e;--ink:#eef1f8;--mut:#9aa3bb;--acc:#5b8cff;--acc2:#8a5bff;--ok:#2ecc71;--warn:#f0a43c;--bad:#ff5c5c;--line:#242c48}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;font:17px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Inter,"Noto Sans",sans-serif;background:radial-gradient(1200px 600px at 50% -10%,#1b2450 0,var(--bg) 55%);color:var(--ink);min-height:100vh;display:flex;flex-direction:column}
.topbar{position:sticky;top:0;z-index:30;display:flex;justify-content:flex-end;padding:8px 20px;background:var(--bg);box-shadow:0 8px 18px rgba(11,16,32,.75)}
.topbar .langpick{margin:0;max-width:190px;width:auto}
.topbar .langsel{padding:8px 32px 8px 12px;font-size:13.5px;border-radius:11px;background-color:#141a2e;border:1px solid var(--line);color-scheme:dark;appearance:none;color:var(--ink)}
option{background:#141a2e;color:var(--ink)}
.wrap{flex:1;display:flex;align-items:center;justify-content:center;padding:20px 20px 48px}
.box{width:100%;max-width:420px}
.logo{display:flex;align-items:center;justify-content:center;gap:12px;margin:0 0 18px}
.logo .hex{width:42px;height:42px}.logo b{font-size:22px;letter-spacing:.4px}.logo b i{font-style:normal;color:var(--acc)}
.card{background:linear-gradient(180deg,rgba(255,255,255,.035),rgba(255,255,255,0)),var(--card);border:1px solid var(--line);border-radius:18px;padding:24px 20px;box-shadow:0 10px 30px rgba(0,0,0,.35)}
h1{font-size:22px;margin:0 0 8px}p{margin:0 0 14px;color:var(--mut)}
input[type=password]{width:100%;padding:15px 14px;border-radius:12px;border:1px solid var(--line);background:#0e1428;color:var(--ink);font-size:17px;outline:none}
input:focus{border-color:var(--acc)}
.btn{display:block;width:100%;padding:15px;border:0;border-radius:14px;font-size:17px;font-weight:650;color:#fff;background:linear-gradient(100deg,var(--acc),var(--acc2));margin-top:12px;cursor:pointer}
.btn[disabled]{opacity:.45}
.err{color:#ffb4b4;background:#33121a;border:1px solid #5c2230;border-radius:12px;padding:11px 13px;margin:12px 0 0;display:none;font-size:15px}
.hidden{display:none!important}
</style></head><body>
<div class="topbar"><div class="langpick"><!--FB-LANG-PICK--></div></div>
<div class="wrap"><div class="box">
<div class="logo"><svg class="hex" viewBox="0 0 48 48" fill="none"><path d="M24 3 43 13.5v21L24 45 5 34.5v-21L24 3Z" stroke="url(#lg)" stroke-width="3"/><path d="M16 24l6 6 11-12" stroke="#5b8cff" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/><defs><linearGradient id="lg" x1="5" y1="3" x2="43" y2="45"><stop stop-color="#5b8cff"/><stop offset="1" stop-color="#8a5bff"/></linearGradient></defs></svg><b>Filter<i>Box</i></b></div>
<div class="card">
<h1>Enter your dashboard password</h1>
<p>This dashboard is private to your home. Enter the password you chose during setup.</p>
<input type="password" id="lg-pw" autocomplete="current-password" placeholder="Password" autofocus>
<div class="err" id="lg-err"></div>
<button class="btn" id="lg-go">Continue</button>
</div></div></div>
<script>
const NEXT=__NEXT__;
const $=s=>document.querySelector(s);
$('#lg-go').onclick=async()=>{
  const err=$('#lg-err'); err.style.display='none'; $('#lg-go').disabled=true;
  let j={};
  try{const r=await fetch('/api/panel/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:$('#lg-pw').value})});j=await r.json();}catch(e){}
  $('#lg-go').disabled=false;
  if(j.ok&&j.token){try{sessionStorage.setItem('fb_tok',j.token);}catch(e){} location.replace(NEXT); return;}
  err.textContent=j.error||"That password doesn't match — try again."; err.style.display='block';
};
$('#lg-pw').addEventListener('keydown',e=>{if(e.key==='Enter')$('#lg-go').click();});
</script></body></html>"""

DASH_PAGE = r"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>FilterBox</title><style>
:root{--bg:#0b1020;--card:#141a2e;--ink:#eef1f8;--mut:#9aa3bb;--acc:#5b8cff;--acc2:#8a5bff;--ok:#2ecc71;--warn:#f0a43c;--bad:#ff5c5c;--line:#242c48}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;font:17px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Inter,"Noto Sans",sans-serif;background:radial-gradient(1200px 600px at 50% -10%,#1b2450 0,var(--bg) 55%);color:var(--ink);min-height:100vh}
.wrap{max-width:520px;margin:0 auto;padding:28px 20px 48px}
.logo{display:flex;align-items:center;gap:12px;justify-content:center;margin:6px 0 20px;position:relative}
.logo .hex{width:42px;height:42px}
.logo b{font-size:22px;letter-spacing:.4px}.logo b i{font-style:normal;color:var(--acc)}
.topbar{position:sticky;top:0;z-index:30;display:flex;justify-content:flex-end;align-items:center;padding:6px 0 8px;margin:0 0 6px;background:var(--bg);box-shadow:0 8px 18px rgba(11,16,32,.75)}
.topbar .langpick{margin:0;max-width:190px;width:auto}
.topbar .langsel{padding:8px 32px 8px 12px;font-size:13.5px;border-radius:11px;background-color:#141a2e;border:1px solid var(--line);color-scheme:dark}
option{background:#141a2e;color:var(--ink)}
.gear{position:absolute;right:0;top:50%;transform:translateY(-50%);width:44px;height:44px;display:flex;align-items:center;justify-content:center;border-radius:12px;border:1px solid var(--line);background:#0e1428;cursor:pointer}
.gear:active{border-color:var(--acc)}
.gear svg{width:21px;height:21px;stroke:var(--mut);fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.card{background:linear-gradient(180deg,rgba(255,255,255,.035),rgba(255,255,255,0)),var(--card);border:1px solid var(--line);border-radius:18px;padding:20px;margin:0 0 14px;box-shadow:0 10px 30px rgba(0,0,0,.35)}
h1{font-size:40px;margin:0 0 2px;letter-spacing:-.5px}h2{font-size:17px;margin:0 0 10px}
p{margin:4px 0 10px;color:var(--mut)}
.row{display:flex;align-items:center;gap:10px;margin:0 0 8px;flex-wrap:wrap}
.pill{display:inline-flex;align-items:center;gap:7px;padding:7px 12px;border-radius:999px;background:#0e1428;border:1px solid var(--line);font-size:14px}
.pill .st{width:9px;height:9px;border-radius:50%;background:var(--bad)}
.pill .st.ok{background:var(--ok)}
.pill .st.wait{background:var(--warn)}
.pill .st.bad{background:var(--bad)}
#s-pill{cursor:pointer}
.pausebtn{margin-left:auto;display:inline-flex;align-items:center;gap:6px;border:1px solid var(--line);background:#0e1428;color:var(--ink);border-radius:999px;padding:8px 12px;font-size:13.5px;cursor:pointer;flex:none}
.pausebtn:active{border-color:var(--acc);background:#182040}
.mut{color:var(--mut);font-size:14px}
.bars{display:flex;align-items:flex-end;gap:2px;height:110px;margin:6px 0 4px;padding:10px 10px 8px;background:#0e1428;border:1px solid var(--line);border-radius:12px;direction:ltr}
.bars2{display:flex;align-items:flex-end;gap:1px;height:120px;margin:6px 0 4px;padding:10px 10px 8px;background:#0e1428;border:1px solid var(--line);border-radius:12px;direction:ltr}
.axis{position:relative;height:15px;margin:-2px 2px 8px;direction:ltr;font-size:11px;font-variant-numeric:tabular-nums;opacity:.85}
.axis span{position:absolute;top:0;white-space:nowrap}
.bars2 .b{flex:1;position:relative;min-height:2px;border-radius:2px;background:linear-gradient(180deg,rgba(91,140,255,.55),rgba(91,140,255,.22))}
.bars2 .b i{position:absolute;left:0;right:0;bottom:0;border-radius:2px;background:linear-gradient(180deg,var(--acc2),#6a3df0)}
.chips2{display:flex;flex-wrap:wrap;gap:6px;margin:2px 0 0}
.chip2{background:#0e1428;border:1px solid var(--line);border-radius:999px;padding:5px 11px;font-size:13px;color:var(--ink)}
.chip2 b{color:#a9bcff;font-weight:650;margin-right:2px}
.bar{flex:1;background:linear-gradient(180deg,var(--acc),var(--acc2));border-radius:3px 3px 1px 1px;min-height:3px;opacity:.92}
.top-row{display:flex;justify-content:space-between;gap:12px;padding:9px 2px;border-bottom:1px solid var(--line);font-size:15px}
.top-row:last-child{border-bottom:0}
.top-row .dom{color:var(--ink);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.top-row b{color:var(--mut);font-weight:600;flex:none}
/* ---- dashboard v2: KPIs, tooltips, donut, list bars, desktop grid ---- */
.kpis{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:0 0 14px}
.kpi{position:relative;overflow:hidden;background:linear-gradient(180deg,rgba(255,255,255,.045),rgba(255,255,255,0)),var(--card);border:1px solid var(--line);border-radius:18px;padding:16px 16px 14px;box-shadow:0 10px 30px rgba(0,0,0,.35)}
.kpi.hero{grid-column:1/-1}
.kpi .lab{font-size:11.5px;letter-spacing:.09em;text-transform:uppercase;color:var(--mut);margin:0 0 6px;font-weight:600}
.kpi .big{font-size:34px;line-height:1.06;letter-spacing:-.6px;margin:0;font-weight:700;font-variant-numeric:tabular-nums}
.kpi .sub{font-size:13px;color:var(--mut);margin:6px 0 0}
.kpi .kp{padding:0}
.donutcard{display:flex;flex-direction:column;align-items:center;justify-content:center}
.dwrap{position:relative;display:flex;align-items:center;justify-content:center;margin:2px 0 0}
.donut{width:86px;height:86px;transform:rotate(-90deg)}
.donut .dring{fill:none;stroke:#0e1428;stroke-width:12}
.donut .dval{fill:none;stroke:url(#dg);stroke-width:12;stroke-linecap:round;transition:stroke-dasharray .5s ease}
.dcenter{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;pointer-events:none}
.dcenter b{display:block;font-size:19px;line-height:1;font-variant-numeric:tabular-nums}
.dcenter span{font-size:10.5px;color:var(--mut);margin-top:2px}
.chead{display:flex;align-items:baseline;justify-content:space-between;gap:10px;flex-wrap:wrap}
.chead h2{margin:0 0 8px}
.legend{display:flex;gap:12px;align-items:center;font-size:12px;color:var(--mut);margin:0 0 8px}
.legend i{width:9px;height:9px;border-radius:3px;display:inline-block;margin-right:5px;vertical-align:-1px}
.legend .lq{background:linear-gradient(180deg,rgba(91,140,255,.75),rgba(91,140,255,.35))}
.legend .lb{background:linear-gradient(180deg,var(--acc2),#6a3df0)}
.bars2 .b{cursor:pointer;transition:filter .12s}
.bars2 .b:hover{filter:brightness(1.35)}
.bars .bar{cursor:pointer;transition:filter .12s}
.bars .bar:hover{filter:brightness(1.3)}
.tip{position:fixed;z-index:60;pointer-events:none;background:#0b1020ee;border:1px solid var(--line);border-radius:10px;padding:8px 10px;font-size:12.5px;line-height:1.35;color:var(--ink);box-shadow:0 12px 30px rgba(0,0,0,.5);white-space:normal;max-width:calc(100vw - 16px);backdrop-filter:blur(6px)}
.tip b{color:#fff;font-weight:650}
.tip .m{color:var(--mut)}
.top-row .tb{flex:1;height:6px;min-width:24px;background:#0e1428;border-radius:999px;overflow:hidden;align-self:center;margin:0 2px}
.top-row .tb i{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,var(--acc),var(--acc2));opacity:.85}
.top-row{cursor:default}
.cols{display:block}
@media(min-width:780px){
  .wrap{max-width:1000px}
  .cols{display:grid;grid-template-columns:1fr 1fr;gap:14px;align-items:start}
  .cols .card{margin:0 0 14px}
  .kpis{grid-template-columns:1.7fr 1fr 1fr;gap:14px}
  .kpi.hero{grid-column:auto}
  .kpi .big{font-size:38px}
}
.foot{text-align:center;color:var(--mut);font-size:13px;margin-top:10px}
.btn{display:block;width:100%;padding:15px;border:0;border-radius:14px;font-size:17px;font-weight:650;color:#fff;background:linear-gradient(100deg,var(--acc),var(--acc2));margin-top:12px;cursor:pointer}
.btn.ghost{background:#0e1428;border:1px solid var(--line);color:var(--ink);font-weight:500}
.btn.small{display:inline-block;width:auto;padding:10px 16px;font-size:15px;margin:8px 8px 0 0}
.btn.danger{background:linear-gradient(100deg,#e5484d,#b3261e)}
.btn[disabled]{opacity:.45}
input[type=password],input[type=text]{width:100%;padding:15px 14px;border-radius:12px;border:1px solid var(--line);background:#0e1428;color:var(--ink);font-size:17px;outline:none}
input:focus{border-color:var(--acc)}
.err{color:#ffb4b4;background:#33121a;border:1px solid #5c2230;border-radius:12px;padding:11px 13px;margin-top:12px;display:none;font-size:15px}
.checkline{display:flex;gap:11px;align-items:flex-start;margin:16px 0 2px;padding:13px 14px;background:#0e1428;border:1px solid var(--line);border-radius:13px;cursor:pointer;font-size:15px;line-height:1.4}
.checkline input{width:20px;height:20px;margin:1px 0 0;accent-color:#5b8cff;flex:none}
.checkline span{color:var(--mut)}
.checkline b{color:var(--ink);font-weight:650}
.hidden{display:none!important}
.sheet{position:fixed;inset:0;background:rgba(4,7,16,.72);display:flex;align-items:flex-end;justify-content:center;z-index:50;padding:18px}
#login-sheet{align-items:center}
.sheet-card{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:20px;width:100%;max-width:520px;box-shadow:0 18px 50px rgba(0,0,0,.5)}
.sheet-card h2{margin:2px 0 12px}
#toast{position:fixed;left:12px;top:calc(12px + env(safe-area-inset-top));transform:none;background:#182040;border:1px solid var(--line);color:var(--ink);padding:12px 16px;border-radius:12px;font-size:15px;z-index:70;max-width:min(420px,calc(100vw - 220px));text-align:left;box-shadow:0 8px 24px rgba(0,0,0,.45)}
</style></head><body><div class="wrap">
<div class="topbar"><div class="langpick"><!--FB-LANG-PICK--></div></div>
<div class="logo"><svg class="hex" viewBox="0 0 48 48" fill="none"><path d="M24 3 43 13.5v21L24 45 5 34.5v-21L24 3Z" stroke="url(#g)" stroke-width="3"/><path d="M16 24l6 6 11-12" stroke="#5b8cff" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/><defs><linearGradient id="g" x1="5" y1="3" x2="43" y2="45"><stop stop-color="#5b8cff"/><stop offset="1" stop-color="#8a5bff"/></linearGradient></defs></svg><b>Filter<i>Box</i></b>
<a class="gear" href="/settings" aria-label="Settings" title="Settings"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1 1.55V21a2 2 0 1 1-4 0v-.09a1.7 1.7 0 0 0-1.11-1.55 1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.7 1.7 0 0 0 .34-1.87 1.7 1.7 0 0 0-1.55-1H3a2 2 0 1 1 0-4h.09A1.7 1.7 0 0 0 4.64 8.4a1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.7 1.7 0 0 0 1.87.34h.08a1.7 1.7 0 0 0 1-1.55V3a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1 1.55 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87v.08a1.7 1.7 0 0 0 1.55 1H21a2 2 0 1 1 0 4h-.09a1.7 1.7 0 0 0-1.51 1Z"/></svg></a></div>
<div class="card">
  <div class="row"><span class="pill" id="s-pill" title="Tap to pause filtering"><span class="st wait" id="s-st"></span><span id="s-txt">Protection…</span></span>
  <span class="pill"><span class="st wait" id="n-st"></span><span id="n-txt">Internet…</span></span>
  <button class="pausebtn" id="pause-btn" type="button" title="Pause">Pause</button></div>
  <p class="mut" id="s-sub" style="margin:0">Checking on your filter…</p>
  <button class="btn small hidden" id="btn-resume">Turn back on</button>
</div>
<div class="kpis">
  <div class="kpi hero">
    <div class="lab">Queries today</div>
    <h1 class="big" id="h-num">—</h1>
    <p class="sub" id="h-sub">since midnight</p>
    <p class="sub kp" id="h-meta"></p>
    <p class="sub kp" id="h-cache"></p>
  </div>
  <div class="kpi">
    <div class="lab">Blocked</div>
    <div class="big" id="k-blocked">—</div>
    <div class="sub" id="k-blocked-sub">ads and trackers</div>
  </div>
  <div class="kpi donutcard">
    <div class="lab">Blocked share</div>
    <div class="dwrap">
      <svg class="donut" viewBox="0 0 100 100" aria-hidden="true">
        <defs><linearGradient id="dg" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#5b8cff"/><stop offset="1" stop-color="#8a5bff"/></linearGradient></defs>
        <circle class="dring" cx="50" cy="50" r="40"></circle>
        <circle class="dval" id="donut-arc" cx="50" cy="50" r="40" stroke-dasharray="0 251.3"></circle>
      </svg>
      <div class="dcenter"><b id="k-pct">—</b><span>Blocked</span></div>
    </div>
  </div>
</div>
<div class="card" id="cover-card" style="display:none">
  <h2>Whole home</h2>
  <p class="mut" id="cover-line" style="margin:0"></p>
</div>
<div class="card">
  <div class="chead"><h2>Today</h2><div class="legend"><span><i class="lq"></i>Queries</span><span><i class="lb"></i>Blocked</span></div></div>
  <div class="bars2" id="bars24"></div><div class="axis mut" id="axis24"></div>
  <p class="mut" id="chart24-meta" style="margin:0"></p>
</div>
<div class="card">
  <div class="chead"><h2>Last 7 days</h2><div class="legend"><span><i class="lb"></i>Blocked</span></div></div>
  <div class="bars" id="bars"></div><div class="axis mut" id="axis7"></div>
  <p class="mut" id="chart-meta" style="margin:0"></p>
</div>
<div class="cols">
  <div class="card"><h2>Top blocked today</h2><div id="top"><p class="mut" style="margin:0">Warming up…</p></div></div>
  <div class="card"><h2>Busiest devices</h2><div id="clients"><p class="mut" style="margin:0">Warming up…</p></div></div>
  <div class="card"><h2>Most visited today</h2><div id="topallow"><p class="mut" style="margin:0">Warming up…</p></div></div>
  <div class="card"><h2>Where answers came from</h2><div id="ups"><p class="mut" style="margin:0">Warming up…</p></div></div>
</div>
<div class="card"><h2>Traffic mix</h2><div class="chips2" id="types"><p class="mut" style="margin:0">Warming up…</p></div></div>
<div id="tip" class="tip" hidden></div>
<div class="foot">FilterBox v<span id="ver"></span> · your data stays on this device</div>
</div>
<div class="sheet hidden" id="sheet">
  <div class="sheet-card">
    <h2>Pause filtering?</h2>
    <p class="mut" style="margin:0 0 8px">Filtering will pause for a short break.</p>
    <button class="btn ghost choice" data-m="30">Pause 30 minutes</button>
    <button class="btn ghost choice" data-m="60">Pause 1 hour</button>
    <button class="btn ghost choice" data-m="indef">Pause until I turn it back on</button>
    <button class="btn" id="sheet-cancel">Cancel</button>
  </div>
</div>
<div class="sheet hidden" id="login-sheet">
  <div class="sheet-card">
    <h2>Enter your dashboard password</h2>
    <input type="password" id="lg-pw" autocomplete="current-password" placeholder="Password">
    <div class="err" id="lg-err"></div>
    <button class="btn" id="lg-go">Continue</button>
    <button class="btn ghost" id="lg-cancel">Cancel</button>
  </div>
</div>
<div id="toast" class="hidden" role="status" aria-live="polite"></div>
<script>
const $=s=>document.querySelector(s);
const fmt=n=>Number(n||0).toLocaleString('en-US');
let TOKEN=sessionStorage.getItem('fb_tok')||'';
let LOGIN_DONE=null;
const PAUSED={on:false,timer:null,at:0};
function toast(t){const el=$('#toast');el.textContent=t;el.classList.remove('hidden');el.style.display='block';clearTimeout(toast._t);toast._t=setTimeout(()=>{el.style.display='';el.classList.add('hidden');},3500);}
function countdown(timer){const rem=Math.max(0,timer-(Date.now()-PAUSED.at)/1000);const m=Math.round(rem/60);return m>=60?('Back in '+Math.floor(m/60)+' h '+(m%60)+' min'):('Back in ~'+Math.max(1,m)+' min');}
function showLogin(done){LOGIN_DONE=done||null;$('#lg-pw').value='';$('#lg-err').style.display='none';$('#login-sheet').classList.remove('hidden');setTimeout(()=>$('#lg-pw').focus(),60);}
$('#lg-cancel').onclick=()=>{$('#login-sheet').classList.add('hidden');LOGIN_DONE=null;};
$('#lg-go').onclick=async()=>{
  let j={};
  try{const r=await fetch('/api/panel/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:$('#lg-pw').value})});j=await r.json();}catch(e){}
  if(j.ok&&j.token){TOKEN=j.token;sessionStorage.setItem('fb_tok',TOKEN);$('#login-sheet').classList.add('hidden');const d=LOGIN_DONE;LOGIN_DONE=null;if(d)d();}
  else{$('#lg-err').textContent=j.error||"That password doesn't match — try again.";$('#lg-err').style.display='block';}
};
$('#lg-pw').addEventListener('keydown',e=>{if(e.key==='Enter')$('#lg-go').click();});
async function act(path,body,onOk){
  let r,j={};
  try{r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-FB-Token':TOKEN},body:JSON.stringify(body||{})});j=await r.json();}
  catch(e){toast('Could not reach the panel — reload in a moment.');return;}
  if(r.status===401){showLogin(()=>act(path,body,onOk));return;}
  if(!r.ok||!j.ok){toast(j.error||(r.status===429?'Too many requests — wait a minute.':'Something went wrong — try again.'));return;}
  if(onOk)onOk(j);
}
$('#s-pill').onclick=()=>{$('#sheet').classList.remove('hidden');};
$('#pause-btn').onclick=()=>{$('#sheet').classList.remove('hidden');};
$('#sheet-cancel').onclick=()=>$('#sheet').classList.add('hidden');
document.querySelectorAll('.choice').forEach(el=>el.onclick=()=>{
  $('#sheet').classList.add('hidden');
  const m=el.dataset.m;
  act('/api/panel/pause',{minutes:m==='indef'?'indefinite':parseInt(m,10)},()=>{
    toast(m==='indef'?'Paused until you turn it back on.':(m==='30'?'Paused for 30 minutes.':'Paused for 1 hour.'));
    load();
  });
});
$('#btn-resume').onclick=()=>act('/api/panel/resume',{},()=>{toast('Protection is back on.');load();});
document.addEventListener('visibilitychange',()=>{if(!document.hidden)load();});
setInterval(()=>{if(PAUSED.on&&PAUSED.timer!=null)$('#s-sub').textContent=countdown(PAUSED.timer);},1000);
const TIP=$('#tip');
function hideTip(){if(TIP){TIP.hidden=true;}}
function placeTip(x,y){
  if(!TIP)return;
  const pad=8;
  const w=TIP.offsetWidth||180, h=TIP.offsetHeight||40;
  const half=w/2+pad;
  const left=Math.max(half, Math.min(x, innerWidth-half));
  const above=(y-h-12)>=pad;
  TIP.style.transform=above?'translate(-50%,-100%)':'translate(-50%,12px)';
  TIP.style.left=left+'px';
  TIP.style.top=Math.max(pad,Math.min(y,innerHeight-pad))+'px';
}
function bindTips(sel,html){
  document.querySelectorAll(sel).forEach(function(el){
    function show(ev){const r=el.getBoundingClientRect();TIP.innerHTML=html(el);TIP.hidden=false;placeTip(ev&&ev.clientX?ev.clientX:(r.left+r.width/2), ev&&ev.clientY?ev.clientY-6:(r.top-4));}
    el.addEventListener('pointerenter',show);
    el.addEventListener('pointermove',function(ev){if(!TIP.hidden)placeTip(ev.clientX,ev.clientY-6);});
    el.addEventListener('pointerleave',hideTip);
    el.addEventListener('pointerdown',function(ev){show(ev);setTimeout(hideTip,2800);});
  });
}
function niceTime(t){const d=new Date(t*1000);const loc=FB_LOC[document.documentElement.lang]||'en-GB';return new Intl.DateTimeFormat(loc,{weekday:'short',hour:'2-digit',minute:'2-digit'}).format(d);}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function rows2(sel,rows,empty){
  const el=$(sel),list=rows||[],max=Math.max(1,...list.map(function(r){return r.n||0;}));
  el.innerHTML=list.length?list.map(function(r){
    const w=Math.max(2,Math.round(100*(r.n||0)/max));
    const name=esc(r.t==null?'':r.t);
    return '<div class="top-row" data-t="'+name+'" data-n="'+(r.n||0)+'"><span class="dom">'+name+'</span><span class="tb"><i style="width:'+w+'%"></i></span><b>'+fmt(r.n)+'</b></div>';
  }).join(''):('<p class="mut" style="margin:0">'+(empty||'')+'</p>');
  bindTips(sel+' .top-row',function(el){return '<b>'+esc(el.dataset.t)+'</b><br><span class="m">'+fmt(el.dataset.n)+' lookups today</span>';});
}
function bars7(H){
  // 7 days of 15-minute buckets is ~670 bars — thinner than a hair on a phone.
  // Aggregate to hours for display.
  const agg=[];let cur=null;
  H.forEach(function(x){const hr=Math.floor((x.t||0)/3600);if(!cur||cur.h!==hr){cur={h:hr,t:(x.t||0),b:0};agg.push(cur);}cur.b+=(x.b||0);});
  const max=Math.max(1,...agg.map(function(x){return x.b||0;}));
  $('#bars').innerHTML=agg.map(function(x){return '<div class="bar" data-t="'+(x.t||0)+'" data-b="'+(x.b||0)+'" style="height:'+Math.max(3,Math.round(100*(x.b||0)/max))+'%"></div>';}).join('');
  bindTips('#bars .bar',function(el){return '<b>'+fmt(el.dataset.b)+' blocked</b><br><span class="m">'+niceTime(el.dataset.t)+'</span>';});
  return agg;
}
function bars24(H){
  H=H||[];const max=Math.max(1,...H.map(function(x){return x.q||0;}));
  $('#bars24').innerHTML=H.map(function(x){const q=x.q||0,b=x.b||0;const hp=Math.max(2,Math.round(100*q/max));const bi=q>0?Math.round(100*b/q):0;
    return '<div class="b" data-t="'+(x.t||0)+'" data-q="'+q+'" data-b="'+b+'" style="height:'+hp+'%"><i style="height:'+bi+'%"></i></div>';}).join('');
  bindTips('#bars24 .b',function(el){const q=+el.dataset.q,b=+el.dataset.b,p=q?Math.round(100*b/q):0;
    return '<b>'+hhmm(el.dataset.t)+'</b><br>'+fmt(q)+' queries · '+fmt(b)+' blocked <span class="m">('+p+'%)</span>';});
  $('#chart24-meta').textContent=H.length?('Each bar is 10 minutes · busiest: '+fmt(max)):'The chart fills in as the day goes.';
  axis24(H);
}
function typesChips(T){const all=Object.entries(T).sort((a,b)=>b[1]-a[1]);const top=all.slice(0,4);const rest=all.slice(4).reduce((s,e)=>s+e[1],0);let h=top.map(e=>'<span class="chip2"><b>'+e[0]+'</b> '+fmt(e[1])+'</span>').join('');if(rest>0)h+='<span class="chip2"><b>OTHER</b> '+fmt(rest)+'</span>';$('#types').innerHTML=h||'<p class="mut" style="margin:0">Warming up…</p>';}
const FB_LOC={en:'en-GB',he:'he-IL',ru:'ru-RU'};
function hhmm(u){const d=new Date(u*1000);return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');}
function axisPut(sel,items){const el=$(sel);if(!el)return;el.innerHTML='';items.forEach(function(it){const s=document.createElement('span');s.textContent=it.l;const x=it.x;if(x<=3){s.style.left='0';}else if(x>=97){s.style.right='0';}else{s.style.left=x+'%';s.style.transform='translateX(-50%)';}el.appendChild(s);});}
function axis24(H){const n=H.length;if(n<4){$('#axis24').innerHTML='';return;}const idx=[0,Math.floor(n/4),Math.floor(n/2),Math.floor(3*n/4),n-1];axisPut('#axis24',idx.map(function(i){return {x:(i/(n-1))*100,l:hhmm(H[i].t)};}));}
function axis7(H){const n=H.length;if(!n){$('#axis7').innerHTML='';return;}const loc=FB_LOC[document.documentElement.lang]||'en-GB';const fmt=new Intl.DateTimeFormat(loc,{weekday:'short'});const items=[];let prev=null,start=0;for(let i=0;i<=n;i++){const key=(i<n)?new Date(H[i].t*1000).toDateString():null;if(prev!==null&&key!==prev){const mid=(start+i-1)/2;items.push({x:(mid/(n-1))*100,l:fmt.format(new Date(H[start].t*1000))});start=i;}prev=key;}$('#axis7').innerHTML='';axisPut('#axis7',items);}
async function load(){
  let r,D;
  try{r=await fetch('/api/panel/stats');}catch(e){$('#s-sub').textContent='Could not reach the panel — reload in a moment.';setTimeout(load,30000);return;}
  if(!r.ok){
    if(r.status===401){showLogin(load);return;}
    $('#s-sub').textContent=r.status===429?'Too many requests — wait a minute.':'Could not reach the panel — reload in a moment.';
    setTimeout(load,30000);return;
  }
  try{D=await r.json();}catch(e){setTimeout(load,30000);return;}
  $('#ver').textContent=D.version||'';
  const b=D.blocking||{},paused=b.status==='disabled';
  PAUSED.on=paused;PAUSED.timer=(b.timer==null?null:b.timer);PAUSED.at=Date.now();
  if(paused){
    $('#s-st').classList.remove('ok','wait');$('#s-st').classList.add('bad');$('#s-txt').textContent='Protection: paused';
    $('#s-sub').textContent=b.timer==null?'Paused until you turn it back on':countdown(b.timer);
    $('#btn-resume').classList.remove('hidden');
  }else{
    $('#btn-resume').classList.add('hidden');
    if(D.engine&&D.engine.ok===false){$('#s-st').classList.remove('ok','bad');$('#s-st').classList.add('wait');$('#s-txt').textContent='Protection: checking…';$('#s-sub').textContent='Filter engine starting up — stats will appear shortly.';}
    else if(D.protection_active===false){$('#s-st').classList.remove('ok','wait');$('#s-st').classList.add('bad');$('#s-txt').textContent='Protection: needs attention';$('#s-sub').textContent=(D.lists_ok===false?'Protection lists need attention — the box is repairing them.':'Ad blocking seems off — try restarting the box, or contact support.');}
    else{$('#s-st').classList.remove('wait','bad');$('#s-st').classList.add('ok');$('#s-txt').textContent='Protection: active';$('#s-sub').textContent='Working quietly in the background.';}
  }
  if(D.internet_up===true){$('#n-st').classList.add('ok');$('#n-txt').textContent='Internet: connected';}
  else if(D.internet_up===false){$('#n-st').classList.remove('ok','wait');$('#n-st').classList.add('bad');$('#n-txt').textContent='Internet: not reaching the internet';}
  else{$('#n-st').classList.remove('ok','bad');$('#n-st').classList.add('wait');$('#n-txt').textContent='Internet: checking…';}
  if(D.totals){
    $('#h-num').textContent=fmt(D.totals.queries);
    $('#h-sub').textContent='since midnight';
    $('#h-meta').textContent=fmt(D.totals.gravity)+' domains in your protection lists';
    $('#h-cache').textContent=D.totals.cached?('answered from cache: '+fmt(D.totals.cached)+' · forwarded: '+fmt(D.totals.forwarded)):'';
  }else{$('#h-num').textContent='—';$('#h-sub').textContent='waiting for the filter engine…';$('#h-meta').textContent='';$('#h-cache').textContent='';}
  const CV=D.coverage;
  if(CV&&CV.state){
    const card=$('#cover-card'),line=$('#cover-line');
    if(card)card.style.display='';
    const now=Math.floor(Date.now()/1000);
    const age=CV.ts?Math.max(0,now-CV.ts):9999;
    const waitAge=CV.since?Math.max(0,now-CV.since):0;
    if(PAUSED.on)line.textContent='Protection is paused — filtering is off.';
    else if(CV.released===false&&CV.state==='bypass')line.textContent='Coverage paused — finishing network release…';
    else if(CV.released===false&&(CV.state==='wait'||CV.state==='error'))line.textContent='Network release still finishing — check the box.';
    else if(CV.state==='full'&&D.protection_active!==true)line.textContent=D.protection_active===true?'Filtering is on — coverage status unavailable.':'Coverage status unavailable — check the box.';
    else if(CV.state==='full'&&age>90)line.textContent='Coverage status is out of date — check the box.';
    else if(D.health&&(Math.floor(Date.now()/1000)-Number(D.health.ts||0))<43200&&(((Number((D.totals||{}).gravity)||Number(D.health.gravity))||0)<100000||(Number(D.health.lists_age_days)||0)>9))line.textContent='Protection lists need attention — the box is repairing them.';
    else if(CV.state==='full'&&CV.devices>0)line.textContent='Covered — '+CV.devices+' devices seen on your network';
    else if(CV.state==='full')line.textContent='Coverage is on — devices will appear as they browse.';
    else if(CV.state==='wait'&&CV.reason==='setup')line.textContent=waitAge<20?'Coverage starting…':'Coverage has not started — check the box.';
    else if(CV.state==='wait'&&waitAge<300)line.textContent='Coverage starting…';
    else if(CV.state==='bypass')line.textContent='Coverage paused — the internet is open.';
    else if(CV.state==='off')line.textContent='Coverage is off.';
    else if(CV.state==='error')line.textContent='Coverage could not start — restart the box or contact support.';
    else line.textContent='Coverage unavailable on this network — contact support.';
  }else{
    const card=$('#cover-card');
    if(card){
      if(card){const vv=String(D.version||'0').split('.').map(Number);if(vv[0]>0||vv[1]>=2){card.style.display='';const l=$('#cover-line');if(l)l.textContent=D.coverage_starting?'Coverage starting…':(D.protection_active===true?'Filtering is on — coverage status unavailable.':'Coverage status unavailable — check the box.');}else card.style.display='none';}
    }
  }
  const TT=D.totals||null;
  const qn=TT?(+TT.queries||0):0,bn=TT?(+TT.blocked||0):0,pct=qn?Math.round(1000*bn/qn)/10:0;
  if($('#k-blocked'))$('#k-blocked').textContent=TT?fmt(bn):'—';
  if($('#k-pct'))$('#k-pct').textContent=(TT&&qn)?(pct.toFixed(1)+'%'):'—';
  if($('#k-blocked-sub'))$('#k-blocked-sub').textContent=!TT?'Warming up…':(qn?'ads and trackers':'waiting for traffic');
  const arc=$('#donut-arc');
  if(arc){const C=2*Math.PI*40;arc.setAttribute('stroke-dasharray',((qn?pct:0)/100*C).toFixed(1)+' '+C.toFixed(1));}
  const H=D.history||[];
  const H7=bars7(H);
  $('#chart-meta').textContent=H.length?'Every bar is a slice of the week — taller means more ads blocked.':'The chart fills in as the week goes.';
  axis7(H7);
  rows2('#top',(D.top_blocked||[]).map(x=>({t:x.domain,n:x.count})),'Nothing blocked yet — enjoy the quiet.');
  bars24(D.history24||[]);
  rows2('#topallow',(D.top_allowed||[]).map(x=>({t:x.domain,n:x.count})),'Warming up…');
  rows2('#clients',(D.top_clients||[]).map(x=>({t:x.name||x.ip,n:x.count})),'Warming up…');
  rows2('#ups',(D.upstreams||[]).map(x=>({t:(x.name||x.ip)+(x.pct!=null?(' · '+x.pct+'%'):''),n:x.count})),'Warming up…');
  typesChips(D.types||{});
  setTimeout(load,30000);
}
load();
</script></body></html>"""

SETTINGS_PAGE = r"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>FilterBox — Settings</title><style>
:root{--bg:#0b1020;--card:#141a2e;--ink:#eef1f8;--mut:#9aa3bb;--acc:#5b8cff;--acc2:#8a5bff;--ok:#2ecc71;--warn:#f0a43c;--bad:#ff5c5c;--line:#242c48}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;font:17px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Inter,"Noto Sans",sans-serif;background:radial-gradient(1200px 600px at 50% -10%,#1b2450 0,var(--bg) 55%);color:var(--ink);min-height:100vh}
.wrap{max-width:520px;margin:0 auto;padding:28px 20px 48px}
.top{display:flex;align-items:center;gap:12px;margin:6px 0 20px}
.top a{color:var(--mut);text-decoration:none;font-size:15px;padding:10px 12px;border:1px solid var(--line);border-radius:12px;background:#0e1428}
.top .hex{width:36px;height:36px;flex:none}
.top b{font-size:22px;letter-spacing:.4px}.top b i{font-style:normal;color:var(--acc)}
.cards{display:block}
@media(min-width:780px){.wrap{max-width:1000px}.cards{display:grid;grid-template-columns:1fr 1fr;gap:14px;align-items:start}.cards .card{margin:0}}
.topbar{position:sticky;top:0;z-index:30;display:flex;justify-content:flex-end;align-items:center;padding:6px 0 8px;margin:0 0 6px;background:var(--bg);box-shadow:0 8px 18px rgba(11,16,32,.75)}
.topbar .langpick{margin:0;max-width:190px;width:auto}
.topbar .langsel{padding:8px 32px 8px 12px;font-size:13.5px;border-radius:11px;background-color:#141a2e;border:1px solid var(--line);color-scheme:dark}
option{background:#141a2e;color:var(--ink)}
.card{background:linear-gradient(180deg,rgba(255,255,255,.035),rgba(255,255,255,0)),var(--card);border:1px solid var(--line);border-radius:18px;padding:20px;margin:0 0 14px;box-shadow:0 10px 30px rgba(0,0,0,.35)}
h2{font-size:17px;margin:0 0 10px}h2.danger{color:#ff9b9b}
p{margin:4px 0 10px;color:var(--mut)}
label{display:block;font-size:14px;color:var(--mut);margin:10px 0 6px}
input[type=password],input[type=text]{width:100%;padding:15px 14px;border-radius:12px;border:1px solid var(--line);background:#0e1428;color:var(--ink);font-size:17px;outline:none}
input:focus{border-color:var(--acc)}
.btn{display:block;width:100%;padding:15px;border:0;border-radius:14px;font-size:17px;font-weight:650;color:#fff;background:linear-gradient(100deg,var(--acc),var(--acc2));margin-top:12px;cursor:pointer}
.btn.ghost{background:#0e1428;border:1px solid var(--line);color:var(--ink);font-weight:500}
.btn.danger{background:linear-gradient(100deg,#e5484d,#b3261e)}
.btn[disabled]{opacity:.45}
.err{color:#ffb4b4;background:#33121a;border:1px solid #5c2230;border-radius:12px;padding:11px 13px;margin-top:12px;display:none;font-size:15px}
.checkline{display:flex;gap:11px;align-items:flex-start;margin:16px 0 2px;padding:13px 14px;background:#0e1428;border:1px solid var(--line);border-radius:13px;cursor:pointer;font-size:15px;line-height:1.4}
.checkline input{width:20px;height:20px;margin:1px 0 0;accent-color:#5b8cff;flex:none}
.checkline span{color:var(--mut)}
.checkline b{color:var(--ink);font-weight:650}
.okmsg{color:#c8ffd9;background:#0e2b1b;border:1px solid #1e5c39;border-radius:12px;padding:11px 13px;margin-top:12px;display:none;font-size:15px}
.hidden{display:none!important}
.mut{color:var(--mut);font-size:14px}
.row{display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid var(--line);font-size:15px}
.row:last-child{border-bottom:0}
.row b{font-weight:600;color:var(--ink);text-align:right;word-break:normal;overflow-wrap:anywhere}.row.addr b{display:flex;flex-direction:column;align-items:flex-end;gap:2px;white-space:nowrap;word-break:normal;overflow-wrap:normal;font-size:15px}.row.addr .sub{color:var(--mut);font-weight:500;font-size:14px}
.sheet{position:fixed;inset:0;background:rgba(4,7,16,.78);display:flex;align-items:center;justify-content:center;z-index:50;padding:18px}
.sheet-card{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:22px;width:100%;max-width:520px;box-shadow:0 18px 50px rgba(0,0,0,.5);text-align:center}
#toast{position:fixed;left:12px;top:calc(12px + env(safe-area-inset-top));transform:none;background:#182040;border:1px solid var(--line);color:var(--ink);padding:12px 16px;border-radius:12px;font-size:15px;z-index:70;max-width:min(420px,calc(100vw - 220px));text-align:left;box-shadow:0 8px 24px rgba(0,0,0,.45)}
</style></head><body><div class="wrap">
<div class="topbar"><div class="langpick"><!--FB-LANG-PICK--></div></div>
<div class="top"><a href="/">← Dashboard</a><svg class="hex" viewBox="0 0 48 48" fill="none"><path d="M24 3 43 13.5v21L24 45 5 34.5v-21L24 3Z" stroke="url(#sg)" stroke-width="3"/><path d="M16 24l6 6 11-12" stroke="#5b8cff" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/><defs><linearGradient id="sg" x1="5" y1="3" x2="43" y2="45"><stop stop-color="#5b8cff"/><stop offset="1" stop-color="#8a5bff"/></linearGradient></defs></svg><b>Filter<i>Box</i></b></div>

<div class="cards">
<div class="card">
  <h2>Change password</h2>
  <p class="mut" style="margin:0">This is the password for the dashboard and the advanced view.</p>
  <label for="cp-cur">Current password</label><input type="password" id="cp-cur" autocomplete="current-password">
  <label for="cp-new">New password (at least 8 characters)</label><input type="password" id="cp-new" autocomplete="new-password">
  <label for="cp-rep">Repeat new password</label><input type="password" id="cp-rep" autocomplete="new-password">
  <div class="err" id="cp-err"></div><div class="okmsg" id="cp-ok">Password updated.</div>
  <button class="btn" id="cp-go">Save new password</button>
</div>

<div class="card">
  <h2>Advanced view</h2>
  <p class="mut" style="margin:0">For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.</p>
  <a class="btn ghost" id="adv-link" href="#" target="_blank" rel="noopener">Open advanced view</a>
  <p class="mut" style="margin:8px 0 0">Uses the same password as this page. Changes there affect filtering for the whole home.</p>
</div>

<div class="card">
  <h2>Restart the box</h2>
  <p class="mut" style="margin:0">Takes about a minute. Filtering pauses briefly while it restarts.</p>
  <button class="btn ghost" id="rb-go">Restart now</button>
</div>

<div class="card">
  <h2 class="danger">Factory reset</h2>
  <p class="mut" style="margin:0">Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.</p>
  <button class="btn ghost" id="rs-open">Reset this box…</button>
  <div class="hidden" id="rs-block">
    <label for="rs-conf">Type RESET to confirm</label><input type="text" id="rs-conf" autocomplete="off" placeholder="RESET">
    <label for="rs-pw">Dashboard password</label><input type="password" id="rs-pw" autocomplete="current-password">
    <div class="err" id="rs-err"></div>
    <button class="btn danger" id="rs-go">Erase everything and reset</button>
  </div>
</div>

<div class="card">
  <h2>About</h2>
  <div class="row"><span>Panel version</span><b id="ab-ver">…</b></div>
  <div class="row"><span>Filter engine</span><b id="ab-ftl">…</b></div>
  <div class="row"><span>Uptime</span><b id="ab-up">…</b></div>
  <div class="row addr"><span>Address</span><b id="ab-addr"><span id="ab-ip" dir="ltr">…</span><span class="sub" dir="ltr">filterbox.lan</span></b></div>
</div>
</div>
</div>
<div class="sheet hidden" id="ov"><div class="sheet-card"><h2 id="ov-title">Working…</h2><p class="mut" id="ov-text" style="margin:0">Please wait.</p></div></div>
<div class="sheet hidden" id="login-sheet">
  <div class="sheet-card" style="text-align:left">
    <h2>Enter your dashboard password</h2>
    <input type="password" id="lg-pw" autocomplete="current-password" placeholder="Password">
    <div class="err" id="lg-err"></div>
    <button class="btn" id="lg-go">Continue</button>
    <button class="btn ghost" id="lg-cancel">Cancel</button>
  </div>
</div>
<div id="toast" class="hidden" role="status" aria-live="polite"></div>
<script>
const $=s=>document.querySelector(s);
let TOKEN=sessionStorage.getItem('fb_tok')||'';
let LOGIN_DONE=null;
function toast(t){const el=$('#toast');el.textContent=t;el.classList.remove('hidden');el.style.display='block';clearTimeout(toast._t);toast._t=setTimeout(()=>{el.style.display='';el.classList.add('hidden');},3500);}
function showLogin(done){LOGIN_DONE=done||null;$('#lg-pw').value='';$('#lg-err').style.display='none';$('#login-sheet').classList.remove('hidden');setTimeout(()=>$('#lg-pw').focus(),60);}
$('#lg-cancel').onclick=()=>{$('#login-sheet').classList.add('hidden');LOGIN_DONE=null;};
$('#lg-go').onclick=async()=>{
  let j={};
  try{const r=await fetch('/api/panel/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:$('#lg-pw').value})});j=await r.json();}catch(e){}
  if(j.ok&&j.token){TOKEN=j.token;sessionStorage.setItem('fb_tok',TOKEN);$('#login-sheet').classList.add('hidden');const d=LOGIN_DONE;LOGIN_DONE=null;if(d)d();}
  else{$('#lg-err').textContent=j.error||"That password doesn't match — try again.";$('#lg-err').style.display='block';}
};
$('#lg-pw').addEventListener('keydown',e=>{if(e.key==='Enter')$('#lg-go').click();});
async function act(path,body,onOk,opts){
  let r,j={};
  try{r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-FB-Token':TOKEN},body:JSON.stringify(body||{})});j=await r.json();}
  catch(e){toast('Could not reach the panel — reload in a moment.');return;}
  if(r.status===401){showLogin(()=>act(path,body,onOk,opts));return;}
  if(!r.ok||!j.ok){const msg=j.error||(r.status===429?'Too many requests — wait a minute.':'Something went wrong — try again.');if(opts&&opts.errEl){opts.errEl.textContent=msg;opts.errEl.style.display='block';}else{toast(msg);}return;}
  if(onOk)onOk(j);
}
$('#cp-go').onclick=()=>{
  const cur=$('#cp-cur').value,nu=$('#cp-new').value,rep=$('#cp-rep').value;
  $('#cp-err').style.display='none';$('#cp-ok').style.display='none';
  if(nu.length<8){$('#cp-err').textContent='Password must be at least 8 characters.';$('#cp-err').style.display='block';return;}
  if(nu!==rep){$('#cp-err').textContent='The two new passwords don’t match.';$('#cp-err').style.display='block';return;}
  act('/api/panel/password',{current:cur,new:nu},()=>{
    $('#cp-ok').style.display='block';$('#cp-cur').value='';$('#cp-new').value='';$('#cp-rep').value='';
  },{errEl:$('#cp-err')});
};
$('#rb-go').onclick=()=>{
  if($('#rb-go').disabled)return;
  $('#rb-go').textContent='Restart now? Tap again to confirm';
  if(!$('#rb-go').dataset.armed){$('#rb-go').dataset.armed='1';setTimeout(()=>{if($('#rb-go').dataset.armed&&!$('#rb-go').disabled){$('#rb-go').dataset.armed='';$('#rb-go').textContent='Restart now';}},4000);return;}
  $('#rb-go').dataset.armed='';$('#rb-go').disabled=true;$('#rb-go').textContent='Restarting…';
  act('/api/panel/reboot',{},()=>waitBack('Back online.','This takes about a minute. Filtering pauses briefly while it restarts.'),{});
};
function waitBack(doneText,startText){
  $('#ov-title').textContent='Restarting the box';
  $('#ov-text').textContent=startText;
  $('#ov').classList.remove('hidden');
  const t0=Date.now();
  const iv=setInterval(async()=>{
    if(Date.now()-t0>300000){clearInterval(iv);$('#ov-title').textContent='Still working…';$('#ov-text').textContent="The box hasn't come back yet. Check that it's powered on, then reload this page.";return;}
    try{const r=await fetch('/api/health');if(r.ok){clearInterval(iv);$('#ov-title').textContent=doneText;$('#ov-text').textContent='Reloading…';setTimeout(()=>location.href='/',1200);}}catch(e){}
  },3000);
}
$('#rs-open').onclick=()=>$('#rs-block').classList.remove('hidden');
$('#rs-go').onclick=()=>{
  $('#rs-err').style.display='none';
  const c=$('#rs-conf').value.trim(),pw=$('#rs-pw').value;
  if(c!=='RESET'){$('#rs-err').textContent='Type RESET exactly to confirm.';$('#rs-err').style.display='block';return;}
  act('/api/panel/reset',{password:pw,confirm:c},()=>{
    $('#ov-title').textContent='Resetting the box';
    $('#ov-text').textContent='Erasing settings and returning to setup mode — the box will restart.';
    $('#ov').classList.remove('hidden');
    const t0=Date.now();
    const iv=setInterval(async()=>{
      if(Date.now()-t0>360000){clearInterval(iv);$('#ov-text').textContent="The box hasn't come back yet. Check that it's powered on, then reload this page.";return;}
      try{const r=await fetch('/api/health');if(r.ok){clearInterval(iv);$('#ov-text').textContent='Back to setup — reloading…';setTimeout(()=>location.href='/',1500);}}catch(e){}
    },3000);
  },{errEl:$('#rs-err')});
};
function fmtUp(s){const d=Math.floor(s/86400),h=Math.floor((s%86400)/3600),m=Math.floor((s%3600)/60);return d?d+' d '+h+' h ':(h?h+' h '+m+' min':m+' min');}
$('#adv-link').href='http://'+(location.hostname||'filterbox.local')+':8089/admin/';
(async()=>{
  try{
    const r=await fetch('/api/panel/stats');const D=await r.json();
    $('#ab-ver').textContent=D.version||'—';
    $('#ab-ftl').textContent=D.ftl_version||'—';
    $('#ab-up').textContent=D.uptime_seconds?fmtUp(D.uptime_seconds):'—';
  }catch(e){}
  try{
    const r=await fetch('/api/status');const S=await r.json();
    const ip=(S.ips&&S.ips[0]&&S.ips[0].ip)||'';
    // Always show a usable URL first: the IP works on every device. The names are
    // conveniences — .local for mDNS hosts (Mac/Windows), .lan for phones/tablets
    // (Android has no mDNS). A bare name without the scheme makes Chrome fall back
    // to a Google search when the name does not resolve, which looks like a bug.
    $('#ab-ip').textContent=ip?('http://'+ip):'';
    $('#ab-ip').style.display=ip?'':'none';
  }catch(e){}
})();
</script></body></html>"""

LIMIT_PAGE = r"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>FilterBox</title><style>
body{margin:0;font:17px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Inter,"Noto Sans",sans-serif;background:#0b1020;color:#eef1f8;display:flex;min-height:100vh;align-items:center;justify-content:center;text-align:center}
.w{max-width:420px;padding:24px}a{color:#5b8cff}
</style></head><body><div class="w"><h1>Too many requests</h1><p style="color:#9aa3bb">Wait a minute, then <a href="/">reload the dashboard</a>.</p></div></body></html>"""

NOT_FOUND_PAGE = r"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>FilterBox</title><style>
body{margin:0;font:17px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Inter,"Noto Sans",sans-serif;background:#0b1020;color:#eef1f8;display:flex;min-height:100vh;align-items:center;justify-content:center;text-align:center}
.w{max-width:420px;padding:24px}a{color:#5b8cff}
</style></head><body><div class="w"><h1>Nothing here</h1><p style="color:#9aa3bb">That page doesn't exist. <a href="/">Back to FilterBox</a>.</p></div></body></html>"""

# ------------------------------------------------------------------ i18n ----
LANG_COOKIE = 'fb_lang'
LANGS = ('en', 'he', 'ar', 'ru', 'es', 'fr', 'pt', 'de', 'it', 'tr', 'hi', 'id', 'vi', 'zh', 'ja', 'ko', 'th', 'lo')
LANG_LABELS = (
    ('en', 'English'), ('he', 'עברית'), ('ar', 'العربية'), ('ru', 'Русский'),
    ('es', 'Español'), ('fr', 'Français'), ('pt', 'Português'), ('de', 'Deutsch'),
    ('it', 'Italiano'), ('tr', 'Türkçe'), ('hi', 'हिन्दी'), ('id', 'Bahasa Indonesia'),
    ('vi', 'Tiếng Việt'), ('zh', '中文'), ('ja', '日本語'), ('ko', '한국어'),
    ('th', 'ไทย'), ('lo', 'ລາວ'),
)
RTL_LANGS = ('he', 'ar')
I18N = json.loads(r"""{"he":{"FilterBox — Setup":"FilterBox — הגדרה","Your filter box is online 🎉":"קופסת הסינון שלכם באוויר 🎉","Checking your setup…":"בודקים את ההתקנה…","Protection…":"הגנה…","Internet…":"אינטרנט…","Get started":"מתחילים","Choose your admin password":"בחרו סיסמת מנהל","This protects your filter's settings page. Write it down somewhere safe.":"הסיסמה מגנה על עמוד ההגדרות של הקופסה. כתבו אותה במקום בטוח.","Password (at least 8 characters)":"סיסמה (8 תווים לפחות)","Repeat password":"חזרה על הסיסמה","Save password":"שמירת הסיסמה","Internet connection":"חיבור לאינטרנט","Choose how this box reaches the internet.":"בחרו איך הקופסה מתחברת לאינטרנט.","Ethernet":"אתרנט","Scan for Wi-Fi networks":"סריקת רשתות Wi-Fi","Wi-Fi password":"סיסמת Wi-Fi","Connect":"התחברות","Continue":"המשך","All set! 🛡️":"הכל מוכן! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"הרשת שלכם מוגנת עכשיו. פרסומות ועוקבים מסוננים בכל מכשיר שמשתמש בקופסה.","Opening your dashboard…":"פותחים את לוח הבקרה…","Open dashboard":"פתיחת לוח הבקרה","Setup already complete":"ההתקנה כבר הושלמה","This box has already been set up. Head to the dashboard to see how it's doing.":"הקופסה הזו כבר הוגדרה. עברו ללוח הבקרה כדי לראות שהכל עובד.","· your data stays on this device":"· הנתונים נשארים במכשיר הזה","Bad response":"תגובה שגויה","Protection: active":"הגנה: פעילה","Protection: warming up":"הגנה: מתחילה לפעול","Internet: connected":"אינטרנט: מחובר","Internet: not yet":"אינטרנט: עוד רגע","This box: ":"הקופסה: ","Good news — filtering is already working.":"חדשות טובות — הסינון כבר עובד.","Almost there — let’s finish the quick setup.":"כמעט סיימנו — נשלים את ההגדרה המהירה.","Ethernet: cable connected":"אתרנט: הכבל מחובר","Ethernet: no cable detected":"אתרנט: לא זוהה כבל","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"יש Wi-Fi בקופסה — אפשר להשתמש בו, או להישאר עם אתרנט.","This box filters through its network cable — nothing to configure here.":"הקופסה מסננת דרך כבל הרשת — אין כאן מה להגדיר.","Password needs at least 8 characters.":"הסיסמה חייבת להכיל לפחות 8 תווים.","The two passwords don’t match.":"הסיסמאות אינן זהות.","Something went wrong.":"משהו השתבש.","Saving…":"שומרים…","Scanning…":"סורקים…","Scan again":"סריקה מחדש","Password for “":"סיסמה עבור “","Connecting…":"מתחברים…","Connected.":"מחובר.","Could not connect.":"החיבור נכשל.","Not ready yet.":"עוד לא מוכן.","No networks found. Try again, or keep using Ethernet.":"לא נמצאו רשתות. נסו שוב, או הישארו עם אתרנט.","Checking on your filter…":"בודקים את הסינון…","Turn back on":"החזרת ההגנה","blocked today":"נחסמו היום","Last 7 days":"7 הימים האחרונים","Top blocked today":"הנחסמים המובילים היום","Warming up…":"מתחממים…","Nothing blocked yet — enjoy the quiet.":"עוד לא נחסם כלום — תיהנו מהשקט.","Pause filtering?":"להשהות את הסינון?","Filtering will pause for a short break.":"הסינון ייעצר להפסקה קצרה.","Pause 30 minutes":"השהיה ל־30 דקות","Pause 1 hour":"השהיה לשעה","Pause until I turn it back on":"השהיה עד שאחזיר לפעולה","Cancel":"ביטול","Enter your dashboard password":"הזינו את סיסמת לוח הבקרה","Password":"סיסמה","Settings":"הגדרות","Tap to pause filtering":"הקשו כדי להשהות את הסינון","Back in ":"חזרה בעוד ","Back in ~":"חזרה בעוד ~"," h ":" ש׳ "," min":" דק׳","Could not reach the panel — reload in a moment.":"לא הצלחנו להגיע ללוח הבקרה — רעננו בעוד רגע.","Too many requests — wait a minute.":"יותר מדי בקשות — המתינו דקה.","Something went wrong — try again.":"משהו השתבש — נסו שוב.","Paused until you turn it back on.":"הסינון מושהה עד שתחזירו לפעולה.","Paused for 30 minutes.":"הסינון מושהה ל־30 דקות.","Paused for 1 hour.":"הסינון מושהה לשעה.","Protection is back on.":"ההגנה חזרה לפעול.","Paused until you turn it back on":"מושהה עד שתחזירו לפעולה","Protection: paused":"הגנה: מושהית","Protection: checking…":"הגנה: בודקים…","Protection: needs attention":"הגנה: דורשת טיפול","Filter engine starting up — stats will appear shortly.":"מנוע הסינון עולה — הסטטיסטיקות יופיעו עוד רגע.","Ad blocking seems off — try restarting the box, or contact support.":"נראה שחסימת הפרסומות כבויה — נסו לאתחל את הקופסה, או פנו לתמיכה.","Working quietly in the background.":"עובדת בשקט ברקע.","Internet: not reaching the internet":"אינטרנט: אין גישה לאינטרנט","Internet: checking…":"אינטרנט: בודקים…","waiting for the filter engine…":"ממתינים למנוע הסינון…","% of all queries · ":"% מכל השאילתות · "," domains in your protection lists":" דומיינים ברשימות ההגנה","Every bar is a slice of the week — taller means more ads blocked.":"כל עמודה היא קטע מהשבוע — גבוהה יותר, יותר פרסומות נחסמו.","The chart fills in as the week goes.":"התרשים מתמלא ככל שהשבוע מתקדם.","That password doesn't match — try again.":"הסיסמה לא נכונה — נסו שוב."," blocked":" חסומים","FilterBox — Settings":"FilterBox — הגדרות","← Dashboard":"→ לוח הבקרה","Change password":"החלפת סיסמה","This is the password for the dashboard and the advanced view.":"זו הסיסמה של לוח הבקרה והתצוגה המתקדמת.","Current password":"סיסמה נוכחית","New password (at least 8 characters)":"סיסמה חדשה (8 תווים לפחות)","Repeat new password":"חזרה על הסיסמה החדשה","Password updated.":"הסיסמה עודכנה.","Save new password":"שמירת הסיסמה החדשה","Restart the box":"אתחול הקופסה","Takes about a minute. Filtering pauses briefly while it restarts.":"לוקח בערך דקה. הסינון מושהה לזמן קצר בזמן האתחול.","Restart now":"אתחול עכשיו","Factory reset":"איפוס מלא","Reset this box…":"איפוס הקופסה…","Type RESET to confirm":"הקלידו RESET לאישור","Dashboard password":"סיסמת לוח הבקרה","Erase everything and reset":"מחיקת הכל ואיפוס","About":"אודות","Panel version":"גרסת לוח הבקרה","Filter engine":"מנוע הסינון","Uptime":"זמן פעילות","Address":"כתובת","Working…":"עובדים…","Please wait.":"המתינו בבקשה.","Password must be at least 8 characters.":"הסיסמה חייבת להכיל לפחות 8 תווים.","The two new passwords don’t match.":"הסיסמאות החדשות אינן זהות.","Restart now? Tap again to confirm":"לאתחל עכשיו? הקישו שוב לאישור","Restarting…":"מאתחל…","Back online.":"חזרנו לאוויר.","This takes about a minute. Filtering pauses briefly while it restarts.":"זה לוקח בערך דקה. הסינון מושהה לזמן קצר בזמן האתחול.","Restarting the box":"מאתחלים את הקופסה","Still working…":"עדיין עובדים…","Reloading…":"מרעננים…","Type RESET exactly to confirm.":"הקלידו RESET בדיוק כפי שכתוב לאישור.","Resetting the box":"מאפסים את הקופסה","Erasing settings and returning to setup mode — the box will restart.":"מוחקים הגדרות וחוזרים למצב התקנה — הקופסה תתאתחל.","Back to setup — reloading…":"חזרה למצב התקנה — מרעננים…"," d ":" י׳ ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"הקופסה עוד לא חזרה. בדקו שהיא מחוברת לחשמל ורעננו את הדף.","Too many requests":"יותר מדי בקשות","Wait a minute, then ":"המתינו דקה, ואז ","reload the dashboard":"רעננו את לוח הבקרה","Nothing here":"כאן אין כלום","That page doesn't exist.":"הדף הזה לא קיים.","Back to FilterBox":"חזרה ל-FilterBox","not found":"לא נמצא","Too many attempts — wait a minute.":"יותר מדי ניסיונות — המתינו דקה.","Session expired — enter the password again.":"פג תוקף החיבור — הזינו את הסיסמה שוב.","Pick 30 minutes, 1 hour, or until you turn it back on.":"בחרו 30 דקות, שעה, או עד שתחזירו לפעולה.","Setup is already complete.":"ההתקנה כבר הושלמה.","That's not the current password — try again.":"הסיסמה הנוכחית שגויה — נסו שוב.","Password is too long (max 128 characters).":"הסיסמה ארוכה מדי (עד 128 תווים).","Couldn't start the restart — check that the box is powered, then try again.":"לא הצלחנו להתחיל את האתחול — בדקו שהקופסה מחוברת לחשמל ונסו שוב.","Could not set the password (service not ready?). Try again in a moment.":"לא הצלחנו לשמור את הסיסמה (המערכת עוד עולה?). נסו שוב בעוד רגע.","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"לא זוהה מתאם Wi-Fi בקופסה — היא עובדת עם אתרנט. הכל מוכן.","Pick a network and enter its password (at least 8 chars).":"בחרו רשת והקלידו את הסיסמה (8 תווים לפחות).","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"אין מתאם Wi-Fi בקופסה — אתרנט היא הדרך. אין כאן מה לעשות.","Wi-Fi tools are not available on this box.":"כלי ה-Wi-Fi לא זמינים בקופסה הזו.","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"הגדרות ה-Wi-Fi נשמרו, אבל עוד אין כתובת — המתינו רגע ורעננו את הדף.","Set an admin password first.":"צריך קודם לבחור סיסמת מנהל.","Connected to ":"מחובר אל ","Could not update Wi-Fi config: ":"לא הצלחנו לעדכן את הגדרות ה-Wi-Fi: ","queries today":"שאילתות היום"," blocked (":" חסומים (","answered from cache: ":"נענו מהמטמון: "," · forwarded: ":" · הועברו הלאה: ","Today":"היום","Each bar is 10 minutes — the purple part was blocked.":"כל עמודה היא 10 דקות — החלק הסגול נחסם.","The chart fills in as the day goes.":"התרשים מתמלא ככל שהיום מתקדם.","Most visited today":"הנצפים ביותר היום","Busiest devices":"המכשירים העסוקים ביותר","Where answers came from":"מאיפה הגיעו התשובות","Traffic mix":"תמהיל השאילתות","Advanced view":"תצוגה מתקדמת","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"למשתמשים מתקדמים — לוח טכני מלא: יומן שאילתות, ניהול רשימות חסימה והגדרות מפורטות.","Open advanced view":"פתיחת התצוגה המתקדמת","Uses the same password as this page. Changes there affect filtering for the whole home.":"זו אותה סיסמה של העמוד הזה. שינויים שם משפיעים על הסינון בכל הבית.","Whole home":"כל הבית","Covered — ":"מכוסה — "," devices seen on your network":" מכשירים ברשת שלכם","Protection is paused — filtering is off.":"ההגנה מושהית — הסינון כבוי.","Coverage paused — finishing network release…":"הכיסוי מושהה — משחררים את הרשת…","Protection starts as soon as setup is finished.":"ההגנה תתחיל ברגע שההגדרה תסתיים.","Coverage is on — devices will appear as they browse.":"הכיסוי פעיל — מכשירים יופיעו כשהם יגלשו.","Coverage starting…":"הכיסוי מתחיל…","Coverage paused — the internet is open.":"הכיסוי מושהה — האינטרנט פתוח.","Coverage is off.":"הכיסוי כבוי.","Coverage has not started — check the box.":"הכיסוי לא התחיל — בדקו את הקופסה.","Coverage status unavailable — check the box.":"מצב הכיסוי לא זמין — בדקו את הקופסה.","Protection: starts after setup":"הגנה: מתחילה אחרי ההגדרה","Finish setup to switch protection on for the whole home.":"סיימו את ההגדרה כדי להפעיל הגנה לכל הבית.","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"ההגדרה הושלמה. ההגנה נדלקת לכל הבית — בלוח הבקרה רואים את ההתקדמות.","Coverage status is out of date — check the box.":"מצב הכיסוי לא מעודכן — בדקו את הקופסה.","Coverage unavailable on this network — contact support.":"הכיסוי לא זמין ברשת הזו — פנו לתמיכה.","Network release still finishing — check the box.":"שחרור הרשת עוד מסתיים — בדקו את הקופסה.","Coverage could not start — restart the box or contact support.":"הכיסוי לא הצליח להתחיל — אתחלו את הקופסה או פנו לתמיכה.","Internal error — try again.":"שגיאה פנימית — נסו שוב.","That network name is not supported — choose another network.":"שם הרשת הזה אינו נתמך — בחרו רשת אחרת.","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"מוחק את סיסמת לוח הבקרה, ההגדרות והסטטיסטיקות. הסינון ממשיך לפעול, והגדרות ה-Wi-Fi נשמרות. אין דרך לבטל פעולה זו — אם תשכחו את הסיסמה, החזיקו את כפתור RESET בקופסה למשך 5 שניות.","Protection lists need attention — the box is repairing them.":"רשימות ההגנה דורשות טיפול — הקופסה מתקנת אותן.","Filtering is on — coverage status unavailable.":"הסינון פועל — מצב הכיסוי לא זמין.","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"רשימות ההגנה עוד בהכנה — השאירו את הקופסה מחוברת לחשמל ולרשת ונסו שוב בעוד כמה דקות.","Filtering is already running for your whole home.":"הסינון כבר פועל בכל הבית.","Protection is starting — no action needed.":"ההגנה מתחילה — אין צורך לעשות דבר.","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"לוח הבקרה והסטטיסטיקות הם אופציונליים. הגדירו סיסמה כדי להשתמש בהם — אחרת פשוט סגרו את הדף ותיהנו מהשקט.","Set up the dashboard":"הגדרת לוח הבקרה","Choose your dashboard password":"בחרו סיסמה ללוח הבקרה","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"הסיסמה מגנה על לוח הבקרה ועל התצוגה המתקדמת. כתבו אותה במקום בטוח. אם תשכחו אותה, החזיקו את כפתור RESET בקופסה למשך 5 שניות.","You're all set 🛡️":"הכל מוכן 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"הסינון כבר פועל בכל הבית — לוח הבקרה מראה איך הולך.","Queries today":"שאילתות היום","Blocked":"נחסמו","Blocked share":"חלק החסימות","ads and trackers":"פרסומות ועוקבים","lookups today":"פניות היום","Each bar is 10 minutes · busiest:":"כל עמודה היא 10 דקות · השיא:","since midnight":"מאז חצות","waiting for traffic":"ממתינים לתנועה","Queries":"שאילתות","Keep the box updated automatically":"לעדכן את הקופסה אוטומטית","Security fixes and filtering improvements only — no personal data leaves the box.":"רק תיקוני אבטחה ושיפורי סינון — שום מידע אישי לא יוצא מהקופסה.","Share anonymous diagnostic reports":"שיתוף דוחות אבחון אנונימיים","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"יומני שגיאות ובדיקות תקינות שעוזרים לנו לתקן בעיות. ללא היסטוריית גלישה, ללא שמות מכשירים, ללא מידע אישי — רק פרטים טכניים אנונימיים, שנשלחים אלינו באופן פרטי.","Language":"שפה","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"הקופסה לא זיהתה את הכתובת שממנה נפתח הדף. פתחו http://filterbox.lan ונסו שוב.","Pause":"השהיה","This dashboard is private to your home. Enter the password you chose during setup.":"לוח הבקרה הזה פרטי לבית שלכם. הזינו את הסיסמה שבחרתם בזמן ההתקנה.","FilterBox — Sign in":"FilterBox — התחברות"," queries · ":" שאילתות · ","Wait a minute, then":"המתינו דקה, ואז "},"ru":{"FilterBox — Setup":"FilterBox — Настройка","Your filter box is online 🎉":"Ваш фильтр онлайн 🎉","Checking your setup…":"Проверяем вашу настройку…","Protection…":"Защита…","Internet…":"Интернет…","Get started":"Начать","Choose your admin password":"Придумайте пароль администратора","This protects your filter's settings page. Write it down somewhere safe.":"Он защищает страницу настроек вашего фильтра. Запишите его в надёжном месте.","Password (at least 8 characters)":"Пароль (не менее 8 символов)","Repeat password":"Повторите пароль","Save password":"Сохранить пароль","Internet connection":"Подключение к интернету","Choose how this box reaches the internet.":"Выберите, как коробочка подключается к интернету.","Scan for Wi-Fi networks":"Поиск сетей Wi-Fi","Wi-Fi password":"Пароль Wi-Fi","Connect":"Подключиться","Continue":"Продолжить","All set! 🛡️":"Всё готово! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"Ваша сеть теперь под защитой. Реклама и трекеры фильтруются на всех устройствах в вашей сети.","Opening your dashboard…":"Открываем панель управления…","Open dashboard":"Открыть панель","Setup already complete":"Настройка уже завершена","This box has already been set up. Head to the dashboard to see how it's doing.":"Эта коробочка уже настроена. Откройте панель, чтобы посмотреть, как дела.","· your data stays on this device":"· ваши данные остаются на этом устройстве","Bad response":"Некорректный ответ","Protection: active":"Защита: активна","Protection: warming up":"Защита: запускается","Internet: connected":"Интернет: подключён","Internet: not yet":"Интернет: ещё нет","This box: ":"Эта коробочка: ","Good news — filtering is already working.":"Хорошие новости — фильтрация уже работает.","Almost there — let’s finish the quick setup.":"Почти готово — завершим быструю настройку.","Ethernet: cable connected":"Ethernet: кабель подключён","Ethernet: no cable detected":"Ethernet: кабель не обнаружен","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"На коробочке есть Wi-Fi — можно им воспользоваться или оставить Ethernet.","This box filters through its network cable — nothing to configure here.":"Коробочка фильтрует через сетевой кабель — здесь ничего настраивать не нужно.","Password needs at least 8 characters.":"Пароль должен быть не короче 8 символов.","The two passwords don’t match.":"Пароли не совпадают.","Something went wrong.":"Что-то пошло не так.","Saving…":"Сохраняем…","Scanning…":"Сканируем…","Scan again":"Искать снова","Password for “":"Пароль для “","Connecting…":"Подключаемся…","Connected.":"Подключено.","Could not connect.":"Не удалось подключиться.","Not ready yet.":"Ещё не готово.","No networks found. Try again, or keep using Ethernet.":"Сети не найдены. Попробуйте ещё раз или оставьте Ethernet.","Checking on your filter…":"Проверяем фильтр…","Turn back on":"Включить обратно","blocked today":"заблокировано сегодня","Last 7 days":"Последние 7 дней","Top blocked today":"Топ блокировок за сегодня","Warming up…":"Прогреваемся…","Nothing blocked yet — enjoy the quiet.":"Пока ничего не заблокировано — наслаждайтесь тишиной.","Pause filtering?":"Приостановить фильтрацию?","Filtering will pause for a short break.":"Фильтрация приостановится на короткую паузу.","Pause 30 minutes":"Пауза на 30 минут","Pause 1 hour":"Пауза на 1 час","Pause until I turn it back on":"Пауза до ручного включения","Cancel":"Отмена","Enter your dashboard password":"Введите пароль от панели","Password":"Пароль","Settings":"Настройки","Tap to pause filtering":"Нажмите, чтобы приостановить фильтрацию","Back in ":"Возврат через ","Back in ~":"Возврат через ~"," h ":" ч "," min":" мин","Could not reach the panel — reload in a moment.":"Не удалось связаться с панелью — обновите страницу через минуту.","Too many requests — wait a minute.":"Слишком много запросов — подождите минуту.","Something went wrong — try again.":"Что-то пошло не так — попробуйте ещё раз.","Paused until you turn it back on.":"Фильтрация приостановлена до ручного включения.","Paused for 30 minutes.":"Фильтрация приостановлена на 30 минут.","Paused for 1 hour.":"Фильтрация приостановлена на 1 час.","Protection is back on.":"Защита снова включена.","Paused until you turn it back on":"Приостановлено до ручного включения","Protection: paused":"Защита: на паузе","Protection: checking…":"Защита: проверяем…","Protection: needs attention":"Защита: требует внимания","Filter engine starting up — stats will appear shortly.":"Движок фильтрации запускается — статистика появится с минуты на минуту.","Ad blocking seems off — try restarting the box, or contact support.":"Похоже, блокировка рекламы отключена — попробуйте перезагрузить коробочку или обратитесь в поддержку.","Working quietly in the background.":"Тихо работает в фоне.","Internet: not reaching the internet":"Интернет: нет доступа в интернет","Internet: checking…":"Интернет: проверяем…","waiting for the filter engine…":"ждём движок фильтрации…","% of all queries · ":"% всех запросов · "," domains in your protection lists":" доменов в списках защиты","Every bar is a slice of the week — taller means more ads blocked.":"Каждый столбик — часть недели: выше значит больше рекламы заблокировано.","The chart fills in as the week goes.":"График наполняется по ходу недели.","That password doesn't match — try again.":"Пароль не подходит — попробуйте ещё раз."," blocked":" заблокировано","FilterBox — Settings":"FilterBox — Настройки","← Dashboard":"← Панель","Change password":"Смена пароля","This is the password for the dashboard and the advanced view.":"Это пароль от панели управления и расширенного режима.","Current password":"Текущий пароль","New password (at least 8 characters)":"Новый пароль (не менее 8 символов)","Repeat new password":"Повторите новый пароль","Password updated.":"Пароль обновлён.","Save new password":"Сохранить новый пароль","Restart the box":"Перезагрузка коробочки","Takes about a minute. Filtering pauses briefly while it restarts.":"Занимает около минуты. Фильтрация ненадолго приостановится.","Restart now":"Перезагрузить сейчас","Factory reset":"Полный сброс","Reset this box…":"Сбросить коробочку…","Type RESET to confirm":"Введите RESET для подтверждения","Dashboard password":"Пароль панели","Erase everything and reset":"Стереть всё и сбросить","About":"О системе","Panel version":"Версия панели","Filter engine":"Движок фильтрации","Uptime":"Время работы","Address":"Адрес","Working…":"Выполняется…","Please wait.":"Подождите, пожалуйста.","Password must be at least 8 characters.":"Пароль должен быть не короче 8 символов.","The two new passwords don’t match.":"Новые пароли не совпадают.","Restart now? Tap again to confirm":"Перезагрузить? Нажмите ещё раз для подтверждения","Restarting…":"Перезагрузка…","Back online.":"Снова онлайн.","This takes about a minute. Filtering pauses briefly while it restarts.":"Это займёт около минуты. Фильтрация ненадолго приостановится.","Restarting the box":"Перезагружаем коробочку","Still working…":"Всё ещё работаем…","Reloading…":"Обновляем…","Type RESET exactly to confirm.":"Введите RESET точно, чтобы подтвердить.","Resetting the box":"Сбрасываем коробочку","Erasing settings and returning to setup mode — the box will restart.":"Стираем настройки и возвращаемся в режим настройки — коробочка перезагрузится.","Back to setup — reloading…":"Снова настройка — обновляем…"," d ":" д ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"Коробочка ещё не вернулась. Проверьте, что она включена, и обновите страницу.","Too many requests":"Слишком много запросов","Wait a minute, then ":"Подождите минуту, затем ","reload the dashboard":"обновите панель","Nothing here":"Здесь ничего нет","That page doesn't exist.":"Такой страницы не существует.","Back to FilterBox":"Вернуться в FilterBox","not found":"не найдено","Too many attempts — wait a minute.":"Слишком много попыток — подождите минуту.","Session expired — enter the password again.":"Сеанс истёк — введите пароль снова.","Pick 30 minutes, 1 hour, or until you turn it back on.":"Выберите 30 минут, 1 час или до ручного включения.","Setup is already complete.":"Настройка уже завершена.","That's not the current password — try again.":"Это не текущий пароль — попробуйте ещё раз.","Password is too long (max 128 characters).":"Пароль слишком длинный (максимум 128 символов).","Couldn't start the restart — check that the box is powered, then try again.":"Не удалось запустить перезагрузку — проверьте, что коробочка включена, и попробуйте ещё раз.","Could not set the password (service not ready?). Try again in a moment.":"Не удалось сохранить пароль (сервис ещё не готов?). Попробуйте через минуту.","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"Wi-Fi-адаптер не обнаружен — коробочка работает через Ethernet. Всё готово.","Pick a network and enter its password (at least 8 chars).":"Выберите сеть и введите пароль (не менее 8 символов).","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"Wi-Fi-адаптера на коробочке нет — используйте Ethernet. Здесь делать нечего.","Wi-Fi tools are not available on this box.":"Средства Wi-Fi недоступны на этой коробочке.","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"Настройки Wi-Fi сохранены, но адрес ещё не получен — подождите минуту и обновите страницу.","Set an admin password first.":"Сначала задайте пароль администратора.","Connected to ":"Подключено к ","Could not update Wi-Fi config: ":"Не удалось обновить конфигурацию Wi-Fi: ","queries today":"запросов сегодня"," blocked (":" заблокировано (","answered from cache: ":"из кэша: "," · forwarded: ":" · переслано: ","Today":"Сегодня","Each bar is 10 minutes — the purple part was blocked.":"Каждый столбик — 10 минут; фиолетовая часть заблокирована.","The chart fills in as the day goes.":"График наполняется по ходу дня.","Most visited today":"Чаще всего открывают","Busiest devices":"Самые активные устройства","Where answers came from":"Откуда пришли ответы","Traffic mix":"Типы запросов","Advanced view":"Расширенный режим","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"Для опытных пользователей — полная техническая панель: журнал запросов, управление списками блокировки и подробные настройки.","Open advanced view":"Открыть расширенный режим","Uses the same password as this page. Changes there affect filtering for the whole home.":"Используется тот же пароль, что и здесь. Изменения там влияют на фильтрацию во всём доме.","Whole home":"Весь дом","Covered — ":"Под защитой — "," devices seen on your network":" устройств в вашей сети","Protection is paused — filtering is off.":"Защита приостановлена — фильтрация отключена.","Coverage paused — finishing network release…":"Покрытие приостановлено — завершаем освобождение сети…","Protection starts as soon as setup is finished.":"Защита начнётся сразу после завершения настройки.","Coverage is on — devices will appear as they browse.":"Покрытие включено — устройства появятся, когда начнут работать.","Coverage starting…":"Покрытие запускается…","Coverage paused — the internet is open.":"Покрытие приостановлено — интернет открыт.","Coverage is off.":"Покрытие отключено.","Coverage has not started — check the box.":"Покрытие не запустилось — проверьте коробочку.","Coverage status unavailable — check the box.":"Статус покрытия недоступен — проверьте коробочку.","Protection: starts after setup":"Защита: начнётся после настройки","Finish setup to switch protection on for the whole home.":"Завершите настройку, чтобы включить защиту для всего дома.","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"Настройка завершена. Защита включается для всего дома — прогресс виден на панели.","Coverage status is out of date — check the box.":"Статус покрытия устарел — проверьте коробочку.","Coverage unavailable on this network — contact support.":"Покрытие недоступно в этой сети — обратитесь в поддержку.","Network release still finishing — check the box.":"Освобождение сети ещё завершается — проверьте коробочку.","Coverage could not start — restart the box or contact support.":"Покрытие не запустилось — перезагрузите коробочку или обратитесь в поддержку.","Internal error — try again.":"Внутренняя ошибка — попробуйте ещё раз.","That network name is not supported — choose another network.":"Это имя сети не поддерживается — выберите другую сеть.","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"Стирает пароль панели, настройки и статистику. Фильтрация продолжает работать, настройки Wi-Fi сохраняются. Действие необратимо — если забудете пароль, удерживайте кнопку RESET на коробочке 5 секунд.","Protection lists need attention — the box is repairing them.":"Списки защиты требуют внимания — коробочка их восстанавливает.","Filtering is on — coverage status unavailable.":"Фильтрация работает — статус покрытия недоступен.","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"Списки защиты ещё готовятся — оставьте коробочку включённой и подключённой к сети и попробуйте снова через несколько минут.","Filtering is already running for your whole home.":"Фильтрация уже работает для всего дома.","Protection is starting — no action needed.":"Защита запускается — ничего делать не нужно.","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"Панель и статистика необязательны. Задайте пароль, чтобы пользоваться ими, — или просто закройте страницу и наслаждайтесь тишиной.","Set up the dashboard":"Настроить панель","Choose your dashboard password":"Придумайте пароль для панели","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"Он защищает панель и расширенный режим. Запишите его в надёжном месте. Если забудете — удерживайте кнопку RESET на коробочке 5 секунд.","You're all set 🛡️":"Всё готово 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"Фильтрация уже работает для всего дома — панель показывает, как идут дела.","Queries today":"Запросы сегодня","Blocked":"Заблокировано","Blocked share":"Доля блокировок","ads and trackers":"реклама и трекеры","lookups today":"обращений сегодня","Each bar is 10 minutes · busiest:":"Каждый столбик — 10 минут · максимум:","since midnight":"с полуночи","waiting for traffic":"ждём трафик","Queries":"Запросы","Keep the box updated automatically":"Обновлять коробочку автоматически","Security fixes and filtering improvements only — no personal data leaves the box.":"Только исправления безопасности и улучшения фильтрации — никакие личные данные не покидают коробочку.","Share anonymous diagnostic reports":"Делиться анонимными отчётами о диагностике","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"Журналы ошибок и проверки состояния, которые помогают нам исправлять проблемы. Без истории просмотров, имён устройств и личных данных — только анонимные технические сведения, отправляемые нам конфиденциально.","Ethernet":"Ethernet","Language":"Язык","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"Коробочка не распознала адрес, с которого открыта эта страница. Откройте http://filterbox.lan и попробуйте снова.","Pause":"Пауза","This dashboard is private to your home. Enter the password you chose during setup.":"Эта панель приватна для вашего дома. Введите пароль, который вы задали при настройке.","FilterBox — Sign in":"FilterBox — Вход"," queries · ":" запросов · ","Wait a minute, then":"Подождите минуту, затем "},"ar":{"FilterBox — Setup":"FilterBox — الإعداد","Your filter box is online 🎉":"FilterBox متصل بالإنترنت الآن 🎉","Checking your setup…":"جارٍ فحص الإعداد…","Protection…":"الحماية…","Internet…":"الإنترنت…","Get started":"ابدأ","Choose your admin password":"اختر كلمة مرور المسؤول","This protects your filter's settings page. Write it down somewhere safe.":"هذا يحمي صفحة إعدادات الفلتر. اكتبها في مكان آمن.","Password (at least 8 characters)":"كلمة المرور (8 أحرف على الأقل)","Repeat password":"أعد كلمة المرور","Save password":"حفظ كلمة المرور","Internet connection":"اتصال الإنترنت","Choose how this box reaches the internet.":"اختر كيف يتصل هذا الصندوق بالإنترنت.","Ethernet":"إيثرنت","Scan for Wi-Fi networks":"بحث عن شبكات Wi-Fi","Wi-Fi password":"كلمة مرور Wi-Fi","Connect":"اتصال","Continue":"متابعة","All set! 🛡️":"كل شيء جاهز! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"شبكتك محمية الآن. يجري فلترة الإعلانات وأدوات التتبع لكل جهاز يستخدم هذا الصندوق.","Opening your dashboard…":"جارٍ فتح لوحة التحكم…","Open dashboard":"فتح لوحة التحكم","Setup already complete":"الإعداد مكتمل بالفعل","This box has already been set up. Head to the dashboard to see how it's doing.":"تم إعداد هذا الصندوق بالفعل. انتقل إلى لوحة التحكم لمعرفة حالته.","· your data stays on this device":"· بياناتك تبقى على هذا الجهاز","Bad response":"استجابة غير صحيحة","Protection: active":"الحماية: مفعّلة","Protection: warming up":"الحماية: قيد التشغيل","Internet: connected":"الإنترنت: متصل","Internet: not yet":"الإنترنت: ليس بعد","This box: ":"هذا الصندوق: ","Good news — filtering is already working.":"خبر جيد — الفلترة تعمل بالفعل.","Almost there — let’s finish the quick setup.":"أوشكنا على الانتهاء — لنكمل الإعداد السريع.","Ethernet: cable connected":"Ethernet: الكابل متصل","Ethernet: no cable detected":"Ethernet: لا يوجد كابل","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"Wi-Fi متاح على هذا الصندوق — يمكنك استخدامه أو البقاء على Ethernet.","This box filters through its network cable — nothing to configure here.":"هذا الصندوق يفلتر عبر كابل الشبكة — لا شيء لإعداده هنا.","Password needs at least 8 characters.":"كلمة المرور يجب أن تكون 8 أحرف على الأقل.","The two passwords don’t match.":"كلمتا المرور غير متطابقتين.","Something went wrong.":"حدث خطأ ما.","Saving…":"جارٍ الحفظ…","Scanning…":"جارٍ البحث…","Scan again":"بحث مرة أخرى","Password for “":"كلمة مرور “","Connecting…":"جارٍ الاتصال…","Connected.":"تم الاتصال.","Could not connect.":"تعذّر الاتصال.","Not ready yet.":"غير جاهز بعد.","No networks found. Try again, or keep using Ethernet.":"لم يتم العثور على شبكات. حاول مرة أخرى، أو ابقَ على Ethernet.","Checking on your filter…":"جارٍ فحص الفلتر…","Turn back on":"إعادة التشغيل","blocked today":"محجوب اليوم","Last 7 days":"آخر 7 أيام","Top blocked today":"الأكثر حجبًا اليوم","Warming up…":"قيد التشغيل…","Nothing blocked yet — enjoy the quiet.":"لم يُحجب شيء بعد — استمتع بالهدوء.","Pause filtering?":"إيقاف الفلترة مؤقتًا؟","Filtering will pause for a short break.":"ستتوقف الفلترة مؤقتًا لفترة قصيرة.","Pause 30 minutes":"إيقاف 30 دقيقة","Pause 1 hour":"إيقاف ساعة واحدة","Pause until I turn it back on":"إيقاف حتى أعيد التشغيل","Cancel":"إلغاء","Enter your dashboard password":"أدخل كلمة مرور لوحة التحكم","Password":"كلمة المرور","Settings":"الإعدادات","Tap to pause filtering":"اضغط لإيقاف الفلترة مؤقتًا","Back in ":"يعود بعد ","Back in ~":"يعود بعد ~"," h ":" س "," min":" د","Could not reach the panel — reload in a moment.":"تعذّر الوصول إلى اللوحة — أعد التحميل بعد لحظة.","Too many requests — wait a minute.":"طلبات كثيرة جدًا — انتظر دقيقة.","Something went wrong — try again.":"حدث خطأ ما — حاول مرة أخرى.","Paused until you turn it back on.":"متوقف مؤقتًا حتى تعيد التشغيل.","Paused for 30 minutes.":"متوقف مؤقتًا لمدة 30 دقيقة.","Paused for 1 hour.":"متوقف مؤقتًا لمدة ساعة واحدة.","Protection is back on.":"الحماية عادت للعمل.","Paused until you turn it back on":"متوقف حتى تعيد التشغيل","Protection: paused":"الحماية: متوقفة","Protection: checking…":"الحماية: جارٍ الفحص…","Protection: needs attention":"الحماية: تحتاج إلى انتباه","Filter engine starting up — stats will appear shortly.":"محرك الفلترة يبدأ — ستظهر الإحصاءات قريبًا.","Ad blocking seems off — try restarting the box, or contact support.":"يبدو أن حجب الإعلانات متوقف — أعد تشغيل الصندوق أو تواصل مع الدعم.","Working quietly in the background.":"يعمل بهدوء في الخلفية.","Internet: not reaching the internet":"الإنترنت: لا يوجد وصول","Internet: checking…":"الإنترنت: جارٍ الفحص…","waiting for the filter engine…":"في انتظار محرك الفلترة…","% of all queries · ":"% من جميع الاستعلامات · "," domains in your protection lists":" نطاقًا في قوائم الحماية","Every bar is a slice of the week — taller means more ads blocked.":"كل شريط جزء من الأسبوع — الأطول يعني حجب إعلانات أكثر.","The chart fills in as the week goes.":"يمتلئ المخطط تدريجيًا مع تقدم الأسبوع.","That password doesn't match — try again.":"كلمة المرور غير مطابقة — حاول مرة أخرى."," blocked":" محجوب","FilterBox — Settings":"FilterBox — الإعدادات","← Dashboard":"← لوحة التحكم","Change password":"تغيير كلمة المرور","This is the password for the dashboard and the advanced view.":"هذه كلمة مرور لوحة التحكم والعرض المتقدم.","Current password":"كلمة المرور الحالية","New password (at least 8 characters)":"كلمة مرور جديدة (8 أحرف على الأقل)","Repeat new password":"أعد كلمة المرور الجديدة","Password updated.":"تم تحديث كلمة المرور.","Save new password":"حفظ كلمة المرور الجديدة","Restart the box":"إعادة تشغيل الصندوق","Takes about a minute. Filtering pauses briefly while it restarts.":"يستغرق حوالي دقيقة. تتوقف الفلترة قليلًا أثناء إعادة التشغيل.","Restart now":"إعادة التشغيل الآن","Factory reset":"إعادة ضبط المصنع","Reset this box…":"إعادة ضبط هذا الصندوق…","Type RESET to confirm":"اكتب RESET للتأكيد","Dashboard password":"كلمة مرور لوحة التحكم","Erase everything and reset":"محو كل شيء وإعادة الضبط","About":"حول","Panel version":"إصدار اللوحة","Filter engine":"محرك الفلترة","Uptime":"مدة التشغيل","Address":"العنوان","Working…":"جارٍ العمل…","Please wait.":"يرجى الانتظار.","Password must be at least 8 characters.":"كلمة المرور يجب أن تكون 8 أحرف على الأقل.","The two new passwords don’t match.":"كلمتا المرور الجديدتان غير متطابقتين.","Restart now? Tap again to confirm":"إعادة التشغيل الآن؟ اضغط مرة أخرى للتأكيد","Restarting…":"جارٍ إعادة التشغيل…","Back online.":"عاد الاتصال.","This takes about a minute. Filtering pauses briefly while it restarts.":"يستغرق هذا حوالي دقيقة. تتوقف الفلترة قليلًا أثناء إعادة التشغيل.","Restarting the box":"جارٍ إعادة تشغيل الصندوق","Still working…":"لا يزال يعمل…","Reloading…":"جارٍ إعادة التحميل…","Type RESET exactly to confirm.":"اكتب RESET تمامًا للتأكيد.","Resetting the box":"جارٍ إعادة ضبط الصندوق","Erasing settings and returning to setup mode — the box will restart.":"محو الإعدادات والعودة إلى وضع الإعداد — سيعيد الصندوق التشغيل.","Back to setup — reloading…":"العودة إلى الإعداد — جارٍ إعادة التحميل…"," d ":" ي ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"لم يعد الصندوق بعد. تأكد من أنه متصل بالكهرباء، ثم أعد تحميل هذه الصفحة.","Too many requests":"طلبات كثيرة جدًا","Wait a minute, then ":"انتظر دقيقة، ثم ","reload the dashboard":"أعد تحميل لوحة التحكم","Nothing here":"لا شيء هنا","That page doesn't exist.":"هذه الصفحة غير موجودة.","Back to FilterBox":"العودة إلى FilterBox","not found":"غير موجود","Too many attempts — wait a minute.":"محاولات كثيرة جدًا — انتظر دقيقة.","Session expired — enter the password again.":"انتهت الجلسة — أدخل كلمة المرور مرة أخرى.","Pick 30 minutes, 1 hour, or until you turn it back on.":"اختر 30 دقيقة، أو ساعة واحدة، أو حتى تعيد التشغيل.","Setup is already complete.":"الإعداد مكتمل بالفعل.","That's not the current password — try again.":"ليست كلمة المرور الحالية — حاول مرة أخرى.","Password is too long (max 128 characters).":"كلمة المرور طويلة جدًا (128 حرفًا كحد أقصى).","Couldn't start the restart — check that the box is powered, then try again.":"تعذّر بدء إعادة التشغيل — تأكد من أن الصندوق متصل بالكهرباء، ثم حاول مرة أخرى.","Could not set the password (service not ready?). Try again in a moment.":"تعذّر حفظ كلمة المرور (الخدمة غير جاهزة؟). حاول مرة أخرى بعد لحظة.","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"لم يُعثر على محول Wi-Fi في هذا الصندوق — يستخدم Ethernet. كل شيء جاهز.","Pick a network and enter its password (at least 8 chars).":"اختر شبكة وأدخل كلمة مرورها (8 أحرف على الأقل).","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"لا يوجد محول Wi-Fi في هذا الصندوق — الطريق هو Ethernet. لا شيء لفعله هنا.","Wi-Fi tools are not available on this box.":"أدوات Wi-Fi غير متاحة على هذا الصندوق.","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"تم حفظ إعدادات Wi-Fi، لكن لا يوجد عنوان بعد — انتظر دقيقة وأعد تحميل هذه الصفحة.","Set an admin password first.":"عيّن كلمة مرور المسؤول أولًا.","Connected to ":"متصل بـ ","Could not update Wi-Fi config: ":"تعذّر تحديث إعدادات Wi-Fi: ","queries today":"استعلامًا اليوم"," blocked (":" محجوب (","answered from cache: ":"مُجاب عليها من الذاكرة المؤقتة: "," · forwarded: ":" · مُمرَّرة: ","Today":"اليوم","Each bar is 10 minutes — the purple part was blocked.":"كل شريط 10 دقائق — الجزء البنفسجي محجوب.","The chart fills in as the day goes.":"يمتلئ المخطط تدريجيًا مع تقدم اليوم.","Most visited today":"الأكثر زيارة اليوم","Busiest devices":"الأجهزة الأكثر نشاطًا","Where answers came from":"مصدر الإجابات","Traffic mix":"مزيج حركة المرور","Advanced view":"العرض المتقدم","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"للمستخدمين المتقدمين — لوحة التحكم التقنية الكاملة: سجل الاستعلامات وإدارة قوائم الحجب والإعدادات التفصيلية.","Open advanced view":"فتح العرض المتقدم","Uses the same password as this page. Changes there affect filtering for the whole home.":"تستخدم نفس كلمة مرور هذه الصفحة. التغييرات هناك تؤثر على الفلترة في المنزل بأكمله.","Whole home":"المنزل بأكمله","Covered — ":"مغطّى — "," devices seen on your network":" جهازًا ظهر على شبكتك","Protection is paused — filtering is off.":"الحماية متوقفة مؤقتًا — الفلترة متوقفة.","Coverage paused — finishing network release…":"التغطية متوقفة مؤقتًا — جارٍ إنهاء تحرير الشبكة…","Protection starts as soon as setup is finished.":"تبدأ الحماية فور انتهاء الإعداد.","Coverage is on — devices will appear as they browse.":"التغطية مفعّلة — ستظهر الأجهزة أثناء تصفحها.","Coverage starting…":"جارٍ بدء التغطية…","Coverage paused — the internet is open.":"التغطية متوقفة مؤقتًا — الإنترنت مفتوح.","Coverage is off.":"التغطية متوقفة.","Coverage has not started — check the box.":"لم تبدأ التغطية — تحقق من الصندوق.","Coverage status unavailable — check the box.":"حالة التغطية غير متاحة — تحقق من الصندوق.","Protection: starts after setup":"الحماية: تبدأ بعد الإعداد","Finish setup to switch protection on for the whole home.":"أكمل الإعداد لتفعيل الحماية في المنزل بأكمله.","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"اكتمل الإعداد. الحماية تُفعّل الآن في منزلك بأكمله — تعرض لوحة التحكم تقدمها.","Coverage status is out of date — check the box.":"حالة التغطية قديمة — تحقق من الصندوق.","Coverage unavailable on this network — contact support.":"التغطية غير متاحة على هذه الشبكة — تواصل مع الدعم.","Network release still finishing — check the box.":"تحرير الشبكة لم ينتهِ بعد — تحقق من الصندوق.","Coverage could not start — restart the box or contact support.":"تعذّر بدء التغطية — أعد تشغيل الصندوق أو تواصل مع الدعم.","Internal error — try again.":"خطأ داخلي — حاول مرة أخرى.","That network name is not supported — choose another network.":"اسم الشبكة هذا غير مدعوم — اختر شبكة أخرى.","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"يمحو كلمة مرور لوحة التحكم والإعدادات والإحصاءات. تستمر الفلترة، وتبقى إعدادات Wi-Fi. لا يمكن التراجع عن هذا — إذا نسيت كلمة المرور، اضغط مطولًا على زر RESET في الصندوق لمدة 5 ثوانٍ.","Protection lists need attention — the box is repairing them.":"قوائم الحماية تحتاج إلى انتباه — الصندوق يصلحها.","Filtering is on — coverage status unavailable.":"الفلترة مفعّلة — حالة التغطية غير متاحة.","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"لا تزال قوائم الحماية قيد الإعداد — أبقِ الصندوق موصولًا بالكهرباء والشبكة، ثم حاول مرة أخرى بعد بضع دقائق.","Filtering is already running for your whole home.":"الفلترة تعمل بالفعل لمنزلك بأكمله.","Protection is starting — no action needed.":"الحماية تبدأ — لا حاجة لأي إجراء.","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"لوحة التحكم والإحصاءات اختيارية. عيّن كلمة مرور لاستخدامها — وإلا فأغلق هذه الصفحة واستمتع بالهدوء.","Set up the dashboard":"إعداد لوحة التحكم","Choose your dashboard password":"اختر كلمة مرور لوحة التحكم","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"هذا يحمي لوحة التحكم والعرض المتقدم. اكتبها في مكان آمن. إذا نسيتها، اضغط مطولًا على زر RESET في الصندوق لمدة 5 ثوانٍ.","You're all set 🛡️":"كل شيء جاهز 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"الفلترة تعمل بالفعل لمنزلك بأكمله — تعرض لوحة التحكم سيرها.","Queries today":"الاستعلامات اليوم","Blocked":"محجوب","Blocked share":"نسبة الحجب","ads and trackers":"إعلانات وأدوات تتبع","lookups today":"بحثًا اليوم","Each bar is 10 minutes · busiest:":"كل شريط 10 دقائق · الأكثر نشاطًا:","since midnight":"منذ منتصف الليل","waiting for traffic":"في انتظار حركة المرور","Queries":"الاستعلامات","Keep the box updated automatically":"أبقِ الصندوق محدَّثًا تلقائيًا","Security fixes and filtering improvements only — no personal data leaves the box.":"إصلاحات أمنية وتحسينات في التصفية فقط — لا تخرج أي بيانات شخصية من الصندوق.","Share anonymous diagnostic reports":"مشاركة تقارير تشخيص مجهولة الهوية","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"سجلات الأخطاء وفحوصات الحالة التي تساعدنا في إصلاح المشكلات. لا سجل تصفح، ولا أسماء أجهزة، ولا بيانات شخصية — فقط تفاصيل تقنية مجهولة الهوية تُرسَل إلينا بشكل خاص.","Language":"اللغة","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"لم يتعرف الصندوق على العنوان الذي فُتحت منه هذه الصفحة. افتح http://filterbox.lan وحاول مرة أخرى.","Pause":"إيقاف مؤقت","This dashboard is private to your home. Enter the password you chose during setup.":"لوحة التحكم هذه خاصة بمنزلك. أدخل كلمة المرور التي اخترتها أثناء الإعداد.","FilterBox — Sign in":"FilterBox — تسجيل الدخول"," queries · ":" استعلامات · ","Wait a minute, then":"انتظر دقيقة، ثم "},"de":{"FilterBox — Setup":"FilterBox — Einrichtung","Your filter box is online 🎉":"Deine FilterBox ist online 🎉","Checking your setup…":"Einrichtung wird geprüft…","Protection…":"Schutz…","Internet…":"Internet…","Get started":"Los geht's","Choose your admin password":"Admin-Passwort wählen","This protects your filter's settings page. Write it down somewhere safe.":"Damit schützt du die Einstellungsseite deines Filters. Schreib es an einem sicheren Ort auf.","Password (at least 8 characters)":"Passwort (mindestens 8 Zeichen)","Repeat password":"Passwort wiederholen","Save password":"Passwort speichern","Internet connection":"Internetverbindung","Choose how this box reaches the internet.":"Wähle, wie diese Box ins Internet kommt.","Ethernet":"Ethernet","Scan for Wi-Fi networks":"Nach Wi-Fi-Netzen suchen","Wi-Fi password":"Wi-Fi-Passwort","Connect":"Verbinden","Continue":"Weiter","All set! 🛡️":"Alles bereit! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"Dein Netzwerk ist jetzt geschützt. Werbung und Tracker werden für jedes Gerät gefiltert, das diese Box nutzt.","Opening your dashboard…":"Dashboard wird geöffnet…","Open dashboard":"Dashboard öffnen","Setup already complete":"Einrichtung bereits abgeschlossen","This box has already been set up. Head to the dashboard to see how it's doing.":"Diese Box wurde bereits eingerichtet. Im Dashboard siehst du, wie sie läuft.","· your data stays on this device":"· deine Daten bleiben auf diesem Gerät","Bad response":"Ungültige Antwort","Protection: active":"Schutz: aktiv","Protection: warming up":"Schutz: startet","Internet: connected":"Internet: verbunden","Internet: not yet":"Internet: noch nicht","This box: ":"Diese Box: ","Good news — filtering is already working.":"Gute Nachricht — die Filterung läuft bereits.","Almost there — let’s finish the quick setup.":"Fast geschafft — schließen wir die kurze Einrichtung ab.","Ethernet: cable connected":"Ethernet: Kabel verbunden","Ethernet: no cable detected":"Ethernet: kein Kabel erkannt","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"Wi-Fi ist auf dieser Box verfügbar — du kannst es nutzen oder bei Ethernet bleiben.","This box filters through its network cable — nothing to configure here.":"Diese Box filtert über ihr Netzwerkkabel — hier gibt es nichts einzustellen.","Password needs at least 8 characters.":"Das Passwort braucht mindestens 8 Zeichen.","The two passwords don’t match.":"Die beiden Passwörter stimmen nicht überein.","Something went wrong.":"Etwas ist schiefgelaufen.","Saving…":"Speichern…","Scanning…":"Suche läuft…","Scan again":"Erneut suchen","Password for “":"Passwort für „","Connecting…":"Verbinden…","Connected.":"Verbunden.","Could not connect.":"Verbindung nicht möglich.","Not ready yet.":"Noch nicht bereit.","No networks found. Try again, or keep using Ethernet.":"Keine Netzwerke gefunden. Versuch es erneut oder bleib bei Ethernet.","Checking on your filter…":"Dein Filter wird geprüft…","Turn back on":"Wieder einschalten","blocked today":"heute blockiert","Last 7 days":"Letzte 7 Tage","Top blocked today":"Heute am häufigsten blockiert","Warming up…":"Startet…","Nothing blocked yet — enjoy the quiet.":"Noch nichts blockiert — genieß die Ruhe.","Pause filtering?":"Filterung pausieren?","Filtering will pause for a short break.":"Die Filterung pausiert für eine kurze Auszeit.","Pause 30 minutes":"30 Minuten pausieren","Pause 1 hour":"1 Stunde pausieren","Pause until I turn it back on":"Pausieren bis ich es wieder einschalte","Cancel":"Abbrechen","Enter your dashboard password":"Dashboard-Passwort eingeben","Password":"Passwort","Settings":"Einstellungen","Tap to pause filtering":"Tippen, um die Filterung zu pausieren","Back in ":"Wieder aktiv in ","Back in ~":"Wieder aktiv in ~"," h ":" Std. "," min":" Min.","Could not reach the panel — reload in a moment.":"Panel nicht erreichbar — lade gleich neu.","Too many requests — wait a minute.":"Zu viele Anfragen — warte eine Minute.","Something went wrong — try again.":"Etwas ist schiefgelaufen — versuch es erneut.","Paused until you turn it back on.":"Pausiert, bis du es wieder einschaltest.","Paused for 30 minutes.":"Für 30 Minuten pausiert.","Paused for 1 hour.":"Für 1 Stunde pausiert.","Protection is back on.":"Der Schutz ist wieder an.","Paused until you turn it back on":"Pausiert, bis du es wieder einschaltest","Protection: paused":"Schutz: pausiert","Protection: checking…":"Schutz: wird geprüft…","Protection: needs attention":"Schutz: braucht Aufmerksamkeit","Filter engine starting up — stats will appear shortly.":"Filter-Engine startet — Statistiken erscheinen gleich.","Ad blocking seems off — try restarting the box, or contact support.":"Werbeblockierung scheint ausgeschaltet zu sein — starte die Box neu oder kontaktiere den Support.","Working quietly in the background.":"Arbeitet leise im Hintergrund.","Internet: not reaching the internet":"Internet: kein Internetzugang","Internet: checking…":"Internet: wird geprüft…","waiting for the filter engine…":"warte auf die Filter-Engine…","% of all queries · ":"% aller Anfragen · "," domains in your protection lists":" Domains in deinen Schutzlisten","Every bar is a slice of the week — taller means more ads blocked.":"Jeder Balken ist ein Teil der Woche — höher bedeutet mehr blockierte Werbung.","The chart fills in as the week goes.":"Das Diagramm füllt sich im Lauf der Woche.","That password doesn't match — try again.":"Das Passwort stimmt nicht — versuch es erneut."," blocked":" blockiert","FilterBox — Settings":"FilterBox — Einstellungen","← Dashboard":"← Dashboard","Change password":"Passwort ändern","This is the password for the dashboard and the advanced view.":"Das ist das Passwort für das Dashboard und die erweiterte Ansicht.","Current password":"Aktuelles Passwort","New password (at least 8 characters)":"Neues Passwort (mindestens 8 Zeichen)","Repeat new password":"Neues Passwort wiederholen","Password updated.":"Passwort aktualisiert.","Save new password":"Neues Passwort speichern","Restart the box":"Box neu starten","Takes about a minute. Filtering pauses briefly while it restarts.":"Dauert etwa eine Minute. Die Filterung pausiert kurz während des Neustarts.","Restart now":"Jetzt neu starten","Factory reset":"Werkseinstellungen","Reset this box…":"Diese Box zurücksetzen…","Type RESET to confirm":"RESET eingeben zum Bestätigen","Dashboard password":"Dashboard-Passwort","Erase everything and reset":"Alles löschen und zurücksetzen","About":"Über","Panel version":"Panel-Version","Filter engine":"Filter-Engine","Uptime":"Laufzeit","Address":"Adresse","Working…":"Arbeitet…","Please wait.":"Bitte warten.","Password must be at least 8 characters.":"Das Passwort muss mindestens 8 Zeichen haben.","The two new passwords don’t match.":"Die beiden neuen Passwörter stimmen nicht überein.","Restart now? Tap again to confirm":"Jetzt neu starten? Zum Bestätigen erneut tippen","Restarting…":"Neustart läuft…","Back online.":"Wieder online.","This takes about a minute. Filtering pauses briefly while it restarts.":"Das dauert etwa eine Minute. Die Filterung pausiert kurz während des Neustarts.","Restarting the box":"Box wird neu gestartet","Still working…":"Läuft noch…","Reloading…":"Neu laden…","Type RESET exactly to confirm.":"Gib RESET genau so ein, um zu bestätigen.","Resetting the box":"Box wird zurückgesetzt","Erasing settings and returning to setup mode — the box will restart.":"Einstellungen werden gelöscht, zurück zum Einrichtungsmodus — die Box startet neu.","Back to setup — reloading…":"Zurück zur Einrichtung — neu laden…"," d ":" T. ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"Die Box ist noch nicht zurück. Prüfe, ob sie Strom hat, und lade dann diese Seite neu.","Too many requests":"Zu viele Anfragen","Wait a minute, then ":"Warte eine Minute, dann ","reload the dashboard":"Dashboard neu laden","Nothing here":"Nichts hier","That page doesn't exist.":"Diese Seite gibt es nicht.","Back to FilterBox":"Zurück zu FilterBox","not found":"nicht gefunden","Too many attempts — wait a minute.":"Zu viele Versuche — warte eine Minute.","Session expired — enter the password again.":"Sitzung abgelaufen — gib das Passwort erneut ein.","Pick 30 minutes, 1 hour, or until you turn it back on.":"Wähle 30 Minuten, 1 Stunde oder bis du es wieder einschaltest.","Setup is already complete.":"Die Einrichtung ist bereits abgeschlossen.","That's not the current password — try again.":"Das ist nicht das aktuelle Passwort — versuch es erneut.","Password is too long (max 128 characters).":"Das Passwort ist zu lang (max. 128 Zeichen).","Couldn't start the restart — check that the box is powered, then try again.":"Neustart konnte nicht gestartet werden — prüfe, ob die Box Strom hat, und versuch es erneut.","Could not set the password (service not ready?). Try again in a moment.":"Passwort konnte nicht gesetzt werden (Dienst nicht bereit?). Versuch es gleich noch einmal.","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"Kein Wi-Fi-Adapter auf dieser Box erkannt — sie nutzt Ethernet. Alles bereit.","Pick a network and enter its password (at least 8 chars).":"Wähle ein Netzwerk und gib sein Passwort ein (mindestens 8 Zeichen).","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"Kein Wi-Fi-Adapter auf dieser Box — Ethernet ist der Weg. Hier ist nichts zu tun.","Wi-Fi tools are not available on this box.":"Wi-Fi-Werkzeuge sind auf dieser Box nicht verfügbar.","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"Wi-Fi-Einstellungen gespeichert, aber noch keine Adresse — warte eine Minute und lade diese Seite neu.","Set an admin password first.":"Lege zuerst ein Admin-Passwort fest.","Connected to ":"Verbunden mit ","Could not update Wi-Fi config: ":"Wi-Fi-Konfiguration konnte nicht aktualisiert werden: ","queries today":"Anfragen heute"," blocked (":" blockiert (","answered from cache: ":"aus dem Cache beantwortet: "," · forwarded: ":" · weitergeleitet: ","Today":"Heute","Each bar is 10 minutes — the purple part was blocked.":"Jeder Balken sind 10 Minuten — der violette Teil wurde blockiert.","The chart fills in as the day goes.":"Das Diagramm füllt sich im Lauf des Tages.","Most visited today":"Heute am meisten besucht","Busiest devices":"Aktivste Geräte","Where answers came from":"Woher die Antworten kamen","Traffic mix":"Datenverkehr","Advanced view":"Erweiterte Ansicht","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"Für fortgeschrittene Nutzer — das volle technische Dashboard: Anfrageprotokoll, Blocklisten-Verwaltung und detaillierte Einstellungen.","Open advanced view":"Erweiterte Ansicht öffnen","Uses the same password as this page. Changes there affect filtering for the whole home.":"Nutzt dasselbe Passwort wie diese Seite. Änderungen dort wirken auf die Filterung im ganzen Zuhause.","Whole home":"Ganzes Zuhause","Covered — ":"Abgedeckt — "," devices seen on your network":" Geräte in deinem Netzwerk gesehen","Protection is paused — filtering is off.":"Der Schutz ist pausiert — die Filterung ist aus.","Coverage paused — finishing network release…":"Abdeckung pausiert — Netzwerkfreigabe wird abgeschlossen…","Protection starts as soon as setup is finished.":"Der Schutz startet, sobald die Einrichtung fertig ist.","Coverage is on — devices will appear as they browse.":"Abdeckung ist an — Geräte erscheinen, sobald sie surfen.","Coverage starting…":"Abdeckung startet…","Coverage paused — the internet is open.":"Abdeckung pausiert — das Internet ist offen.","Coverage is off.":"Abdeckung ist aus.","Coverage has not started — check the box.":"Abdeckung hat nicht gestartet — prüfe die Box.","Coverage status unavailable — check the box.":"Abdeckungsstatus nicht verfügbar — prüfe die Box.","Protection: starts after setup":"Schutz: startet nach der Einrichtung","Finish setup to switch protection on for the whole home.":"Schließe die Einrichtung ab, um den Schutz fürs ganze Zuhause einzuschalten.","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"Einrichtung abgeschlossen. Der Schutz wird für dein ganzes Zuhause eingeschaltet — das Dashboard zeigt den Fortschritt.","Coverage status is out of date — check the box.":"Abdeckungsstatus ist veraltet — prüfe die Box.","Coverage unavailable on this network — contact support.":"Abdeckung in diesem Netzwerk nicht verfügbar — kontaktiere den Support.","Network release still finishing — check the box.":"Netzwerkfreigabe läuft noch — prüfe die Box.","Coverage could not start — restart the box or contact support.":"Abdeckung konnte nicht starten — starte die Box neu oder kontaktiere den Support.","Internal error — try again.":"Interner Fehler — versuch es erneut.","That network name is not supported — choose another network.":"Dieser Netzwerkname wird nicht unterstützt — wähle ein anderes Netzwerk.","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"Löscht dein Dashboard-Passwort, Einstellungen und Statistiken. Die Filterung läuft weiter, und die Wi-Fi-Einstellungen bleiben. Das kann nicht rückgängig gemacht werden — falls du das Passwort je vergisst, halte die RESET-Taste an der Box 5 Sekunden gedrückt.","Protection lists need attention — the box is repairing them.":"Schutzlisten brauchen Aufmerksamkeit — die Box repariert sie.","Filtering is on — coverage status unavailable.":"Filterung ist an — Abdeckungsstatus nicht verfügbar.","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"Deine Schutzlisten werden noch vorbereitet — lass die Box am Strom und verbunden, und versuch es in ein paar Minuten erneut.","Filtering is already running for your whole home.":"Die Filterung läuft bereits für dein ganzes Zuhause.","Protection is starting — no action needed.":"Der Schutz startet — nichts zu tun.","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"Dashboard und Statistiken sind optional. Lege ein Passwort fest, um sie zu nutzen — sonst schließe einfach diese Seite und genieß die Ruhe.","Set up the dashboard":"Dashboard einrichten","Choose your dashboard password":"Dashboard-Passwort wählen","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"Damit schützt du das Dashboard und die erweiterte Ansicht. Schreib es an einem sicheren Ort auf. Wenn du es vergisst, halte die RESET-Taste an der Box 5 Sekunden gedrückt.","You're all set 🛡️":"Alles bereit 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"Die Filterung läuft bereits für dein ganzes Zuhause — im Dashboard siehst du, wie es läuft.","Queries today":"Anfragen heute","Blocked":"Blockiert","Blocked share":"Blockiert-Anteil","ads and trackers":"Werbung und Tracker","lookups today":"Abfragen heute","Each bar is 10 minutes · busiest:":"Jeder Balken sind 10 Minuten · am meisten:","since midnight":"seit Mitternacht","waiting for traffic":"warte auf Datenverkehr","Queries":"Anfragen","Keep the box updated automatically":"Die Box automatisch aktualisieren","Security fixes and filtering improvements only — no personal data leaves the box.":"Nur Sicherheitskorrekturen und Filterverbesserungen — keine persönlichen Daten verlassen die Box.","Share anonymous diagnostic reports":"Anonyme Diagnoseberichte teilen","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"Fehlerprotokolle und Zustandsprüfungen, die uns helfen, Probleme zu beheben. Kein Browserverlauf, keine Gerätenamen, keine persönlichen Daten — nur anonymisierte technische Details, die uns vertraulich gesendet werden.","Language":"Sprache","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"Diese Box hat die Adresse, über die diese Seite geöffnet wurde, nicht erkannt. Öffnen Sie http://filterbox.lan und versuchen Sie es erneut.","Pause":"Pausieren","This dashboard is private to your home. Enter the password you chose during setup.":"Dieses Dashboard ist privat für Ihr Zuhause. Geben Sie das Passwort ein, das Sie bei der Einrichtung gewählt haben.","FilterBox — Sign in":"FilterBox — Anmelden"," queries · ":" Abfragen · ","Wait a minute, then":"Warten Sie eine Minute, dann "},"es":{"FilterBox — Setup":"FilterBox — Configuración","Your filter box is online 🎉":"Tu FilterBox está en línea 🎉","Checking your setup…":"Comprobando tu configuración…","Protection…":"Protección…","Internet…":"Internet…","Get started":"Empezar","Choose your admin password":"Elige tu contraseña de administrador","This protects your filter's settings page. Write it down somewhere safe.":"Esto protege la página de ajustes de tu filtro. Anótala en un lugar seguro.","Password (at least 8 characters)":"Contraseña (mínimo 8 caracteres)","Repeat password":"Repite la contraseña","Save password":"Guardar contraseña","Internet connection":"Conexión a Internet","Choose how this box reaches the internet.":"Elige cómo se conecta este equipo a Internet.","Ethernet":"Ethernet","Scan for Wi-Fi networks":"Buscar redes Wi-Fi","Wi-Fi password":"Contraseña Wi-Fi","Connect":"Conectar","Continue":"Continuar","All set! 🛡️":"¡Todo listo! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"Tu red ya está protegida. Se filtran anuncios y rastreadores para todos los dispositivos que usan este equipo.","Opening your dashboard…":"Abriendo tu panel…","Open dashboard":"Abrir panel","Setup already complete":"Configuración ya completada","This box has already been set up. Head to the dashboard to see how it's doing.":"Este equipo ya está configurado. Ve al panel para ver cómo va.","· your data stays on this device":"· tus datos se quedan en este dispositivo","Bad response":"Respuesta incorrecta","Protection: active":"Protección: activa","Protection: warming up":"Protección: iniciando","Internet: connected":"Internet: conectado","Internet: not yet":"Internet: aún no","This box: ":"Este equipo: ","Good news — filtering is already working.":"Buenas noticias: el filtrado ya funciona.","Almost there — let’s finish the quick setup.":"Ya casi está: terminemos la configuración rápida.","Ethernet: cable connected":"Ethernet: cable conectado","Ethernet: no cable detected":"Ethernet: no se detecta cable","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"Este equipo tiene Wi-Fi: puedes usarlo o seguir con Ethernet.","This box filters through its network cable — nothing to configure here.":"Este equipo filtra por su cable de red: aquí no hay nada que configurar.","Password needs at least 8 characters.":"La contraseña necesita al menos 8 caracteres.","The two passwords don’t match.":"Las dos contraseñas no coinciden.","Something went wrong.":"Algo ha ido mal.","Saving…":"Guardando…","Scanning…":"Buscando…","Scan again":"Buscar de nuevo","Password for “":"Contraseña de “","Connecting…":"Conectando…","Connected.":"Conectado.","Could not connect.":"No se pudo conectar.","Not ready yet.":"Aún no está listo.","No networks found. Try again, or keep using Ethernet.":"No se han encontrado redes. Inténtalo de nuevo o sigue usando Ethernet.","Checking on your filter…":"Comprobando tu filtro…","Turn back on":"Reactivar","blocked today":"bloqueados hoy","Last 7 days":"Últimos 7 días","Top blocked today":"Más bloqueados hoy","Warming up…":"Iniciando…","Nothing blocked yet — enjoy the quiet.":"Aún no se ha bloqueado nada: disfruta de la calma.","Pause filtering?":"¿Pausar el filtrado?","Filtering will pause for a short break.":"El filtrado se pausará un rato.","Pause 30 minutes":"Pausar 30 minutos","Pause 1 hour":"Pausar 1 hora","Pause until I turn it back on":"Pausar hasta que lo reactive","Cancel":"Cancelar","Enter your dashboard password":"Introduce tu contraseña del panel","Password":"Contraseña","Settings":"Ajustes","Tap to pause filtering":"Toca para pausar el filtrado","Back in ":"Vuelve en ","Back in ~":"Vuelve en ~"," h ":" h "," min":" min","Could not reach the panel — reload in a moment.":"No se pudo acceder al panel: recarga en un momento.","Too many requests — wait a minute.":"Demasiadas solicitudes: espera un minuto.","Something went wrong — try again.":"Algo ha ido mal: inténtalo de nuevo.","Paused until you turn it back on.":"En pausa hasta que lo reactives.","Paused for 30 minutes.":"En pausa durante 30 minutos.","Paused for 1 hour.":"En pausa durante 1 hora.","Protection is back on.":"La protección está activa de nuevo.","Paused until you turn it back on":"En pausa hasta que lo reactives","Protection: paused":"Protección: en pausa","Protection: checking…":"Protección: comprobando…","Protection: needs attention":"Protección: requiere atención","Filter engine starting up — stats will appear shortly.":"El motor de filtrado está arrancando: las estadísticas aparecerán en breve.","Ad blocking seems off — try restarting the box, or contact support.":"El bloqueo de anuncios parece desactivado: reinicia el equipo o contacta con soporte.","Working quietly in the background.":"Trabajando en silencio en segundo plano.","Internet: not reaching the internet":"Internet: sin acceso a Internet","Internet: checking…":"Internet: comprobando…","waiting for the filter engine…":"esperando al motor de filtrado…","% of all queries · ":"% de todas las consultas · "," domains in your protection lists":" dominios en tus listas de protección","Every bar is a slice of the week — taller means more ads blocked.":"Cada barra es una parte de la semana: más alta significa más anuncios bloqueados.","The chart fills in as the week goes.":"El gráfico se va completando con la semana.","That password doesn't match — try again.":"Esa contraseña no coincide: inténtalo de nuevo."," blocked":" bloqueados","FilterBox — Settings":"FilterBox — Ajustes","← Dashboard":"← Panel","Change password":"Cambiar contraseña","This is the password for the dashboard and the advanced view.":"Es la contraseña del panel y de la vista avanzada.","Current password":"Contraseña actual","New password (at least 8 characters)":"Nueva contraseña (mínimo 8 caracteres)","Repeat new password":"Repite la nueva contraseña","Password updated.":"Contraseña actualizada.","Save new password":"Guardar nueva contraseña","Restart the box":"Reiniciar el equipo","Takes about a minute. Filtering pauses briefly while it restarts.":"Tarda alrededor de un minuto. El filtrado se pausa brevemente mientras se reinicia.","Restart now":"Reiniciar ahora","Factory reset":"Restablecer de fábrica","Reset this box…":"Restablecer este equipo…","Type RESET to confirm":"Escribe RESET para confirmar","Dashboard password":"Contraseña del panel","Erase everything and reset":"Borrar todo y restablecer","About":"Acerca de","Panel version":"Versión del panel","Filter engine":"Motor de filtrado","Uptime":"Tiempo activo","Address":"Dirección","Working…":"Procesando…","Please wait.":"Espera un momento.","Password must be at least 8 characters.":"La contraseña debe tener al menos 8 caracteres.","The two new passwords don’t match.":"Las dos contraseñas nuevas no coinciden.","Restart now? Tap again to confirm":"¿Reiniciar ahora? Toca otra vez para confirmar","Restarting…":"Reiniciando…","Back online.":"De nuevo en línea.","This takes about a minute. Filtering pauses briefly while it restarts.":"Esto tarda alrededor de un minuto. El filtrado se pausa brevemente mientras se reinicia.","Restarting the box":"Reiniciando el equipo","Still working…":"Aún procesando…","Reloading…":"Recargando…","Type RESET exactly to confirm.":"Escribe RESET exactamente para confirmar.","Resetting the box":"Restableciendo el equipo","Erasing settings and returning to setup mode — the box will restart.":"Borrando los ajustes y volviendo al modo de configuración: el equipo se reiniciará.","Back to setup — reloading…":"Volviendo a la configuración: recargando…"," d ":" d ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"El equipo aún no ha vuelto. Comprueba que está encendido y recarga esta página.","Too many requests":"Demasiadas solicitudes","Wait a minute, then ":"Espera un minuto y luego ","reload the dashboard":"recarga el panel","Nothing here":"Aquí no hay nada","That page doesn't exist.":"Esa página no existe.","Back to FilterBox":"Volver a FilterBox","not found":"no encontrado","Too many attempts — wait a minute.":"Demasiados intentos: espera un minuto.","Session expired — enter the password again.":"La sesión ha caducado: introduce la contraseña otra vez.","Pick 30 minutes, 1 hour, or until you turn it back on.":"Elige 30 minutos, 1 hora o hasta que lo reactives.","Setup is already complete.":"La configuración ya está completada.","That's not the current password — try again.":"Esa no es la contraseña actual: inténtalo de nuevo.","Password is too long (max 128 characters).":"La contraseña es demasiado larga (máximo 128 caracteres).","Couldn't start the restart — check that the box is powered, then try again.":"No se pudo iniciar el reinicio: comprueba que el equipo tiene corriente e inténtalo de nuevo.","Could not set the password (service not ready?). Try again in a moment.":"No se pudo guardar la contraseña (¿servicio no listo?). Inténtalo de nuevo en un momento.","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"No se ha detectado adaptador Wi-Fi en este equipo: usa Ethernet. Todo listo.","Pick a network and enter its password (at least 8 chars).":"Elige una red e introduce su contraseña (mínimo 8 caracteres).","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"Este equipo no tiene adaptador Wi-Fi: la vía es Ethernet. Aquí no hay nada que hacer.","Wi-Fi tools are not available on this box.":"Las herramientas Wi-Fi no están disponibles en este equipo.","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"Ajustes Wi-Fi guardados, pero aún no hay dirección: espera un minuto y recarga esta página.","Set an admin password first.":"Primero establece una contraseña de administrador.","Connected to ":"Conectado a ","Could not update Wi-Fi config: ":"No se pudo actualizar la configuración Wi-Fi: ","queries today":"consultas hoy"," blocked (":" bloqueados (","answered from cache: ":"respondidas desde caché: "," · forwarded: ":" · reenviadas: ","Today":"Hoy","Each bar is 10 minutes — the purple part was blocked.":"Cada barra son 10 minutos: la parte morada se bloqueó.","The chart fills in as the day goes.":"El gráfico se va completando a lo largo del día.","Most visited today":"Más visitados hoy","Busiest devices":"Dispositivos más activos","Where answers came from":"De dónde vienen las respuestas","Traffic mix":"Mezcla de tráfico","Advanced view":"Vista avanzada","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"Para usuarios avanzados: el panel técnico completo con registro de consultas, gestión de listas de bloqueo y ajustes detallados.","Open advanced view":"Abrir vista avanzada","Uses the same password as this page. Changes there affect filtering for the whole home.":"Usa la misma contraseña que esta página. Los cambios de allí afectan al filtrado de toda la casa.","Whole home":"Toda la casa","Covered — ":"Cubiertos: "," devices seen on your network":" dispositivos vistos en tu red","Protection is paused — filtering is off.":"La protección está en pausa: el filtrado está desactivado.","Coverage paused — finishing network release…":"Cobertura en pausa: terminando de liberar la red…","Protection starts as soon as setup is finished.":"La protección empieza en cuanto termina la configuración.","Coverage is on — devices will appear as they browse.":"La cobertura está activa: los dispositivos aparecerán a medida que naveguen.","Coverage starting…":"Iniciando cobertura…","Coverage paused — the internet is open.":"Cobertura en pausa: Internet queda abierto.","Coverage is off.":"La cobertura está desactivada.","Coverage has not started — check the box.":"La cobertura no ha empezado: revisa el equipo.","Coverage status unavailable — check the box.":"Estado de cobertura no disponible: revisa el equipo.","Protection: starts after setup":"Protección: empieza tras la configuración","Finish setup to switch protection on for the whole home.":"Termina la configuración para activar la protección en toda la casa.","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"Configuración completada. La protección se está activando en toda tu casa: el panel muestra el progreso.","Coverage status is out of date — check the box.":"El estado de cobertura está desactualizado: revisa el equipo.","Coverage unavailable on this network — contact support.":"Cobertura no disponible en esta red: contacta con soporte.","Network release still finishing — check the box.":"La liberación de la red aún no ha terminado: revisa el equipo.","Coverage could not start — restart the box or contact support.":"No se pudo iniciar la cobertura: reinicia el equipo o contacta con soporte.","Internal error — try again.":"Error interno: inténtalo de nuevo.","That network name is not supported — choose another network.":"Ese nombre de red no es compatible: elige otra red.","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"Borra la contraseña del panel, los ajustes y las estadísticas. El filtrado sigue funcionando y los ajustes Wi-Fi se mantienen. Esto no se puede deshacer: si alguna vez olvidas la contraseña, mantén pulsado el botón RESET del equipo durante 5 segundos.","Protection lists need attention — the box is repairing them.":"Las listas de protección necesitan atención: el equipo las está reparando.","Filtering is on — coverage status unavailable.":"El filtrado está activo: estado de cobertura no disponible.","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"Tus listas de protección aún se están preparando: mantén el equipo enchufado y conectado e inténtalo de nuevo en unos minutos.","Filtering is already running for your whole home.":"El filtrado ya está funcionando en toda tu casa.","Protection is starting — no action needed.":"La protección está arrancando: no hay que hacer nada.","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"El panel y las estadísticas son opcionales. Establece una contraseña para usarlos; si no, cierra esta página y disfruta de la calma.","Set up the dashboard":"Configurar el panel","Choose your dashboard password":"Elige tu contraseña del panel","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"Esto protege el panel y la vista avanzada. Anótala en un lugar seguro. Si la olvidas, mantén pulsado el botón RESET del equipo durante 5 segundos.","You're all set 🛡️":"¡Todo listo! 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"El filtrado ya está funcionando en toda tu casa: el panel muestra cómo va.","Queries today":"Consultas hoy","Blocked":"Bloqueados","Blocked share":"Porcentaje bloqueado","ads and trackers":"anuncios y rastreadores","lookups today":"búsquedas hoy","Each bar is 10 minutes · busiest:":"Cada barra son 10 minutos · más activo:","since midnight":"desde medianoche","waiting for traffic":"esperando tráfico","Queries":"Consultas","Keep the box updated automatically":"Mantener el equipo actualizado automáticamente","Security fixes and filtering improvements only — no personal data leaves the box.":"Solo correcciones de seguridad y mejoras de filtrado; ningún dato personal sale del equipo.","Share anonymous diagnostic reports":"Compartir informes de diagnóstico anónimos","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"Registros de errores y comprobaciones de estado que nos ayudan a corregir problemas. Sin historial de navegación, nombres de dispositivos ni datos personales: solo detalles técnicos anónimos, enviados de forma privada.","Language":"Idioma","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"Este equipo no reconoció la dirección desde la que se abrió esta página. Abre http://filterbox.lan e inténtalo de nuevo.","Pause":"Pausar","This dashboard is private to your home. Enter the password you chose during setup.":"Este panel es privado de tu hogar. Introduce la contraseña que elegiste durante la configuración.","FilterBox — Sign in":"FilterBox — Iniciar sesión"," queries · ":" consultas · ","Wait a minute, then":"Espera un minuto y "},"fr":{"FilterBox — Setup":"FilterBox — Installation","Your filter box is online 🎉":"Votre FilterBox est en ligne 🎉","Checking your setup…":"Vérification de votre installation…","Protection…":"Protection…","Internet…":"Internet…","Get started":"Commencer","Choose your admin password":"Choisissez votre mot de passe administrateur","This protects your filter's settings page. Write it down somewhere safe.":"Cela protège la page de réglages de votre filtre. Notez-le en lieu sûr.","Password (at least 8 characters)":"Mot de passe (8 caractères minimum)","Repeat password":"Répétez le mot de passe","Save password":"Enregistrer le mot de passe","Internet connection":"Connexion Internet","Choose how this box reaches the internet.":"Choisissez comment ce boîtier se connecte à Internet.","Ethernet":"Ethernet","Scan for Wi-Fi networks":"Rechercher les réseaux Wi-Fi","Wi-Fi password":"Mot de passe Wi-Fi","Connect":"Connecter","Continue":"Continuer","All set! 🛡️":"Tout est prêt ! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"Votre réseau est protégé. Les publicités et les traqueurs sont filtrés pour chaque appareil qui utilise ce boîtier.","Opening your dashboard…":"Ouverture de votre tableau de bord…","Open dashboard":"Ouvrir le tableau de bord","Setup already complete":"Installation déjà terminée","This box has already been set up. Head to the dashboard to see how it's doing.":"Ce boîtier est déjà installé. Ouvrez le tableau de bord pour voir comment il se porte.","· your data stays on this device":"· vos données restent sur cet appareil","Bad response":"Réponse invalide","Protection: active":"Protection : active","Protection: warming up":"Protection : démarrage","Internet: connected":"Internet : connecté","Internet: not yet":"Internet : pas encore","This box: ":"Ce boîtier : ","Good news — filtering is already working.":"Bonne nouvelle : le filtrage fonctionne déjà.","Almost there — let’s finish the quick setup.":"Presque terminé : finissons l'installation rapide.","Ethernet: cable connected":"Ethernet : câble connecté","Ethernet: no cable detected":"Ethernet : aucun câble détecté","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"Le Wi-Fi est disponible sur ce boîtier : vous pouvez l'utiliser ou garder Ethernet.","This box filters through its network cable — nothing to configure here.":"Ce boîtier filtre via son câble réseau : rien à configurer ici.","Password needs at least 8 characters.":"Le mot de passe doit comporter au moins 8 caractères.","The two passwords don’t match.":"Les deux mots de passe ne correspondent pas.","Something went wrong.":"Une erreur est survenue.","Saving…":"Enregistrement…","Scanning…":"Recherche…","Scan again":"Rechercher à nouveau","Password for “":"Mot de passe de “","Connecting…":"Connexion…","Connected.":"Connecté.","Could not connect.":"Connexion impossible.","Not ready yet.":"Pas encore prêt.","No networks found. Try again, or keep using Ethernet.":"Aucun réseau trouvé. Réessayez, ou gardez Ethernet.","Checking on your filter…":"Vérification de votre filtre…","Turn back on":"Réactiver","blocked today":"bloqués aujourd'hui","Last 7 days":"7 derniers jours","Top blocked today":"Les plus bloqués aujourd'hui","Warming up…":"Démarrage…","Nothing blocked yet — enjoy the quiet.":"Rien de bloqué pour l'instant : profitez du calme.","Pause filtering?":"Suspendre le filtrage ?","Filtering will pause for a short break.":"Le filtrage sera suspendu pour une courte pause.","Pause 30 minutes":"Pause de 30 minutes","Pause 1 hour":"Pause 1 heure","Pause until I turn it back on":"Pause jusqu'à réactivation","Cancel":"Annuler","Enter your dashboard password":"Saisissez votre mot de passe du tableau de bord","Password":"Mot de passe","Settings":"Réglages","Tap to pause filtering":"Touchez pour suspendre le filtrage","Back in ":"Retour dans ","Back in ~":"Retour dans ~"," h ":" h "," min":" min","Could not reach the panel — reload in a moment.":"Panneau injoignable : rechargez dans un instant.","Too many requests — wait a minute.":"Trop de requêtes : attendez une minute.","Something went wrong — try again.":"Une erreur est survenue : réessayez.","Paused until you turn it back on.":"En pause jusqu'à réactivation.","Paused for 30 minutes.":"En pause pendant 30 minutes.","Paused for 1 hour.":"En pause pendant 1 heure.","Protection is back on.":"La protection est de nouveau active.","Paused until you turn it back on":"En pause jusqu'à réactivation","Protection: paused":"Protection : en pause","Protection: checking…":"Protection : vérification…","Protection: needs attention":"Protection : attention requise","Filter engine starting up — stats will appear shortly.":"Le moteur de filtrage démarre : les statistiques apparaîtront bientôt.","Ad blocking seems off — try restarting the box, or contact support.":"Le blocage des publicités semble inactif : redémarrez le boîtier ou contactez le support.","Working quietly in the background.":"Travaille discrètement en arrière-plan.","Internet: not reaching the internet":"Internet : pas d'accès à Internet","Internet: checking…":"Internet : vérification…","waiting for the filter engine…":"en attente du moteur de filtrage…","% of all queries · ":"% de toutes les requêtes · "," domains in your protection lists":" domaines dans vos listes de protection","Every bar is a slice of the week — taller means more ads blocked.":"Chaque barre représente une part de la semaine : plus elle est haute, plus de publicités sont bloquées.","The chart fills in as the week goes.":"Le graphique se remplit au fil de la semaine.","That password doesn't match — try again.":"Ce mot de passe ne correspond pas : réessayez."," blocked":" bloqués","FilterBox — Settings":"FilterBox — Réglages","← Dashboard":"← Tableau de bord","Change password":"Changer le mot de passe","This is the password for the dashboard and the advanced view.":"C'est le mot de passe du tableau de bord et de la vue avancée.","Current password":"Mot de passe actuel","New password (at least 8 characters)":"Nouveau mot de passe (8 caractères minimum)","Repeat new password":"Répétez le nouveau mot de passe","Password updated.":"Mot de passe mis à jour.","Save new password":"Enregistrer le nouveau mot de passe","Restart the box":"Redémarrer le boîtier","Takes about a minute. Filtering pauses briefly while it restarts.":"Environ une minute. Le filtrage est brièvement suspendu pendant le redémarrage.","Restart now":"Redémarrer maintenant","Factory reset":"Réinitialisation d'usine","Reset this box…":"Réinitialiser ce boîtier…","Type RESET to confirm":"Saisissez RESET pour confirmer","Dashboard password":"Mot de passe du tableau de bord","Erase everything and reset":"Tout effacer et réinitialiser","About":"À propos","Panel version":"Version du panneau","Filter engine":"Moteur de filtrage","Uptime":"Durée de service","Address":"Adresse","Working…":"En cours…","Please wait.":"Veuillez patienter.","Password must be at least 8 characters.":"Le mot de passe doit comporter au moins 8 caractères.","The two new passwords don’t match.":"Les deux nouveaux mots de passe ne correspondent pas.","Restart now? Tap again to confirm":"Redémarrer maintenant ? Touchez à nouveau pour confirmer","Restarting…":"Redémarrage…","Back online.":"De nouveau en ligne.","This takes about a minute. Filtering pauses briefly while it restarts.":"Cela prend environ une minute. Le filtrage est brièvement suspendu pendant le redémarrage.","Restarting the box":"Redémarrage du boîtier","Still working…":"Toujours en cours…","Reloading…":"Rechargement…","Type RESET exactly to confirm.":"Saisissez exactement RESET pour confirmer.","Resetting the box":"Réinitialisation du boîtier","Erasing settings and returning to setup mode — the box will restart.":"Effacement des réglages et retour au mode installation : le boîtier va redémarrer.","Back to setup — reloading…":"Retour à l'installation : rechargement…"," d ":" j ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"Le boîtier n'est pas encore revenu. Vérifiez qu'il est sous tension, puis rechargez cette page.","Too many requests":"Trop de requêtes","Wait a minute, then ":"Attendez une minute, puis ","reload the dashboard":"rechargez le tableau de bord","Nothing here":"Rien ici","That page doesn't exist.":"Cette page n'existe pas.","Back to FilterBox":"Retour à FilterBox","not found":"introuvable","Too many attempts — wait a minute.":"Trop de tentatives : attendez une minute.","Session expired — enter the password again.":"Session expirée : saisissez à nouveau le mot de passe.","Pick 30 minutes, 1 hour, or until you turn it back on.":"Choisissez 30 minutes, 1 heure, ou jusqu'à réactivation.","Setup is already complete.":"L'installation est déjà terminée.","That's not the current password — try again.":"Ce n'est pas le mot de passe actuel : réessayez.","Password is too long (max 128 characters).":"Mot de passe trop long (128 caractères maximum).","Couldn't start the restart — check that the box is powered, then try again.":"Impossible de lancer le redémarrage : vérifiez que le boîtier est alimenté, puis réessayez.","Could not set the password (service not ready?). Try again in a moment.":"Impossible d'enregistrer le mot de passe (service pas prêt ?). Réessayez dans un instant.","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"Aucun adaptateur Wi-Fi détecté sur ce boîtier : il utilise Ethernet. Tout est prêt.","Pick a network and enter its password (at least 8 chars).":"Choisissez un réseau et saisissez son mot de passe (8 caractères minimum).","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"Pas d'adaptateur Wi-Fi sur ce boîtier : Ethernet est la solution. Rien à faire ici.","Wi-Fi tools are not available on this box.":"Les outils Wi-Fi ne sont pas disponibles sur ce boîtier.","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"Réglages Wi-Fi enregistrés, mais pas encore d'adresse : patientez une minute et rechargez cette page.","Set an admin password first.":"Définissez d'abord un mot de passe administrateur.","Connected to ":"Connecté à ","Could not update Wi-Fi config: ":"Impossible de mettre à jour la configuration Wi-Fi : ","queries today":"requêtes aujourd'hui"," blocked (":" bloqués (","answered from cache: ":"répondues depuis le cache : "," · forwarded: ":" · transmises : ","Today":"Aujourd'hui","Each bar is 10 minutes — the purple part was blocked.":"Chaque barre représente 10 minutes : la partie violette a été bloquée.","The chart fills in as the day goes.":"Le graphique se remplit au fil de la journée.","Most visited today":"Les plus visités aujourd'hui","Busiest devices":"Appareils les plus actifs","Where answers came from":"Provenance des réponses","Traffic mix":"Répartition du trafic","Advanced view":"Vue avancée","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"Pour les utilisateurs avancés : le tableau de bord technique complet avec journal des requêtes, gestion des listes de blocage et réglages détaillés.","Open advanced view":"Ouvrir la vue avancée","Uses the same password as this page. Changes there affect filtering for the whole home.":"Utilise le même mot de passe que cette page. Les modifications apportées ici affectent le filtrage de toute la maison.","Whole home":"Toute la maison","Covered — ":"Couverts : "," devices seen on your network":" appareils vus sur votre réseau","Protection is paused — filtering is off.":"La protection est en pause : le filtrage est désactivé.","Coverage paused — finishing network release…":"Couverture en pause : libération du réseau en cours…","Protection starts as soon as setup is finished.":"La protection démarre dès que l'installation est terminée.","Coverage is on — devices will appear as they browse.":"La couverture est active : les appareils apparaîtront au fil de leur navigation.","Coverage starting…":"Démarrage de la couverture…","Coverage paused — the internet is open.":"Couverture en pause : Internet est ouvert.","Coverage is off.":"La couverture est désactivée.","Coverage has not started — check the box.":"La couverture n'a pas démarré : vérifiez le boîtier.","Coverage status unavailable — check the box.":"État de la couverture indisponible : vérifiez le boîtier.","Protection: starts after setup":"Protection : démarre après l'installation","Finish setup to switch protection on for the whole home.":"Terminez l'installation pour activer la protection dans toute la maison.","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"Installation terminée. La protection s'active pour toute votre maison : le tableau de bord montre sa progression.","Coverage status is out of date — check the box.":"L'état de la couverture est obsolète : vérifiez le boîtier.","Coverage unavailable on this network — contact support.":"Couverture indisponible sur ce réseau : contactez le support.","Network release still finishing — check the box.":"La libération du réseau n'est pas terminée : vérifiez le boîtier.","Coverage could not start — restart the box or contact support.":"La couverture n'a pas pu démarrer : redémarrez le boîtier ou contactez le support.","Internal error — try again.":"Erreur interne : réessayez.","That network name is not supported — choose another network.":"Ce nom de réseau n'est pas pris en charge : choisissez un autre réseau.","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"Efface le mot de passe du tableau de bord, les réglages et les statistiques. Le filtrage continue et les réglages Wi-Fi sont conservés. Action irréversible : si vous oubliez le mot de passe, maintenez le bouton RESET du boîtier pendant 5 secondes.","Protection lists need attention — the box is repairing them.":"Les listes de protection nécessitent votre attention : le boîtier les répare.","Filtering is on — coverage status unavailable.":"Le filtrage est actif : état de la couverture indisponible.","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"Vos listes de protection sont encore en préparation : gardez le boîtier sous tension et connecté, puis réessayez dans quelques minutes.","Filtering is already running for your whole home.":"Le filtrage est déjà actif pour toute votre maison.","Protection is starting — no action needed.":"La protection démarre : aucune action nécessaire.","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"Le tableau de bord et les statistiques sont facultatifs. Définissez un mot de passe pour les utiliser ; sinon, fermez cette page et profitez du calme.","Set up the dashboard":"Configurer le tableau de bord","Choose your dashboard password":"Choisissez votre mot de passe du tableau de bord","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"Cela protège le tableau de bord et la vue avancée. Notez-le en lieu sûr. Si vous l'oubliez, maintenez le bouton RESET du boîtier pendant 5 secondes.","You're all set 🛡️":"Tout est prêt 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"Le filtrage est déjà actif pour toute votre maison : le tableau de bord montre comment cela se passe.","Queries today":"Requêtes aujourd'hui","Blocked":"Bloqués","Blocked share":"Part bloquée","ads and trackers":"publicités et traqueurs","lookups today":"recherches aujourd'hui","Each bar is 10 minutes · busiest:":"Chaque barre = 10 minutes · le plus actif :","since midnight":"depuis minuit","waiting for traffic":"en attente de trafic","Queries":"Requêtes","Keep the box updated automatically":"Mettre à jour le boîtier automatiquement","Security fixes and filtering improvements only — no personal data leaves the box.":"Uniquement des correctifs de sécurité et des améliorations de filtrage — aucune donnée personnelle ne quitte le boîtier.","Share anonymous diagnostic reports":"Partager des rapports de diagnostic anonymes","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"Journaux d'erreurs et contrôles de santé qui nous aident à corriger les problèmes. Aucun historique de navigation, nom d'appareil ou donnée personnelle — uniquement des détails techniques anonymisés, envoyés en privé.","Language":"Langue","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"Ce boîtier n'a pas reconnu l'adresse depuis laquelle cette page a été ouverte. Ouvrez http://filterbox.lan et réessayez.","Pause":"Pause","This dashboard is private to your home. Enter the password you chose during setup.":"Ce tableau de bord est privé, propre à votre foyer. Saisissez le mot de passe choisi lors de l'installation.","FilterBox — Sign in":"FilterBox — Connexion"," queries · ":" requêtes · ","Wait a minute, then":"Attendez une minute, puis "},"it":{"FilterBox — Setup":"FilterBox — Configurazione","Your filter box is online 🎉":"Il tuo FilterBox è online 🎉","Checking your setup…":"Verifica della configurazione…","Protection…":"Protezione…","Internet…":"Internet…","Get started":"Inizia","Choose your admin password":"Scegli la password di amministratore","This protects your filter's settings page. Write it down somewhere safe.":"Protegge la pagina delle impostazioni del filtro. Scrivila in un posto sicuro.","Password (at least 8 characters)":"Password (almeno 8 caratteri)","Repeat password":"Ripeti la password","Save password":"Salva la password","Internet connection":"Connessione a internet","Choose how this box reaches the internet.":"Scegli come questo apparecchio si collega a internet.","Ethernet":"Ethernet","Scan for Wi-Fi networks":"Cerca reti Wi-Fi","Wi-Fi password":"Password Wi-Fi","Connect":"Connetti","Continue":"Continua","All set! 🛡️":"Tutto pronto! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"La tua rete è ora protetta. Gli annunci e i tracker vengono filtrati per ogni dispositivo che usa questo apparecchio.","Opening your dashboard…":"Apertura del pannello…","Open dashboard":"Apri il pannello","Setup already complete":"Configurazione già completata","This box has already been set up. Head to the dashboard to see how it's doing.":"Questo apparecchio è già stato configurato. Vai al pannello per vedere come sta andando.","· your data stays on this device":"· i tuoi dati restano su questo dispositivo","Bad response":"Risposta non valida","Protection: active":"Protezione: attiva","Protection: warming up":"Protezione: avvio in corso","Internet: connected":"Internet: connesso","Internet: not yet":"Internet: non ancora","This box: ":"Questo apparecchio: ","Good news — filtering is already working.":"Buone notizie — il filtraggio sta già funzionando.","Almost there — let’s finish the quick setup.":"Ci siamo quasi — completiamo la configurazione rapida.","Ethernet: cable connected":"Ethernet: cavo collegato","Ethernet: no cable detected":"Ethernet: nessun cavo rilevato","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"Il Wi-Fi è disponibile su questo apparecchio — puoi usarlo o restare su Ethernet.","This box filters through its network cable — nothing to configure here.":"Questo apparecchio filtra tramite il cavo di rete — qui non c'è nulla da configurare.","Password needs at least 8 characters.":"La password deve avere almeno 8 caratteri.","The two passwords don’t match.":"Le due password non coincidono.","Something went wrong.":"Qualcosa è andato storto.","Saving…":"Salvataggio…","Scanning…":"Scansione…","Scan again":"Cerca di nuovo","Password for “":"Password per “","Connecting…":"Connessione…","Connected.":"Connesso.","Could not connect.":"Connessione non riuscita.","Not ready yet.":"Non ancora pronto.","No networks found. Try again, or keep using Ethernet.":"Nessuna rete trovata. Riprova o continua con Ethernet.","Checking on your filter…":"Verifica del filtro in corso…","Turn back on":"Riattiva","blocked today":"bloccati oggi","Last 7 days":"Ultimi 7 giorni","Top blocked today":"Più bloccati oggi","Warming up…":"Avvio…","Nothing blocked yet — enjoy the quiet.":"Ancora nulla bloccato — goditi la tranquillità.","Pause filtering?":"Mettere in pausa il filtraggio?","Filtering will pause for a short break.":"Il filtraggio si fermerà per una breve pausa.","Pause 30 minutes":"Pausa di 30 minuti","Pause 1 hour":"Pausa di 1 ora","Pause until I turn it back on":"In pausa finché non lo riattivo","Cancel":"Annulla","Enter your dashboard password":"Inserisci la password del pannello","Password":"Password","Settings":"Impostazioni","Tap to pause filtering":"Tocca per mettere in pausa il filtraggio","Back in ":"Riprende tra ","Back in ~":"Riprende tra ~"," h ":" h "," min":" min","Could not reach the panel — reload in a moment.":"Impossibile raggiungere il pannello — ricarica tra poco.","Too many requests — wait a minute.":"Troppe richieste — aspetta un minuto.","Something went wrong — try again.":"Qualcosa è andato storto — riprova.","Paused until you turn it back on.":"In pausa finché non lo riattivi.","Paused for 30 minutes.":"In pausa per 30 minuti.","Paused for 1 hour.":"In pausa per 1 ora.","Protection is back on.":"La protezione è di nuovo attiva.","Paused until you turn it back on":"In pausa finché non lo riattivi","Protection: paused":"Protezione: in pausa","Protection: checking…":"Protezione: verifica…","Protection: needs attention":"Protezione: richiede attenzione","Filter engine starting up — stats will appear shortly.":"Il motore di filtraggio si sta avviando — le statistiche arriveranno a breve.","Ad blocking seems off — try restarting the box, or contact support.":"Il blocco degli annunci sembra disattivato — prova a riavviare l'apparecchio o contatta l'assistenza.","Working quietly in the background.":"Lavora in silenzio in background.","Internet: not reaching the internet":"Internet: nessun accesso a internet","Internet: checking…":"Internet: verifica…","waiting for the filter engine…":"in attesa del motore di filtraggio…","% of all queries · ":"% di tutte le richieste · "," domains in your protection lists":" domini nelle tue liste di protezione","Every bar is a slice of the week — taller means more ads blocked.":"Ogni barra è una fetta della settimana — più alta significa più annunci bloccati.","The chart fills in as the week goes.":"Il grafico si riempie con il passare della settimana.","That password doesn't match — try again.":"Questa password non corrisponde — riprova."," blocked":" bloccati","FilterBox — Settings":"FilterBox — Impostazioni","← Dashboard":"← Pannello","Change password":"Cambia password","This is the password for the dashboard and the advanced view.":"È la password del pannello e della vista avanzata.","Current password":"Password attuale","New password (at least 8 characters)":"Nuova password (almeno 8 caratteri)","Repeat new password":"Ripeti la nuova password","Password updated.":"Password aggiornata.","Save new password":"Salva la nuova password","Restart the box":"Riavvia l'apparecchio","Takes about a minute. Filtering pauses briefly while it restarts.":"Richiede circa un minuto. Il filtraggio si ferma brevemente durante il riavvio.","Restart now":"Riavvia ora","Factory reset":"Ripristino di fabbrica","Reset this box…":"Ripristina questo apparecchio…","Type RESET to confirm":"Scrivi RESET per confermare","Dashboard password":"Password del pannello","Erase everything and reset":"Cancella tutto e ripristina","About":"Informazioni","Panel version":"Versione del pannello","Filter engine":"Motore di filtraggio","Uptime":"Tempo di attività","Address":"Indirizzo","Working…":"In corso…","Please wait.":"Attendi.","Password must be at least 8 characters.":"La password deve avere almeno 8 caratteri.","The two new passwords don’t match.":"Le due nuove password non coincidono.","Restart now? Tap again to confirm":"Riavviare ora? Tocca di nuovo per confermare","Restarting…":"Riavvio…","Back online.":"Di nuovo online.","This takes about a minute. Filtering pauses briefly while it restarts.":"Richiede circa un minuto. Il filtraggio si ferma brevemente durante il riavvio.","Restarting the box":"Riavvio dell'apparecchio","Still working…":"Ancora in corso…","Reloading…":"Ricaricamento…","Type RESET exactly to confirm.":"Scrivi RESET esattamente per confermare.","Resetting the box":"Ripristino dell'apparecchio","Erasing settings and returning to setup mode — the box will restart.":"Cancellazione delle impostazioni e ritorno alla modalità di configurazione — l'apparecchio si riavvierà.","Back to setup — reloading…":"Torna alla configurazione — ricaricamento…"," d ":" g ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"L'apparecchio non è ancora tornato. Controlla che sia alimentato, poi ricarica questa pagina.","Too many requests":"Troppe richieste","Wait a minute, then ":"Aspetta un minuto, poi ","reload the dashboard":"ricarica il pannello","Nothing here":"Niente qui","That page doesn't exist.":"Questa pagina non esiste.","Back to FilterBox":"Torna a FilterBox","not found":"non trovato","Too many attempts — wait a minute.":"Troppi tentativi — aspetta un minuto.","Session expired — enter the password again.":"Sessione scaduta — inserisci di nuovo la password.","Pick 30 minutes, 1 hour, or until you turn it back on.":"Scegli 30 minuti, 1 ora o finché non lo riattivi.","Setup is already complete.":"La configurazione è già completata.","That's not the current password — try again.":"Non è la password attuale — riprova.","Password is too long (max 128 characters).":"La password è troppo lunga (max 128 caratteri).","Couldn't start the restart — check that the box is powered, then try again.":"Impossibile avviare il riavvio — controlla che l'apparecchio sia alimentato, poi riprova.","Could not set the password (service not ready?). Try again in a moment.":"Impossibile impostare la password (servizio non pronto?). Riprova tra poco.","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"Nessun adattatore Wi-Fi rilevato su questo apparecchio — usa Ethernet. Tutto pronto.","Pick a network and enter its password (at least 8 chars).":"Scegli una rete e inserisci la password (almeno 8 caratteri).","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"Nessun adattatore Wi-Fi su questo apparecchio — Ethernet è la strada. Niente da fare qui.","Wi-Fi tools are not available on this box.":"Gli strumenti Wi-Fi non sono disponibili su questo apparecchio.","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"Impostazioni Wi-Fi salvate, ma ancora nessun indirizzo — aspetta un minuto e ricarica questa pagina.","Set an admin password first.":"Imposta prima una password di amministratore.","Connected to ":"Connesso a ","Could not update Wi-Fi config: ":"Impossibile aggiornare la configurazione Wi-Fi: ","queries today":"richieste oggi"," blocked (":" bloccati (","answered from cache: ":"risposte dalla cache: "," · forwarded: ":" · inoltrati: ","Today":"Oggi","Each bar is 10 minutes — the purple part was blocked.":"Ogni barra sono 10 minuti — la parte viola è stata bloccata.","The chart fills in as the day goes.":"Il grafico si riempie con il passare della giornata.","Most visited today":"Più visitati oggi","Busiest devices":"Dispositivi più attivi","Where answers came from":"Da dove arrivano le risposte","Traffic mix":"Composizione del traffico","Advanced view":"Vista avanzata","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"Per utenti esperti — il pannello tecnico completo: registro delle richieste, gestione delle liste di blocco e impostazioni dettagliate.","Open advanced view":"Apri la vista avanzata","Uses the same password as this page. Changes there affect filtering for the whole home.":"Usa la stessa password di questa pagina. Le modifiche lì influiscono sul filtraggio di tutta la casa.","Whole home":"Tutta la casa","Covered — ":"Coperti — "," devices seen on your network":" dispositivi visti sulla tua rete","Protection is paused — filtering is off.":"La protezione è in pausa — il filtraggio è disattivato.","Coverage paused — finishing network release…":"Copertura in pausa — conclusione del rilascio della rete…","Protection starts as soon as setup is finished.":"La protezione inizia appena la configurazione è terminata.","Coverage is on — devices will appear as they browse.":"La copertura è attiva — i dispositivi appariranno mentre navigano.","Coverage starting…":"Avvio della copertura…","Coverage paused — the internet is open.":"Copertura in pausa — internet è aperto.","Coverage is off.":"La copertura è disattivata.","Coverage has not started — check the box.":"La copertura non è partita — controlla l'apparecchio.","Coverage status unavailable — check the box.":"Stato della copertura non disponibile — controlla l'apparecchio.","Protection: starts after setup":"Protezione: inizia dopo la configurazione","Finish setup to switch protection on for the whole home.":"Completa la configurazione per attivare la protezione su tutta la casa.","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"Configurazione completata. La protezione si sta attivando per tutta la casa — il pannello mostra i progressi.","Coverage status is out of date — check the box.":"Lo stato della copertura è vecchio — controlla l'apparecchio.","Coverage unavailable on this network — contact support.":"Copertura non disponibile su questa rete — contatta l'assistenza.","Network release still finishing — check the box.":"Il rilascio della rete è ancora in corso — controlla l'apparecchio.","Coverage could not start — restart the box or contact support.":"Impossibile avviare la copertura — riavvia l'apparecchio o contatta l'assistenza.","Internal error — try again.":"Errore interno — riprova.","That network name is not supported — choose another network.":"Questo nome di rete non è supportato — scegli un'altra rete.","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"Cancella la password del pannello, le impostazioni e le statistiche. Il filtraggio continua e le impostazioni Wi-Fi restano. Non può essere annullato — se dimentichi la password, tieni premuto il pulsante RESET sull'apparecchio per 5 secondi.","Protection lists need attention — the box is repairing them.":"Le liste di protezione richiedono attenzione — l'apparecchio le sta riparando.","Filtering is on — coverage status unavailable.":"Il filtraggio è attivo — stato della copertura non disponibile.","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"Le tue liste di protezione sono ancora in preparazione — tieni l'apparecchio alimentato e collegato, poi riprova tra qualche minuto.","Filtering is already running for your whole home.":"Il filtraggio è già attivo per tutta la casa.","Protection is starting — no action needed.":"La protezione si sta avviando — non serve fare nulla.","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"Il pannello e le statistiche sono facoltativi. Imposta una password per usarli — altrimenti chiudi questa pagina e goditi la tranquillità.","Set up the dashboard":"Configura il pannello","Choose your dashboard password":"Scegli la password del pannello","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"Protegge il pannello e la vista avanzata. Scrivila in un posto sicuro. Se la dimentichi, tieni premuto il pulsante RESET sull'apparecchio per 5 secondi.","You're all set 🛡️":"Tutto pronto 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"Il filtraggio è già attivo per tutta la casa — il pannello mostra come sta andando.","Queries today":"Richieste oggi","Blocked":"Bloccati","Blocked share":"Quota bloccata","ads and trackers":"annunci e tracker","lookups today":"ricerche oggi","Each bar is 10 minutes · busiest:":"Ogni barra sono 10 minuti · più traffico:","since midnight":"da mezzanotte","waiting for traffic":"in attesa di traffico","Queries":"Richieste","Keep the box updated automatically":"Mantieni il dispositivo aggiornato automaticamente","Security fixes and filtering improvements only — no personal data leaves the box.":"Solo correzioni di sicurezza e miglioramenti del filtro: nessun dato personale lascia il dispositivo.","Share anonymous diagnostic reports":"Condividi rapporti diagnostici anonimi","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"Registri errori e controlli di stato che ci aiutano a risolvere i problemi. Nessuna cronologia di navigazione, nome di dispositivo o dato personale: solo dettagli tecnici anonimi, inviati in privato.","Language":"Lingua","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"Questo dispositivo non ha riconosciuto l'indirizzo da cui è stata aperta questa pagina. Apri http://filterbox.lan e riprova.","Pause":"Pausa","This dashboard is private to your home. Enter the password you chose during setup.":"Questa dashboard è privata per la tua casa. Inserisci la password scelta durante la configurazione.","FilterBox — Sign in":"FilterBox — Accedi"," queries · ":" query · ","Wait a minute, then":"Attendi un minuto, poi "},"ja":{"FilterBox — Setup":"FilterBox — セットアップ","Your filter box is online 🎉":"フィルターボックスがオンラインになりました 🎉","Checking your setup…":"設定を確認しています…","Protection…":"保護…","Internet…":"インターネット…","Get started":"はじめる","Choose your admin password":"管理者パスワードを設定","This protects your filter's settings page. Write it down somewhere safe.":"このパスワードはフィルターの設定ページを守ります。忘れないよう、安全な場所に書き留めてください。","Password (at least 8 characters)":"パスワード（8 文字以上）","Repeat password":"パスワード（確認）","Save password":"パスワードを保存","Internet connection":"インターネット接続","Choose how this box reaches the internet.":"このボックスをインターネットにつなぐ方法を選びます。","Ethernet":"イーサネット","Scan for Wi-Fi networks":"Wi-Fi ネットワークを検索","Wi-Fi password":"Wi-Fi パスワード","Connect":"接続","Continue":"次へ","All set! 🛡️":"準備完了！🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"これでご自宅のネットワークは保護されました。このボックスを使うすべての機器で、広告とトラッカーがブロックされています。","Opening your dashboard…":"ダッシュボードを開いています…","Open dashboard":"ダッシュボードを開く","Setup already complete":"セットアップは完了しています","This box has already been set up. Head to the dashboard to see how it's doing.":"このボックスはすでに設定済みです。ダッシュボードで状態を確認できます。","· your data stays on this device":"· データはこの機器の中に留まります","Bad response":"応答エラー","Protection: active":"保護：有効","Protection: warming up":"保護：準備中","Internet: connected":"インターネット：接続済み","Internet: not yet":"インターネット：未接続","This box: ":"本体：","Good news — filtering is already working.":"いいお知らせです — フィルタリングはすでに動いています。","Almost there — let’s finish the quick setup.":"あと少し — 簡単なセットアップを終わらせましょう。","Ethernet: cable connected":"Ethernet：ケーブル接続済み","Ethernet: no cable detected":"Ethernet：ケーブルが見つかりません","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"このボックスは Wi-Fi に対応しています。Wi-Fi を使うことも、Ethernet のままでもかまいません。","This box filters through its network cable — nothing to configure here.":"このボックスはネットワークケーブルで動作します。ここで設定することはありません。","Password needs at least 8 characters.":"パスワードは 8 文字以上にしてください。","The two passwords don’t match.":"パスワードが一致しません。","Something went wrong.":"問題が発生しました。","Saving…":"保存しています…","Scanning…":"検索しています…","Scan again":"もう一度検索","Password for “":"パスワード：“","Connecting…":"接続しています…","Connected.":"接続しました。","Could not connect.":"接続できませんでした。","Not ready yet.":"まだ準備ができていません。","No networks found. Try again, or keep using Ethernet.":"ネットワークが見つかりません。もう一度試すか、Ethernet のままお使いください。","Checking on your filter…":"フィルターを確認しています…","Turn back on":"オンに戻す","blocked today":"本日のブロック","Last 7 days":"過去 7 日間","Top blocked today":"本日のブロック上位","Warming up…":"準備中…","Nothing blocked yet — enjoy the quiet.":"まだ何もブロックしていません — 静かな時間をお楽しみください。","Pause filtering?":"フィルタリングを一時停止しますか？","Filtering will pause for a short break.":"フィルタリングを少しの間止めます。","Pause 30 minutes":"30 分間停止","Pause 1 hour":"1 時間停止","Pause until I turn it back on":"自分で戻すまで停止","Cancel":"キャンセル","Enter your dashboard password":"ダッシュボードのパスワードを入力","Password":"パスワード","Settings":"設定","Tap to pause filtering":"タップして一時停止","Back in ":"あと ","Back in ~":"あと約 "," h ":" 時間 "," min":" 分","Could not reach the panel — reload in a moment.":"パネルに接続できません — 少ししてから再読み込みしてください。","Too many requests — wait a minute.":"リクエストが多すぎます — 1 分お待ちください。","Something went wrong — try again.":"問題が発生しました — もう一度お試しください。","Paused until you turn it back on.":"戻すまで停止しています。","Paused for 30 minutes.":"30 分間停止しました。","Paused for 1 hour.":"1 時間停止しました。","Protection is back on.":"保護が再開しました。","Paused until you turn it back on":"戻すまで停止","Protection: paused":"保護：停止中","Protection: checking…":"保護：確認中…","Protection: needs attention":"保護：要確認","Filter engine starting up — stats will appear shortly.":"フィルターエンジンを起動中です — まもなく統計が表示されます。","Ad blocking seems off — try restarting the box, or contact support.":"広告ブロックが止まっているようです — ボックスを再起動するか、サポートにご連絡ください。","Working quietly in the background.":"裏で静かに動いています。","Internet: not reaching the internet":"インターネット：接続できません","Internet: checking…":"インターネット：確認中…","waiting for the filter engine…":"フィルターエンジンを待っています…","% of all queries · ":"全クエリの % · "," domains in your protection lists":" ドメインを保護リストに収録","Every bar is a slice of the week — taller means more ads blocked.":"棒グラフは 1 週間の区切りです — 高いほど広告を多くブロックしたことを示します。","The chart fills in as the week goes.":"週が進むにつれてグラフが埋まっていきます。","That password doesn't match — try again.":"パスワードが違います — もう一度お試しください。"," blocked":" ブロック","FilterBox — Settings":"FilterBox — 設定","← Dashboard":"← ダッシュボード","Change password":"パスワードを変更","This is the password for the dashboard and the advanced view.":"これはダッシュボードと詳細画面のパスワードです。","Current password":"現在のパスワード","New password (at least 8 characters)":"新しいパスワード（8 文字以上）","Repeat new password":"新しいパスワード（確認）","Password updated.":"パスワードを更新しました。","Save new password":"新しいパスワードを保存","Restart the box":"ボックスを再起動","Takes about a minute. Filtering pauses briefly while it restarts.":"1 分ほどかかります。再起動中はフィルタリングが少し止まります。","Restart now":"今すぐ再起動","Factory reset":"初期化","Reset this box…":"このボックスを初期化…","Type RESET to confirm":"RESET と入力して確認","Dashboard password":"ダッシュボードのパスワード","Erase everything and reset":"すべて消去して初期化","About":"この製品について","Panel version":"パネルのバージョン","Filter engine":"フィルターエンジン","Uptime":"稼働時間","Address":"アドレス","Working…":"処理中…","Please wait.":"しばらくお待ちください。","Password must be at least 8 characters.":"パスワードは 8 文字以上にしてください。","The two new passwords don’t match.":"新しいパスワードが一致しません。","Restart now? Tap again to confirm":"今すぐ再起動しますか？もう一度タップで確定","Restarting…":"再起動しています…","Back online.":"オンラインに戻りました。","This takes about a minute. Filtering pauses briefly while it restarts.":"1 分ほどかかります。再起動中はフィルタリングが少し止まります。","Restarting the box":"ボックスを再起動しています","Still working…":"まだ処理中です…","Reloading…":"再読み込み中…","Type RESET exactly to confirm.":"確認のため RESET と正確に入力してください。","Resetting the box":"ボックスを初期化しています","Erasing settings and returning to setup mode — the box will restart.":"設定を消去してセットアップモードに戻ります — ボックスは再起動します。","Back to setup — reloading…":"セットアップに戻ります — 再読み込み中…"," d ":" 日 ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"ボックスがまだ戻ってきません。電源が入っているか確認して、このページを再読み込みしてください。","Too many requests":"リクエストが多すぎます","Wait a minute, then ":"1 分待ってから ","reload the dashboard":"ダッシュボードを再読み込み","Nothing here":"何もありません","That page doesn't exist.":"このページは存在しません。","Back to FilterBox":"FilterBox に戻る","not found":"見つかりません","Too many attempts — wait a minute.":"試行回数が多すぎます — 1 分お待ちください。","Session expired — enter the password again.":"セッションが切れました — もう一度パスワードを入力してください。","Pick 30 minutes, 1 hour, or until you turn it back on.":"30 分、1 時間、または自分で戻すまでから選んでください。","Setup is already complete.":"セットアップは完了済みです。","That's not the current password — try again.":"現在のパスワードが違います — もう一度お試しください。","Password is too long (max 128 characters).":"パスワードが長すぎます（最大 128 文字）。","Couldn't start the restart — check that the box is powered, then try again.":"再起動を開始できませんでした — ボックスの電源を確認して、もう一度お試しください。","Could not set the password (service not ready?). Try again in a moment.":"パスワードを設定できませんでした（サービスが未準備？）。少ししてからもう一度お試しください。","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"このボックスには Wi-Fi アダプターがありません — Ethernet で動作します。準備は完了です。","Pick a network and enter its password (at least 8 chars).":"ネットワークを選んでパスワードを入力してください（8 文字以上）。","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"このボックスに Wi-Fi アダプターはありません — Ethernet をお使いください。ここですることはありません。","Wi-Fi tools are not available on this box.":"このボックスでは Wi-Fi 機能を利用できません。","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"Wi-Fi 設定は保存しましたが、まだアドレスがありません — 1 分ほど待ってからこのページを再読み込みしてください。","Set an admin password first.":"先に管理者パスワードを設定してください。","Connected to ":"接続先: ","Could not update Wi-Fi config: ":"Wi-Fi 設定を更新できませんでした：","queries today":"本日のクエリ"," blocked (":" ブロック（","answered from cache: ":"キャッシュから応答: "," · forwarded: ":" · 転送: ","Today":"今日","Each bar is 10 minutes — the purple part was blocked.":"棒 1 本が 10 分です — 紫の部分がブロックされた分です。","The chart fills in as the day goes.":"時間が経つにつれてグラフが埋まっていきます。","Most visited today":"本日のアクセス上位","Busiest devices":"よく使われる機器","Where answers came from":"応答の取得元","Traffic mix":"通信の内訳","Advanced view":"詳細ビュー","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"上級者向け — 技術的なフル機能のダッシュボード：クエリログ、ブロックリスト管理、詳細設定。","Open advanced view":"詳細ビューを開く","Uses the same password as this page. Changes there affect filtering for the whole home.":"このページと同じパスワードです。変更は家じゅうのフィルタリングに影響します。","Whole home":"家じゅう","Covered — ":"カバー済み — "," devices seen on your network":" 台の機器をネットワークで確認","Protection is paused — filtering is off.":"保護は停止中です — フィルタリングはオフです。","Coverage paused — finishing network release…":"カバーを停止中 — ネットワークの解放を完了しています…","Protection starts as soon as setup is finished.":"セットアップが終わるとすぐに保護が始まります。","Coverage is on — devices will appear as they browse.":"カバー中です — 機器は通信すると表示されます。","Coverage starting…":"カバーを開始しています…","Coverage paused — the internet is open.":"カバー停止中 — ネットワークは無防備です。","Coverage is off.":"カバーはオフです。","Coverage has not started — check the box.":"カバーが始まっていません — ボックスを確認してください。","Coverage status unavailable — check the box.":"カバー状態を取得できません — ボックスを確認してください。","Protection: starts after setup":"保護：セットアップ後に開始","Finish setup to switch protection on for the whole home.":"セットアップを終えると、家じゅうの保護がオンになります。","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"セットアップ完了。家じゅうの保護をオンにしています — 進み具合はダッシュボードで確認できます。","Coverage status is out of date — check the box.":"カバー状態が古くなっています — ボックスを確認してください。","Coverage unavailable on this network — contact support.":"このネットワークではカバーできません — サポートにご連絡ください。","Network release still finishing — check the box.":"ネットワークの解放がまだ終わっていません — ボックスを確認してください。","Coverage could not start — restart the box or contact support.":"カバーを開始できませんでした — ボックスを再起動するか、サポートにご連絡ください。","Internal error — try again.":"内部エラー — もう一度お試しください。","That network name is not supported — choose another network.":"このネットワーク名は使えません — 別のネットワークを選んでください。","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"ダッシュボードのパスワード、設定、統計を消去します。フィルタリングはそのまま続き、Wi-Fi 設定も残ります。元に戻すことはできません — パスワードを忘れた場合は、ボックス側面の RESET ボタンを 5 秒間押してください。","Protection lists need attention — the box is repairing them.":"保護リストに問題があります — ボックスが修復しています。","Filtering is on — coverage status unavailable.":"フィルタリングはオンです — カバー状態を取得できません。","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"保護リストをまだ準備しています — ボックスの電源と接続を保ったまま、数分後にもう一度お試しください。","Filtering is already running for your whole home.":"家じゅうのフィルタリングはすでに動いています。","Protection is starting — no action needed.":"保護を開始しています — 操作は不要です。","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"ダッシュボードと統計は任意です。使う場合はパスワードを設定してください — 使わないならこのページを閉じて、静かなネットを楽しんでください。","Set up the dashboard":"ダッシュボードを設定","Choose your dashboard password":"ダッシュボードのパスワードを設定","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"このパスワードはダッシュボードと詳細ビューを守ります。安全な場所に書き留めてください。忘れた場合は、ボックスの RESET ボタンを 5 秒間押してください。","You're all set 🛡️":"準備完了 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"家じゅうのフィルタリングはすでに動いています — 進み具合はダッシュボードで見られます。","Queries today":"本日のクエリ","Blocked":"ブロック","Blocked share":"ブロック率","ads and trackers":"広告とトラッカー","lookups today":"本日の照会","Each bar is 10 minutes · busiest:":"棒 1 本が 10 分 · ピーク:","since midnight":"0 時から","waiting for traffic":"通信を待っています","Queries":"クエリ","Keep the box updated automatically":"ボックスを自動的に更新する","Security fixes and filtering improvements only — no personal data leaves the box.":"セキュリティ修正とフィルタリングの改善のみ — 個人データがボックスの外に出ることはありません。","Share anonymous diagnostic reports":"匿名の診断レポートを共有する","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"問題の修正に役立つエラーログとヘルスチェック。閲覧履歴、デバイス名、個人データは含まれません — 匿名化された技術情報のみを非公開で送信します。","Language":"言語","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"このページを開いたアドレスをボックスが認識できませんでした。http://filterbox.lan を開いて、もう一度お試しください。","Pause":"一時停止","This dashboard is private to your home. Enter the password you chose during setup.":"このダッシュボードはご家庭専用です。セットアップ時に設定したパスワードを入力してください。","FilterBox — Sign in":"FilterBox — サインイン"," queries · ":" クエリ · ","Wait a minute, then":"1 分待ってから"},"pt":{"FilterBox — Setup":"FilterBox — Configuração","Your filter box is online 🎉":"O teu FilterBox está online 🎉","Checking your setup…":"A verificar a configuração…","Protection…":"Proteção…","Internet…":"Internet…","Get started":"Começar","Choose your admin password":"Escolhe a palavra-passe de administrador","This protects your filter's settings page. Write it down somewhere safe.":"Isto protege a página de definições do teu filtro. Anota-a num local seguro.","Password (at least 8 characters)":"Palavra-passe (pelo menos 8 caracteres)","Repeat password":"Repetir palavra-passe","Save password":"Guardar palavra-passe","Internet connection":"Ligação à internet","Choose how this box reaches the internet.":"Escolhe como este equipamento chega à internet.","Ethernet":"Ethernet","Scan for Wi-Fi networks":"Procurar redes Wi-Fi","Wi-Fi password":"Palavra-passe Wi-Fi","Connect":"Ligar","Continue":"Continuar","All set! 🛡️":"Tudo pronto! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"A tua rede está agora protegida. Os anúncios e rastreadores são filtrados em todos os dispositivos que usam este equipamento.","Opening your dashboard…":"A abrir o teu painel…","Open dashboard":"Abrir painel","Setup already complete":"Configuração já concluída","This box has already been set up. Head to the dashboard to see how it's doing.":"Este equipamento já foi configurado. Vai ao painel para ver como está a correr.","· your data stays on this device":"· os teus dados ficam neste dispositivo","Bad response":"Resposta inválida","Protection: active":"Proteção: ativa","Protection: warming up":"Proteção: a iniciar","Internet: connected":"Internet: ligada","Internet: not yet":"Internet: ainda não","This box: ":"Este equipamento: ","Good news — filtering is already working.":"Boas notícias — a filtragem já está a funcionar.","Almost there — let’s finish the quick setup.":"Quase lá — vamos terminar a configuração rápida.","Ethernet: cable connected":"Ethernet: cabo ligado","Ethernet: no cable detected":"Ethernet: nenhum cabo detetado","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"O Wi-Fi está disponível neste equipamento — podes usá-lo ou manter o Ethernet.","This box filters through its network cable — nothing to configure here.":"Este equipamento filtra através do cabo de rede — não há nada a configurar aqui.","Password needs at least 8 characters.":"A palavra-passe precisa de pelo menos 8 caracteres.","The two passwords don’t match.":"As duas palavras-passe não coincidem.","Something went wrong.":"Algo correu mal.","Saving…":"A guardar…","Scanning…":"A procurar…","Scan again":"Procurar novamente","Password for “":"Palavra-passe de “","Connecting…":"A ligar…","Connected.":"Ligado.","Could not connect.":"Não foi possível ligar.","Not ready yet.":"Ainda não está pronto.","No networks found. Try again, or keep using Ethernet.":"Nenhuma rede encontrada. Tenta novamente ou continua com Ethernet.","Checking on your filter…":"A verificar o teu filtro…","Turn back on":"Voltar a ligar","blocked today":"bloqueados hoje","Last 7 days":"Últimos 7 dias","Top blocked today":"Mais bloqueados hoje","Warming up…":"A iniciar…","Nothing blocked yet — enjoy the quiet.":"Ainda nada bloqueado — aproveita a calma.","Pause filtering?":"Pausar a filtragem?","Filtering will pause for a short break.":"A filtragem vai ficar em pausa por um curto período.","Pause 30 minutes":"Pausar 30 minutos","Pause 1 hour":"Pausar 1 hora","Pause until I turn it back on":"Pausar até eu voltar a ligar","Cancel":"Cancelar","Enter your dashboard password":"Introduz a palavra-passe do painel","Password":"Palavra-passe","Settings":"Definições","Tap to pause filtering":"Toca para pausar a filtragem","Back in ":"Volta em ","Back in ~":"Volta em ~"," h ":" h "," min":" min","Could not reach the panel — reload in a moment.":"Não foi possível contactar o painel — recarrega daqui a pouco.","Too many requests — wait a minute.":"Demasiados pedidos — espera um minuto.","Something went wrong — try again.":"Algo correu mal — tenta novamente.","Paused until you turn it back on.":"Em pausa até voltares a ligar.","Paused for 30 minutes.":"Em pausa durante 30 minutos.","Paused for 1 hour.":"Em pausa durante 1 hora.","Protection is back on.":"A proteção está de novo ativa.","Paused until you turn it back on":"Em pausa até voltares a ligar","Protection: paused":"Proteção: em pausa","Protection: checking…":"Proteção: a verificar…","Protection: needs attention":"Proteção: precisa de atenção","Filter engine starting up — stats will appear shortly.":"O motor de filtragem está a iniciar — as estatísticas aparecem em breve.","Ad blocking seems off — try restarting the box, or contact support.":"O bloqueio de anúncios parece estar desligado — tenta reiniciar o equipamento ou contacta o suporte.","Working quietly in the background.":"A trabalhar discretamente em segundo plano.","Internet: not reaching the internet":"Internet: sem acesso à internet","Internet: checking…":"Internet: a verificar…","waiting for the filter engine…":"à espera do motor de filtragem…","% of all queries · ":"% de todos os pedidos · "," domains in your protection lists":" domínios nas tuas listas de proteção","Every bar is a slice of the week — taller means more ads blocked.":"Cada barra é uma fatia da semana — mais alta significa mais anúncios bloqueados.","The chart fills in as the week goes.":"O gráfico vai preenchendo ao longo da semana.","That password doesn't match — try again.":"Essa palavra-passe não corresponde — tenta novamente."," blocked":" bloqueados","FilterBox — Settings":"FilterBox — Definições","← Dashboard":"← Painel","Change password":"Alterar palavra-passe","This is the password for the dashboard and the advanced view.":"Esta é a palavra-passe do painel e da vista avançada.","Current password":"Palavra-passe atual","New password (at least 8 characters)":"Nova palavra-passe (pelo menos 8 caracteres)","Repeat new password":"Repetir nova palavra-passe","Password updated.":"Palavra-passe atualizada.","Save new password":"Guardar nova palavra-passe","Restart the box":"Reiniciar o equipamento","Takes about a minute. Filtering pauses briefly while it restarts.":"Demora cerca de um minuto. A filtragem pausa brevemente durante o reinício.","Restart now":"Reiniciar agora","Factory reset":"Reposição de fábrica","Reset this box…":"Repor este equipamento…","Type RESET to confirm":"Escreve RESET para confirmar","Dashboard password":"Palavra-passe do painel","Erase everything and reset":"Apagar tudo e repor","About":"Acerca","Panel version":"Versão do painel","Filter engine":"Motor de filtragem","Uptime":"Tempo ativo","Address":"Endereço","Working…":"A trabalhar…","Please wait.":"Aguarda, por favor.","Password must be at least 8 characters.":"A palavra-passe tem de ter pelo menos 8 caracteres.","The two new passwords don’t match.":"As duas novas palavras-passe não coincidem.","Restart now? Tap again to confirm":"Reiniciar agora? Toca novamente para confirmar","Restarting…":"A reiniciar…","Back online.":"De novo online.","This takes about a minute. Filtering pauses briefly while it restarts.":"Isto demora cerca de um minuto. A filtragem pausa brevemente durante o reinício.","Restarting the box":"A reiniciar o equipamento","Still working…":"Ainda a trabalhar…","Reloading…":"A recarregar…","Type RESET exactly to confirm.":"Escreve RESET exatamente para confirmar.","Resetting the box":"A repor o equipamento","Erasing settings and returning to setup mode — the box will restart.":"A apagar as definições e a voltar ao modo de configuração — o equipamento vai reiniciar.","Back to setup — reloading…":"De volta à configuração — a recarregar…"," d ":" d ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"O equipamento ainda não voltou. Verifica se está ligado à corrente e recarrega esta página.","Too many requests":"Demasiados pedidos","Wait a minute, then ":"Espera um minuto e ","reload the dashboard":"recarrega o painel","Nothing here":"Nada aqui","That page doesn't exist.":"Essa página não existe.","Back to FilterBox":"Voltar ao FilterBox","not found":"não encontrado","Too many attempts — wait a minute.":"Demasiadas tentativas — espera um minuto.","Session expired — enter the password again.":"Sessão expirada — introduz a palavra-passe novamente.","Pick 30 minutes, 1 hour, or until you turn it back on.":"Escolhe 30 minutos, 1 hora ou até voltares a ligar.","Setup is already complete.":"A configuração já está concluída.","That's not the current password — try again.":"Essa não é a palavra-passe atual — tenta novamente.","Password is too long (max 128 characters).":"A palavra-passe é demasiado longa (máx. 128 caracteres).","Couldn't start the restart — check that the box is powered, then try again.":"Não foi possível iniciar o reinício — verifica se o equipamento está ligado à corrente e tenta novamente.","Could not set the password (service not ready?). Try again in a moment.":"Não foi possível definir a palavra-passe (serviço não pronto?). Tenta novamente daqui a pouco.","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"Nenhum adaptador Wi-Fi detetado neste equipamento — usa Ethernet. Está tudo pronto.","Pick a network and enter its password (at least 8 chars).":"Escolhe uma rede e introduz a palavra-passe (pelo menos 8 caracteres).","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"Sem adaptador Wi-Fi neste equipamento — o Ethernet é o caminho. Nada a fazer aqui.","Wi-Fi tools are not available on this box.":"As ferramentas Wi-Fi não estão disponíveis neste equipamento.","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"Definições Wi-Fi guardadas, mas ainda sem endereço — dá-lhe um minuto e recarrega esta página.","Set an admin password first.":"Define primeiro uma palavra-passe de administrador.","Connected to ":"Ligado a ","Could not update Wi-Fi config: ":"Não foi possível atualizar a configuração Wi-Fi: ","queries today":"pedidos hoje"," blocked (":" bloqueados (","answered from cache: ":"respondidos a partir da cache: "," · forwarded: ":" · reencaminhados: ","Today":"Hoje","Each bar is 10 minutes — the purple part was blocked.":"Cada barra são 10 minutos — a parte roxa foi bloqueada.","The chart fills in as the day goes.":"O gráfico vai preenchendo ao longo do dia.","Most visited today":"Mais visitados hoje","Busiest devices":"Dispositivos mais ativos","Where answers came from":"De onde vieram as respostas","Traffic mix":"Mistura de tráfego","Advanced view":"Vista avançada","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"Para utilizadores avançados — o painel técnico completo: registo de pedidos, gestão de listas de bloqueio e definições detalhadas.","Open advanced view":"Abrir vista avançada","Uses the same password as this page. Changes there affect filtering for the whole home.":"Usa a mesma palavra-passe desta página. As alterações aí afetam a filtragem de toda a casa.","Whole home":"Toda a casa","Covered — ":"Cobertos — "," devices seen on your network":" dispositivos vistos na tua rede","Protection is paused — filtering is off.":"A proteção está em pausa — a filtragem está desligada.","Coverage paused — finishing network release…":"Cobertura em pausa — a concluir a libertação da rede…","Protection starts as soon as setup is finished.":"A proteção começa assim que a configuração terminar.","Coverage is on — devices will appear as they browse.":"A cobertura está ligada — os dispositivos aparecem à medida que navegam.","Coverage starting…":"A cobertura está a iniciar…","Coverage paused — the internet is open.":"Cobertura em pausa — a internet está aberta.","Coverage is off.":"A cobertura está desligada.","Coverage has not started — check the box.":"A cobertura não começou — verifica o equipamento.","Coverage status unavailable — check the box.":"Estado da cobertura indisponível — verifica o equipamento.","Protection: starts after setup":"Proteção: começa após a configuração","Finish setup to switch protection on for the whole home.":"Termina a configuração para ligar a proteção a toda a casa.","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"Configuração concluída. A proteção está a ligar-se para toda a casa — o painel mostra o progresso.","Coverage status is out of date — check the box.":"O estado da cobertura está desatualizado — verifica o equipamento.","Coverage unavailable on this network — contact support.":"Cobertura indisponível nesta rede — contacta o suporte.","Network release still finishing — check the box.":"A libertação da rede ainda está a terminar — verifica o equipamento.","Coverage could not start — restart the box or contact support.":"A cobertura não pôde começar — reinicia o equipamento ou contacta o suporte.","Internal error — try again.":"Erro interno — tenta novamente.","That network name is not supported — choose another network.":"Esse nome de rede não é suportado — escolhe outra rede.","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"Apaga a palavra-passe do painel, as definições e as estatísticas. A filtragem continua a funcionar e as definições Wi-Fi mantêm-se. Isto não pode ser anulado — se alguma vez esqueceres a palavra-passe, mantém o botão RESET do equipamento premido durante 5 segundos.","Protection lists need attention — the box is repairing them.":"As listas de proteção precisam de atenção — o equipamento está a repará-las.","Filtering is on — coverage status unavailable.":"A filtragem está ligada — estado da cobertura indisponível.","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"As tuas listas de proteção ainda estão a ser preparadas — mantém o equipamento ligado à corrente e à rede e tenta novamente dentro de alguns minutos.","Filtering is already running for your whole home.":"A filtragem já está a funcionar para toda a casa.","Protection is starting — no action needed.":"A proteção está a começar — não é preciso fazer nada.","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"O painel e as estatísticas são opcionais. Define uma palavra-passe para os usar — caso contrário, fecha esta página e aproveita a calma.","Set up the dashboard":"Configurar o painel","Choose your dashboard password":"Escolhe a palavra-passe do painel","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"Isto protege o painel e a vista avançada. Anota-a num local seguro. Se a esqueceres, mantém o botão RESET do equipamento premido durante 5 segundos.","You're all set 🛡️":"Está tudo pronto 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"A filtragem já está a funcionar para toda a casa — o painel mostra como está a correr.","Queries today":"Pedidos hoje","Blocked":"Bloqueados","Blocked share":"Percentagem bloqueada","ads and trackers":"anúncios e rastreadores","lookups today":"consultas hoje","Each bar is 10 minutes · busiest:":"Cada barra são 10 minutos · mais movimentados:","since midnight":"desde a meia-noite","waiting for traffic":"à espera de tráfego","Queries":"Pedidos","Keep the box updated automatically":"Manter o equipamento atualizado automaticamente","Security fixes and filtering improvements only — no personal data leaves the box.":"Apenas correções de segurança e melhorias de filtragem — nenhum dado pessoal sai do equipamento.","Share anonymous diagnostic reports":"Partilhar relatórios de diagnóstico anónimos","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"Registos de erros e verificações de estado que nos ajudam a corrigir problemas. Sem histórico de navegação, nomes de dispositivos ou dados pessoais — apenas detalhes técnicos anonimizados, enviados em privado.","Language":"Idioma","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"Este equipamento não reconheceu o endereço a partir do qual esta página foi aberta. Abra http://filterbox.lan e tente novamente.","Pause":"Pausar","This dashboard is private to your home. Enter the password you chose during setup.":"Este painel é privado para a sua casa. Introduza a palavra-passe que escolheu durante a configuração.","FilterBox — Sign in":"FilterBox — Iniciar sessão"," queries · ":" consultas · ","Wait a minute, then":"Aguarde um minuto e "},"tr":{"FilterBox — Setup":"FilterBox — Kurulum","Your filter box is online 🎉":"Filtre kutunuz çevrimiçi 🎉","Checking your setup…":"Kurulumunuz kontrol ediliyor…","Protection…":"Koruma…","Internet…":"İnternet…","Get started":"Başlayın","Choose your admin password":"Yönetici parolanızı seçin","This protects your filter's settings page. Write it down somewhere safe.":"Bu, filtrenizin ayarlar sayfasını korur. Güvenli bir yere yazın.","Password (at least 8 characters)":"Parola (en az 8 karakter)","Repeat password":"Parolayı yineleyin","Save password":"Parolayı kaydet","Internet connection":"İnternet bağlantısı","Choose how this box reaches the internet.":"Bu kutunun internete nasıl bağlanacağını seçin.","Ethernet":"Ethernet","Scan for Wi-Fi networks":"Wi-Fi ağlarını tara","Wi-Fi password":"Wi-Fi parolası","Connect":"Bağlan","Continue":"Devam","All set! 🛡️":"Hazır! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"Ağınız artık korunuyor. Bu kutuyu kullanan her cihaz için reklamlar ve izleyiciler filtreleniyor.","Opening your dashboard…":"Paneliniz açılıyor…","Open dashboard":"Paneli aç","Setup already complete":"Kurulum zaten tamamlandı","This box has already been set up. Head to the dashboard to see how it's doing.":"Bu kutu zaten kurulmuş. Nasıl çalıştığını görmek için panele gidin.","· your data stays on this device":"· verileriniz bu cihazda kalır","Bad response":"Geçersiz yanıt","Protection: active":"Koruma: etkin","Protection: warming up":"Koruma: ısınıyor","Internet: connected":"İnternet: bağlı","Internet: not yet":"İnternet: henüz yok","This box: ":"Bu kutu: ","Good news — filtering is already working.":"İyi haber — filtreleme zaten çalışıyor.","Almost there — let’s finish the quick setup.":"Neredeyse bitti — hızlı kurulumu tamamlayalım.","Ethernet: cable connected":"Ethernet: kablo bağlı","Ethernet: no cable detected":"Ethernet: kablo bulunamadı","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"Bu kutuda Wi-Fi var — kullanabilir ya da Ethernet'te kalabilirsiniz.","This box filters through its network cable — nothing to configure here.":"Bu kutu ağ kablosu üzerinden filtreler — burada yapılandırılacak bir şey yok.","Password needs at least 8 characters.":"Parola en az 8 karakter olmalı.","The two passwords don’t match.":"İki parola eşleşmiyor.","Something went wrong.":"Bir şeyler ters gitti.","Saving…":"Kaydediliyor…","Scanning…":"Taranıyor…","Scan again":"Yeniden tara","Password for “":"Şu ağın parolası: “","Connecting…":"Bağlanıyor…","Connected.":"Bağlandı.","Could not connect.":"Bağlanılamadı.","Not ready yet.":"Henüz hazır değil.","No networks found. Try again, or keep using Ethernet.":"Ağ bulunamadı. Tekrar deneyin veya Ethernet kullanmaya devam edin.","Checking on your filter…":"Filtreniz kontrol ediliyor…","Turn back on":"Yeniden aç","blocked today":"bugün engellendi","Last 7 days":"Son 7 gün","Top blocked today":"Bugün en çok engellenenler","Warming up…":"Isınıyor…","Nothing blocked yet — enjoy the quiet.":"Henüz hiçbir şey engellenmedi — sessizliğin tadını çıkarın.","Pause filtering?":"Filtreleme duraklatılsın mı?","Filtering will pause for a short break.":"Filtreleme kısa bir ara için duracak.","Pause 30 minutes":"30 dakika duraklat","Pause 1 hour":"1 saat duraklat","Pause until I turn it back on":"Yeniden açana kadar duraklat","Cancel":"İptal","Enter your dashboard password":"Panel parolanızı girin","Password":"Parola","Settings":"Ayarlar","Tap to pause filtering":"Filtrelemeyi duraklatmak için dokunun","Back in ":"Geri dönüş: ","Back in ~":"Geri dönüş ~"," h ":" sa "," min":" dk","Could not reach the panel — reload in a moment.":"Panele ulaşılamadı — birazdan sayfayı yenileyin.","Too many requests — wait a minute.":"Çok fazla istek — bir dakika bekleyin.","Something went wrong — try again.":"Bir şeyler ters gitti — tekrar deneyin.","Paused until you turn it back on.":"Yeniden açana kadar duraklatıldı.","Paused for 30 minutes.":"30 dakika duraklatıldı.","Paused for 1 hour.":"1 saat duraklatıldı.","Protection is back on.":"Koruma yeniden açık.","Paused until you turn it back on":"Yeniden açana kadar duraklatıldı","Protection: paused":"Koruma: duraklatıldı","Protection: checking…":"Koruma: kontrol ediliyor…","Protection: needs attention":"Koruma: dikkat gerekiyor","Filter engine starting up — stats will appear shortly.":"Filtre motoru başlıyor — istatistikler birazdan görünecek.","Ad blocking seems off — try restarting the box, or contact support.":"Reklam engelleme kapalı görünüyor — kutuyu yeniden başlatmayı deneyin veya destekle iletişime geçin.","Working quietly in the background.":"Arka planda sessizce çalışıyor.","Internet: not reaching the internet":"İnternet: internete ulaşılamıyor","Internet: checking…":"İnternet: kontrol ediliyor…","waiting for the filter engine…":"filtre motoru bekleniyor…","% of all queries · ":"tüm sorguların %'si · "," domains in your protection lists":" alan adı koruma listelerinizde","Every bar is a slice of the week — taller means more ads blocked.":"Her çubuk haftanın bir dilimi — daha yüksek olması daha çok reklam engellendiği anlamına gelir.","The chart fills in as the week goes.":"Grafik hafta ilerledikçe doluyor.","That password doesn't match — try again.":"Bu parola eşleşmiyor — tekrar deneyin."," blocked":" engellendi","FilterBox — Settings":"FilterBox — Ayarlar","← Dashboard":"← Panel","Change password":"Parolayı değiştir","This is the password for the dashboard and the advanced view.":"Bu, panel ve gelişmiş görünüm için geçerli paroladır.","Current password":"Mevcut parola","New password (at least 8 characters)":"Yeni parola (en az 8 karakter)","Repeat new password":"Yeni parolayı yineleyin","Password updated.":"Parola güncellendi.","Save new password":"Yeni parolayı kaydet","Restart the box":"Kutuyu yeniden başlat","Takes about a minute. Filtering pauses briefly while it restarts.":"Yaklaşık bir dakika sürer. Yeniden başlarken filtreleme kısa süreliğine durur.","Restart now":"Şimdi yeniden başlat","Factory reset":"Fabrika ayarlarına dönüş","Reset this box…":"Bu kutuyu sıfırla…","Type RESET to confirm":"Onaylamak için RESET yazın","Dashboard password":"Panel parolası","Erase everything and reset":"Her şeyi sil ve sıfırla","About":"Hakkında","Panel version":"Panel sürümü","Filter engine":"Filtre motoru","Uptime":"Çalışma süresi","Address":"Adres","Working…":"Çalışıyor…","Please wait.":"Lütfen bekleyin.","Password must be at least 8 characters.":"Parola en az 8 karakter olmalı.","The two new passwords don’t match.":"İki yeni parola eşleşmiyor.","Restart now? Tap again to confirm":"Şimdi yeniden başlatılsın mı? Onaylamak için tekrar dokunun","Restarting…":"Yeniden başlatılıyor…","Back online.":"Yeniden çevrimiçi.","This takes about a minute. Filtering pauses briefly while it restarts.":"Yaklaşık bir dakika sürer. Yeniden başlarken filtreleme kısa süreliğine durur.","Restarting the box":"Kutu yeniden başlatılıyor","Still working…":"Hâlâ çalışıyor…","Reloading…":"Yeniden yükleniyor…","Type RESET exactly to confirm.":"Onaylamak için tam olarak RESET yazın.","Resetting the box":"Kutu sıfırlanıyor","Erasing settings and returning to setup mode — the box will restart.":"Ayarlar siliniyor ve kurulum moduna dönülüyor — kutu yeniden başlayacak.","Back to setup — reloading…":"Kuruluma dönüldü — yeniden yükleniyor…"," d ":" g ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"Kutu henüz geri dönmedi. Açık olduğunu kontrol edip bu sayfayı yenileyin.","Too many requests":"Çok fazla istek","Wait a minute, then ":"Bir dakika bekleyin, sonra ","reload the dashboard":"paneli yenileyin","Nothing here":"Burada bir şey yok","That page doesn't exist.":"Bu sayfa mevcut değil.","Back to FilterBox":"FilterBox'a dön","not found":"bulunamadı","Too many attempts — wait a minute.":"Çok fazla deneme — bir dakika bekleyin.","Session expired — enter the password again.":"Oturum süresi doldu — parolayı yeniden girin.","Pick 30 minutes, 1 hour, or until you turn it back on.":"30 dakika, 1 saat veya yeniden açana kadar seçin.","Setup is already complete.":"Kurulum zaten tamamlandı.","That's not the current password — try again.":"Bu mevcut parola değil — tekrar deneyin.","Password is too long (max 128 characters).":"Parola çok uzun (en fazla 128 karakter).","Couldn't start the restart — check that the box is powered, then try again.":"Yeniden başlatma başlatılamadı — kutunun açık olduğunu kontrol edip tekrar deneyin.","Could not set the password (service not ready?). Try again in a moment.":"Parola ayarlanamadı (servis hazır değil mi?). Birazdan tekrar deneyin.","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"Bu kutuda Wi-Fi adaptörü bulunamadı — Ethernet kullanıyor. Her şey hazır.","Pick a network and enter its password (at least 8 chars).":"Bir ağ seçin ve parolasını girin (en az 8 karakter).","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"Bu kutuda Wi-Fi adaptörü yok — yol Ethernet. Burada yapılacak bir şey yok.","Wi-Fi tools are not available on this box.":"Bu kutuda Wi-Fi araçları kullanılamıyor.","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"Wi-Fi ayarları kaydedildi ama henüz adres yok — bir dakika bekleyip bu sayfayı yenileyin.","Set an admin password first.":"Önce bir yönetici parolası belirleyin.","Connected to ":"Bağlanıldı: ","Could not update Wi-Fi config: ":"Wi-Fi yapılandırması güncellenemedi: ","queries today":"bugünkü sorgu"," blocked (":" engellendi (","answered from cache: ":"önbellekten yanıtlanan: "," · forwarded: ":" · iletilen: ","Today":"Bugün","Each bar is 10 minutes — the purple part was blocked.":"Her çubuk 10 dakika — mor kısım engellendi.","The chart fills in as the day goes.":"Grafik gün ilerledikçe doluyor.","Most visited today":"Bugün en çok ziyaret edilenler","Busiest devices":"En yoğun cihazlar","Where answers came from":"Yanıtların kaynağı","Traffic mix":"Trafik dağılımı","Advanced view":"Gelişmiş görünüm","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"İleri düzey kullanıcılar için — tam teknik panel: sorgu günlüğü, engel listesi yönetimi ve ayrıntılı ayarlar.","Open advanced view":"Gelişmiş görünümü aç","Uses the same password as this page. Changes there affect filtering for the whole home.":"Bu sayfayla aynı parolayı kullanır. Oradaki değişiklikler tüm evin filtrelemesini etkiler.","Whole home":"Tüm ev","Covered — ":"Kapsam dahilinde — "," devices seen on your network":" cihaz ağınızda görüldü","Protection is paused — filtering is off.":"Koruma duraklatıldı — filtreleme kapalı.","Coverage paused — finishing network release…":"Kapsam duraklatıldı — ağ serbest bırakma tamamlanıyor…","Protection starts as soon as setup is finished.":"Koruma, kurulum biter bitmez başlar.","Coverage is on — devices will appear as they browse.":"Kapsam açık — cihazlar gezdikçe görünecek.","Coverage starting…":"Kapsam başlıyor…","Coverage paused — the internet is open.":"Kapsam duraklatıldı — internet açık.","Coverage is off.":"Kapsam kapalı.","Coverage has not started — check the box.":"Kapsam başlamadı — kutuyu kontrol edin.","Coverage status unavailable — check the box.":"Kapsam durumu kullanılamıyor — kutuyu kontrol edin.","Protection: starts after setup":"Koruma: kurulumdan sonra başlar","Finish setup to switch protection on for the whole home.":"Tüm ev için korumayı açmak üzere kurulumu tamamlayın.","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"Kurulum tamamlandı. Tüm eviniz için koruma açılıyor — panel ilerlemeyi gösterir.","Coverage status is out of date — check the box.":"Kapsam durumu güncel değil — kutuyu kontrol edin.","Coverage unavailable on this network — contact support.":"Bu ağda kapsam kullanılamıyor — destekle iletişime geçin.","Network release still finishing — check the box.":"Ağ serbest bırakma hâlâ tamamlanıyor — kutuyu kontrol edin.","Coverage could not start — restart the box or contact support.":"Kapsam başlatılamadı — kutuyu yeniden başlatın veya destekle iletişime geçin.","Internal error — try again.":"İç hata — tekrar deneyin.","That network name is not supported — choose another network.":"Bu ağ adı desteklenmiyor — başka bir ağ seçin.","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"Panel parolanızı, ayarlarınızı ve istatistiklerinizi siler. Filtreleme çalışmaya devam eder, Wi-Fi ayarları korunur. Bu işlem geri alınamaz — parolayı unutursanız kutudaki RESET düğmesini 5 saniye basılı tutun.","Protection lists need attention — the box is repairing them.":"Koruma listeleri dikkat gerektiriyor — kutu onları onarıyor.","Filtering is on — coverage status unavailable.":"Filtreleme açık — kapsam durumu kullanılamıyor.","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"Koruma listeleriniz hâlâ hazırlanıyor — kutuyu açık ve bağlı tutun, birkaç dakika sonra tekrar deneyin.","Filtering is already running for your whole home.":"Filtreleme tüm eviniz için zaten çalışıyor.","Protection is starting — no action needed.":"Koruma başlıyor — bir şey yapmanız gerekmiyor.","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"Panel ve istatistikler isteğe bağlıdır. Kullanmak için bir parola belirleyin — yoksa bu sayfayı kapatıp sessizliğin tadını çıkarın.","Set up the dashboard":"Paneli kur","Choose your dashboard password":"Panel parolanızı seçin","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"Bu, paneli ve gelişmiş görünümü korur. Güvenli bir yere yazın. Unutursanız kutudaki RESET düğmesini 5 saniye basılı tutun.","You're all set 🛡️":"Her şey hazır 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"Filtreleme tüm eviniz için zaten çalışıyor — panel nasıl gittiğini gösterir.","Queries today":"Bugünkü sorgular","Blocked":"Engellenen","Blocked share":"Engellenen oranı","ads and trackers":"reklamlar ve izleyiciler","lookups today":"bugünkü arama","Each bar is 10 minutes · busiest:":"Her çubuk 10 dakika · en yoğun:","since midnight":"gece yarısından beri","waiting for traffic":"trafik bekleniyor","Queries":"Sorgular","Keep the box updated automatically":"Kutuyu otomatik olarak güncel tut","Security fixes and filtering improvements only — no personal data leaves the box.":"Yalnızca güvenlik düzeltmeleri ve filtreleme iyileştirmeleri — hiçbir kişisel veri kutudan çıkmaz.","Share anonymous diagnostic reports":"Anonim tanılama raporlarını paylaş","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"Sorunları düzeltmemize yardımcı olan hata kayıtları ve sağlık kontrolleri. Tarama geçmişi, cihaz adları veya kişisel veriler yok — yalnızca anonimleştirilmiş teknik ayrıntılar gizlice bize gönderilir.","Language":"Dil","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"Bu kutu, bu sayfanın açıldığı adresi tanımadı. http://filterbox.lan adresini açıp tekrar deneyin.","Pause":"Duraklat","This dashboard is private to your home. Enter the password you chose during setup.":"Bu panel evinize özeldir. Kurulum sırasında belirlediğiniz parolayı girin.","FilterBox — Sign in":"FilterBox — Giriş"," queries · ":" sorgu · ","Wait a minute, then":"Bir dakika bekleyin, sonra "},"vi":{"FilterBox — Setup":"FilterBox — Thiết lập","Your filter box is online 🎉":"Hộp lọc của bạn đã trực tuyến 🎉","Checking your setup…":"Đang kiểm tra thiết lập…","Protection…":"Bảo vệ…","Internet…":"Internet…","Get started":"Bắt đầu","Choose your admin password":"Chọn mật khẩu quản trị","This protects your filter's settings page. Write it down somewhere safe.":"Mật khẩu này bảo vệ trang cài đặt của hộp lọc. Hãy ghi lại và cất ở nơi an toàn.","Password (at least 8 characters)":"Mật khẩu (ít nhất 8 ký tự)","Repeat password":"Nhập lại mật khẩu","Save password":"Lưu mật khẩu","Internet connection":"Kết nối Internet","Choose how this box reaches the internet.":"Chọn cách hộp lọc kết nối Internet.","Ethernet":"Ethernet","Scan for Wi-Fi networks":"Quét mạng Wi-Fi","Wi-Fi password":"Mật khẩu Wi-Fi","Connect":"Kết nối","Continue":"Tiếp tục","All set! 🛡️":"Xong rồi! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"Mạng nhà bạn giờ đã được bảo vệ. Quảng cáo và trình theo dõi đang bị lọc cho mọi thiết bị dùng hộp lọc này.","Opening your dashboard…":"Đang mở bảng điều khiển…","Open dashboard":"Mở bảng điều khiển","Setup already complete":"Thiết lập đã hoàn tất","This box has already been set up. Head to the dashboard to see how it's doing.":"Hộp lọc này đã được thiết lập. Vào bảng điều khiển để xem tình hình.","· your data stays on this device":"· dữ liệu của bạn ở lại trên thiết bị này","Bad response":"Phản hồi lỗi","Protection: active":"Bảo vệ: đang bật","Protection: warming up":"Bảo vệ: đang khởi động","Internet: connected":"Internet: đã kết nối","Internet: not yet":"Internet: chưa có","This box: ":"Hộp lọc: ","Good news — filtering is already working.":"Tin tốt — việc lọc đã hoạt động rồi.","Almost there — let’s finish the quick setup.":"Sắp xong rồi — hãy hoàn tất phần thiết lập nhanh.","Ethernet: cable connected":"Ethernet: đã kết nối cáp","Ethernet: no cable detected":"Ethernet: chưa thấy cáp","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"Hộp lọc này có Wi-Fi — bạn có thể dùng Wi-Fi hoặc giữ Ethernet.","This box filters through its network cable — nothing to configure here.":"Hộp lọc hoạt động qua dây mạng — không cần cấu hình gì ở đây.","Password needs at least 8 characters.":"Mật khẩu cần ít nhất 8 ký tự.","The two passwords don’t match.":"Hai mật khẩu không khớp.","Something went wrong.":"Đã có lỗi xảy ra.","Saving…":"Đang lưu…","Scanning…":"Đang quét…","Scan again":"Quét lại","Password for “":"Mật khẩu của “","Connecting…":"Đang kết nối…","Connected.":"Đã kết nối.","Could not connect.":"Không kết nối được.","Not ready yet.":"Chưa sẵn sàng.","No networks found. Try again, or keep using Ethernet.":"Không tìm thấy mạng nào. Thử lại, hoặc tiếp tục dùng Ethernet.","Checking on your filter…":"Đang kiểm tra hộp lọc…","Turn back on":"Bật lại","blocked today":"bị chặn hôm nay","Last 7 days":"7 ngày qua","Top blocked today":"Bị chặn nhiều nhất hôm nay","Warming up…":"Đang khởi động…","Nothing blocked yet — enjoy the quiet.":"Chưa chặn gì — cứ tận hưởng sự yên tĩnh.","Pause filtering?":"Tạm dừng lọc?","Filtering will pause for a short break.":"Việc lọc sẽ tạm dừng trong một lát.","Pause 30 minutes":"Tạm dừng 30 phút","Pause 1 hour":"Tạm dừng 1 giờ","Pause until I turn it back on":"Tạm dừng đến khi tôi bật lại","Cancel":"Huỷ","Enter your dashboard password":"Nhập mật khẩu bảng điều khiển","Password":"Mật khẩu","Settings":"Cài đặt","Tap to pause filtering":"Chạm để tạm dừng lọc","Back in ":"Còn ","Back in ~":"Còn khoảng "," h ":" giờ "," min":" phút","Could not reach the panel — reload in a moment.":"Không truy cập được bảng điều khiển — hãy tải lại sau giây lát.","Too many requests — wait a minute.":"Quá nhiều yêu cầu — chờ một phút.","Something went wrong — try again.":"Đã có lỗi — thử lại nhé.","Paused until you turn it back on.":"Đã tạm dừng đến khi bạn bật lại.","Paused for 30 minutes.":"Đã tạm dừng 30 phút.","Paused for 1 hour.":"Đã tạm dừng 1 giờ.","Protection is back on.":"Bảo vệ đã bật lại.","Paused until you turn it back on":"Tạm dừng đến khi bạn bật lại","Protection: paused":"Bảo vệ: tạm dừng","Protection: checking…":"Bảo vệ: đang kiểm tra…","Protection: needs attention":"Bảo vệ: cần chú ý","Filter engine starting up — stats will appear shortly.":"Bộ lọc đang khởi động — số liệu sẽ hiện ra ngay.","Ad blocking seems off — try restarting the box, or contact support.":"Chặn quảng cáo có vẻ đang tắt — thử khởi động lại hộp lọc hoặc liên hệ hỗ trợ.","Working quietly in the background.":"Đang âm thầm hoạt động ở phía sau.","Internet: not reaching the internet":"Internet: không vào được mạng","Internet: checking…":"Internet: đang kiểm tra…","waiting for the filter engine…":"đang chờ bộ lọc…","% of all queries · ":"% tổng số truy vấn · "," domains in your protection lists":" tên miền trong danh sách bảo vệ","Every bar is a slice of the week — taller means more ads blocked.":"Mỗi cột là một phần của tuần — cột càng cao càng nhiều quảng cáo bị chặn.","The chart fills in as the week goes.":"Biểu đồ sẽ đầy dần khi tuần trôi qua.","That password doesn't match — try again.":"Mật khẩu không đúng — thử lại nhé."," blocked":" bị chặn","FilterBox — Settings":"FilterBox — Cài đặt","← Dashboard":"← Bảng điều khiển","Change password":"Đổi mật khẩu","This is the password for the dashboard and the advanced view.":"Đây là mật khẩu cho bảng điều khiển và chế độ nâng cao.","Current password":"Mật khẩu hiện tại","New password (at least 8 characters)":"Mật khẩu mới (ít nhất 8 ký tự)","Repeat new password":"Nhập lại mật khẩu mới","Password updated.":"Đã cập nhật mật khẩu.","Save new password":"Lưu mật khẩu mới","Restart the box":"Khởi động lại hộp lọc","Takes about a minute. Filtering pauses briefly while it restarts.":"Mất khoảng một phút. Việc lọc tạm ngừng trong lúc khởi động lại.","Restart now":"Khởi động lại ngay","Factory reset":"Đặt lại về mặc định","Reset this box…":"Đặt lại hộp lọc…","Type RESET to confirm":"Nhập RESET để xác nhận","Dashboard password":"Mật khẩu bảng điều khiển","Erase everything and reset":"Xoá tất cả và đặt lại","About":"Giới thiệu","Panel version":"Phiên bản bảng điều khiển","Filter engine":"Bộ lọc","Uptime":"Thời gian hoạt động","Address":"Địa chỉ","Working…":"Đang xử lý…","Please wait.":"Vui lòng chờ.","Password must be at least 8 characters.":"Mật khẩu phải có ít nhất 8 ký tự.","The two new passwords don’t match.":"Hai mật khẩu mới không khớp.","Restart now? Tap again to confirm":"Khởi động lại ngay? Chạm lần nữa để xác nhận","Restarting…":"Đang khởi động lại…","Back online.":"Đã hoạt động lại.","This takes about a minute. Filtering pauses briefly while it restarts.":"Việc này mất khoảng một phút. Việc lọc tạm ngừng trong lúc khởi động lại.","Restarting the box":"Đang khởi động lại hộp lọc","Still working…":"Vẫn đang xử lý…","Reloading…":"Đang tải lại…","Type RESET exactly to confirm.":"Nhập chính xác RESET để xác nhận.","Resetting the box":"Đang đặt lại hộp lọc","Erasing settings and returning to setup mode — the box will restart.":"Xoá cài đặt và quay về chế độ thiết lập — hộp lọc sẽ khởi động lại.","Back to setup — reloading…":"Quay lại thiết lập — đang tải lại…"," d ":" ngày ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"Hộp lọc chưa hoạt động lại. Kiểm tra xem đã cắm điện chưa, rồi tải lại trang này.","Too many requests":"Quá nhiều yêu cầu","Wait a minute, then ":"Chờ một phút, rồi ","reload the dashboard":"tải lại bảng điều khiển","Nothing here":"Không có gì ở đây","That page doesn't exist.":"Trang này không tồn tại.","Back to FilterBox":"Về FilterBox","not found":"không tìm thấy","Too many attempts — wait a minute.":"Quá nhiều lần thử — chờ một phút.","Session expired — enter the password again.":"Phiên đã hết hạn — nhập lại mật khẩu.","Pick 30 minutes, 1 hour, or until you turn it back on.":"Chọn 30 phút, 1 giờ, hoặc đến khi bạn bật lại.","Setup is already complete.":"Thiết lập đã hoàn tất.","That's not the current password — try again.":"Đó không phải mật khẩu hiện tại — thử lại nhé.","Password is too long (max 128 characters).":"Mật khẩu quá dài (tối đa 128 ký tự).","Couldn't start the restart — check that the box is powered, then try again.":"Không khởi động lại được — kiểm tra nguồn điện của hộp lọc rồi thử lại.","Could not set the password (service not ready?). Try again in a moment.":"Không đặt được mật khẩu (dịch vụ chưa sẵn sàng?). Thử lại sau giây lát.","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"Không thấy bộ thu Wi-Fi trên hộp lọc này — hộp lọc dùng Ethernet. Bạn đã sẵn sàng.","Pick a network and enter its password (at least 8 chars).":"Chọn một mạng và nhập mật khẩu của mạng đó (ít nhất 8 ký tự).","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"Hộp lọc này không có Wi-Fi — dùng Ethernet là được. Không cần làm gì ở đây.","Wi-Fi tools are not available on this box.":"Hộp lọc này không có công cụ Wi-Fi.","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"Đã lưu cài đặt Wi-Fi, nhưng chưa có địa chỉ — chờ một phút rồi tải lại trang này.","Set an admin password first.":"Hãy đặt mật khẩu quản trị trước.","Connected to ":"Đã kết nối với ","Could not update Wi-Fi config: ":"Không cập nhật được cấu hình Wi-Fi: ","queries today":"truy vấn hôm nay"," blocked (":" bị chặn (","answered from cache: ":"trả lời từ bộ nhớ đệm: "," · forwarded: ":" · chuyển tiếp: ","Today":"Hôm nay","Each bar is 10 minutes — the purple part was blocked.":"Mỗi cột là 10 phút — phần màu tím là bị chặn.","The chart fills in as the day goes.":"Biểu đồ sẽ đầy dần trong ngày.","Most visited today":"Truy cập nhiều nhất hôm nay","Busiest devices":"Thiết bị dùng nhiều nhất","Where answers came from":"Nguồn trả lời","Traffic mix":"Cơ cấu lưu lượng","Advanced view":"Chế độ nâng cao","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"Dành cho người dùng nâng cao — bảng điều khiển kỹ thuật đầy đủ: nhật ký truy vấn, quản lý danh sách chặn và cài đặt chi tiết.","Open advanced view":"Mở chế độ nâng cao","Uses the same password as this page. Changes there affect filtering for the whole home.":"Dùng chung mật khẩu với trang này. Thay đổi ở đó ảnh hưởng đến việc lọc của cả nhà.","Whole home":"Cả nhà","Covered — ":"Đã bảo vệ — "," devices seen on your network":" thiết bị thấy trên mạng của bạn","Protection is paused — filtering is off.":"Bảo vệ đang tạm dừng — việc lọc đang tắt.","Coverage paused — finishing network release…":"Tạm dừng bảo vệ — đang hoàn tất việc trả mạng…","Protection starts as soon as setup is finished.":"Việc bảo vệ bắt đầu ngay khi thiết lập xong.","Coverage is on — devices will appear as they browse.":"Đang bảo vệ — thiết bị sẽ hiện ra khi dùng mạng.","Coverage starting…":"Đang bắt đầu bảo vệ…","Coverage paused — the internet is open.":"Tạm dừng bảo vệ — mạng đang mở.","Coverage is off.":"Chưa bảo vệ.","Coverage has not started — check the box.":"Chưa bắt đầu bảo vệ — kiểm tra hộp lọc.","Coverage status unavailable — check the box.":"Không xem được trạng thái bảo vệ — kiểm tra hộp lọc.","Protection: starts after setup":"Bảo vệ: bắt đầu sau khi thiết lập","Finish setup to switch protection on for the whole home.":"Hoàn tất thiết lập để bật bảo vệ cho cả nhà.","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"Thiết lập xong. Bảo vệ đang được bật cho cả nhà — bảng điều khiển hiển thị tiến trình.","Coverage status is out of date — check the box.":"Trạng thái bảo vệ đã cũ — kiểm tra hộp lọc.","Coverage unavailable on this network — contact support.":"Mạng này không hỗ trợ bảo vệ — liên hệ hỗ trợ.","Network release still finishing — check the box.":"Việc trả mạng vẫn đang hoàn tất — kiểm tra hộp lọc.","Coverage could not start — restart the box or contact support.":"Không bắt đầu được bảo vệ — khởi động lại hộp lọc hoặc liên hệ hỗ trợ.","Internal error — try again.":"Lỗi hệ thống — thử lại nhé.","That network name is not supported — choose another network.":"Tên mạng này không được hỗ trợ — chọn mạng khác.","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"Xoá mật khẩu bảng điều khiển, cài đặt và số liệu. Việc lọc vẫn chạy, cài đặt Wi-Fi được giữ lại. Không thể hoàn tác — nếu quên mật khẩu, hãy giữ nút RESET trên hộp lọc 5 giây.","Protection lists need attention — the box is repairing them.":"Danh sách bảo vệ cần chú ý — hộp lọc đang sửa lại.","Filtering is on — coverage status unavailable.":"Đang lọc — không xem được trạng thái bảo vệ.","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"Danh sách bảo vệ vẫn đang được chuẩn bị — giữ hộp lọc cắm điện và kết nối, rồi thử lại sau vài phút.","Filtering is already running for your whole home.":"Việc lọc đã chạy cho cả nhà rồi.","Protection is starting — no action needed.":"Bảo vệ đang khởi động — không cần làm gì.","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"Bảng điều khiển và số liệu là tuỳ chọn. Đặt mật khẩu nếu muốn dùng — không thì chỉ cần đóng trang này và tận hưởng sự yên tĩnh.","Set up the dashboard":"Thiết lập bảng điều khiển","Choose your dashboard password":"Chọn mật khẩu bảng điều khiển","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"Mật khẩu này bảo vệ bảng điều khiển và chế độ nâng cao. Hãy ghi lại và cất ở nơi an toàn. Nếu quên, hãy giữ nút RESET trên hộp lọc 5 giây.","You're all set 🛡️":"Bạn đã sẵn sàng 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"Việc lọc đã chạy cho cả nhà — bảng điều khiển cho bạn thấy tình hình.","Queries today":"Truy vấn hôm nay","Blocked":"Đã chặn","Blocked share":"Tỷ lệ chặn","ads and trackers":"quảng cáo và trình theo dõi","lookups today":"lượt tra cứu hôm nay","Each bar is 10 minutes · busiest:":"Mỗi cột là 10 phút · cao điểm:","since midnight":"từ nửa đêm","waiting for traffic":"đang chờ lưu lượng","Queries":"Truy vấn","Keep the box updated automatically":"Tự động cập nhật hộp lọc","Security fixes and filtering improvements only — no personal data leaves the box.":"Chỉ các bản sửa lỗi bảo mật và cải tiến lọc — không có dữ liệu cá nhân nào rời khỏi hộp.","Share anonymous diagnostic reports":"Chia sẻ báo cáo chẩn đoán ẩn danh","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"Nhật ký lỗi và kiểm tra tình trạng giúp chúng tôi khắc phục sự cố. Không có lịch sử duyệt web, tên thiết bị hay dữ liệu cá nhân — chỉ các chi tiết kỹ thuật ẩn danh, được gửi riêng đến chúng tôi.","Language":"Ngôn ngữ","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"Hộp này không nhận ra địa chỉ đã mở trang này. Hãy mở http://filterbox.lan và thử lại.","Pause":"Tạm dừng","This dashboard is private to your home. Enter the password you chose during setup.":"Bảng điều khiển này là riêng tư cho ngôi nhà của bạn. Nhập mật khẩu bạn đã chọn khi thiết lập.","FilterBox — Sign in":"FilterBox — Đăng nhập"," queries · ":" truy vấn · ","Wait a minute, then":"Đợi một phút, rồi "},"zh":{"FilterBox — Setup":"FilterBox — 设置","Your filter box is online 🎉":"你的过滤器已上线 🎉","Checking your setup…":"正在检查设置…","Protection…":"防护…","Internet…":"网络…","Get started":"开始使用","Choose your admin password":"设置管理员密码","This protects your filter's settings page. Write it down somewhere safe.":"这个密码用于保护过滤器的设置页面。请记下来，放在安全的地方。","Password (at least 8 characters)":"密码（至少 8 个字符）","Repeat password":"再次输入密码","Save password":"保存密码","Internet connection":"网络连接","Choose how this box reaches the internet.":"选择这台设备如何连接网络。","Ethernet":"以太网","Scan for Wi-Fi networks":"扫描 Wi-Fi 网络","Wi-Fi password":"Wi-Fi 密码","Connect":"连接","Continue":"继续","All set! 🛡️":"全部搞定！🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"你的网络现在已受到保护。所有通过这台设备上网的设备，广告和跟踪器都会被过滤。","Opening your dashboard…":"正在打开控制面板…","Open dashboard":"打开控制面板","Setup already complete":"设置已完成","This box has already been set up. Head to the dashboard to see how it's doing.":"这台设备已经设置好了。进入控制面板就能看到运行情况。","· your data stays on this device":"· 你的数据留在这台设备上","Bad response":"响应异常","Protection: active":"防护：已开启","Protection: warming up":"防护：正在预热","Internet: connected":"网络：已连接","Internet: not yet":"网络：尚未连接","This box: ":"本机：","Good news — filtering is already working.":"好消息——过滤已经在工作了。","Almost there — let’s finish the quick setup.":"就快好了——来完成这个快速设置吧。","Ethernet: cable connected":"Ethernet：已连接网线","Ethernet: no cable detected":"Ethernet：未检测到网线","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"这台设备支持 Wi-Fi，你可以用 Wi-Fi，也可以继续用 Ethernet。","This box filters through its network cable — nothing to configure here.":"这台设备通过网线工作，这里不需要设置。","Password needs at least 8 characters.":"密码至少需要 8 个字符。","The two passwords don’t match.":"两次输入的密码不一致。","Something went wrong.":"出了点问题。","Saving…":"正在保存…","Scanning…":"正在扫描…","Scan again":"重新扫描","Password for “":"密码：“","Connecting…":"正在连接…","Connected.":"已连接。","Could not connect.":"无法连接。","Not ready yet.":"还没有准备好。","No networks found. Try again, or keep using Ethernet.":"没有找到网络。请重试，或继续使用 Ethernet。","Checking on your filter…":"正在检查过滤器…","Turn back on":"重新开启","blocked today":"今日已拦截","Last 7 days":"最近 7 天","Top blocked today":"今日拦截最多","Warming up…":"正在预热…","Nothing blocked yet — enjoy the quiet.":"还没有拦截记录——享受清净吧。","Pause filtering?":"暂停过滤？","Filtering will pause for a short break.":"过滤会暂停一小段时间。","Pause 30 minutes":"暂停 30 分钟","Pause 1 hour":"暂停 1 小时","Pause until I turn it back on":"暂停，直到我重新开启","Cancel":"取消","Enter your dashboard password":"输入控制面板密码","Password":"密码","Settings":"设置","Tap to pause filtering":"点按以暂停过滤","Back in ":"还有 ","Back in ~":"约 "," h ":" 小时 "," min":" 分钟","Could not reach the panel — reload in a moment.":"无法连接控制面板——请稍后刷新。","Too many requests — wait a minute.":"请求太多——请等一分钟。","Something went wrong — try again.":"出了点问题——请重试。","Paused until you turn it back on.":"已暂停，直到你重新开启。","Paused for 30 minutes.":"已暂停 30 分钟。","Paused for 1 hour.":"已暂停 1 小时。","Protection is back on.":"防护已重新开启。","Paused until you turn it back on":"暂停，直到你重新开启","Protection: paused":"防护：已暂停","Protection: checking…":"防护：正在检查…","Protection: needs attention":"防护：需要注意","Filter engine starting up — stats will appear shortly.":"过滤引擎正在启动——统计稍后显示。","Ad blocking seems off — try restarting the box, or contact support.":"广告拦截似乎没有开启——请尝试重启设备，或联系支持。","Working quietly in the background.":"正在后台安静运行。","Internet: not reaching the internet":"网络：无法连接到互联网","Internet: checking…":"网络：正在检查…","waiting for the filter engine…":"正在等待过滤引擎…","% of all queries · ":"占全部查询的 % · "," domains in your protection lists":" 个域名在保护列表中","Every bar is a slice of the week — taller means more ads blocked.":"每根柱子代表一周中的一段——越高表示拦截的广告越多。","The chart fills in as the week goes.":"随着这一周过去，图表会逐渐填满。","That password doesn't match — try again.":"密码不对——请重试。"," blocked":" 已拦截","FilterBox — Settings":"FilterBox — 设置","← Dashboard":"← 控制面板","Change password":"更改密码","This is the password for the dashboard and the advanced view.":"这个密码用于控制面板和高级视图。","Current password":"当前密码","New password (at least 8 characters)":"新密码（至少 8 个字符）","Repeat new password":"再次输入新密码","Password updated.":"密码已更新。","Save new password":"保存新密码","Restart the box":"重启设备","Takes about a minute. Filtering pauses briefly while it restarts.":"大约需要一分钟。重启期间过滤会短暂暂停。","Restart now":"立即重启","Factory reset":"恢复出厂设置","Reset this box…":"重置这台设备…","Type RESET to confirm":"输入 RESET 确认","Dashboard password":"控制面板密码","Erase everything and reset":"清除全部并重置","About":"关于","Panel version":"面板版本","Filter engine":"过滤引擎","Uptime":"运行时间","Address":"地址","Working…":"处理中…","Please wait.":"请稍候。","Password must be at least 8 characters.":"密码必须至少 8 个字符。","The two new passwords don’t match.":"两次输入的新密码不一致。","Restart now? Tap again to confirm":"立即重启？再次点按以确认","Restarting…":"正在重启…","Back online.":"已恢复在线。","This takes about a minute. Filtering pauses briefly while it restarts.":"大约需要一分钟。重启期间过滤会短暂暂停。","Restarting the box":"正在重启设备","Still working…":"仍在处理…","Reloading…":"正在刷新…","Type RESET exactly to confirm.":"请准确输入 RESET 以确认。","Resetting the box":"正在重置设备","Erasing settings and returning to setup mode — the box will restart.":"正在清除设置并返回设置模式——设备将重启。","Back to setup — reloading…":"返回设置——正在刷新…"," d ":" 天 ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"设备还没有恢复。请检查电源是否已接通，然后刷新此页面。","Too many requests":"请求过多","Wait a minute, then ":"请稍等一分钟，然后 ","reload the dashboard":"刷新控制面板","Nothing here":"这里什么都没有","That page doesn't exist.":"该页面不存在。","Back to FilterBox":"返回 FilterBox","not found":"未找到","Too many attempts — wait a minute.":"尝试次数过多——请等一分钟。","Session expired — enter the password again.":"会话已过期——请重新输入密码。","Pick 30 minutes, 1 hour, or until you turn it back on.":"选择 30 分钟、1 小时，或直到你重新开启。","Setup is already complete.":"设置已经完成。","That's not the current password — try again.":"当前密码不正确——请重试。","Password is too long (max 128 characters).":"密码太长（最多 128 个字符）。","Couldn't start the restart — check that the box is powered, then try again.":"无法开始重启——请检查设备电源，然后重试。","Could not set the password (service not ready?). Try again in a moment.":"无法设置密码（服务还没准备好？）。请稍后再试。","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"这台设备没有检测到 Wi-Fi 适配器——它使用 Ethernet。一切就绪。","Pick a network and enter its password (at least 8 chars).":"请选择一个网络并输入密码（至少 8 个字符）。","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"这台设备没有 Wi-Fi 适配器——用 Ethernet 就可以。这里无需操作。","Wi-Fi tools are not available on this box.":"这台设备不支持 Wi-Fi 功能。","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"Wi-Fi 设置已保存，但还没有获取到地址——请等一分钟再刷新此页面。","Set an admin password first.":"请先设置管理员密码。","Connected to ":"已连接到 ","Could not update Wi-Fi config: ":"无法更新 Wi-Fi 配置：","queries today":"今日查询"," blocked (":" 已拦截（","answered from cache: ":"由缓存应答："," · forwarded: ":" · 转发：","Today":"今天","Each bar is 10 minutes — the purple part was blocked.":"每根柱子代表 10 分钟——紫色部分是已拦截的。","The chart fills in as the day goes.":"随着一天过去，图表会逐渐填满。","Most visited today":"今日访问最多","Busiest devices":"最忙的设备","Where answers came from":"应答来源","Traffic mix":"流量构成","Advanced view":"高级视图","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"面向高级用户——完整的技术面板：查询日志、拦截列表管理和详细设置。","Open advanced view":"打开高级视图","Uses the same password as this page. Changes there affect filtering for the whole home.":"与本页使用同一个密码。那里的改动会影响全家的过滤。","Whole home":"全家","Covered — ":"已覆盖——"," devices seen on your network":" 台设备已出现在你的网络中","Protection is paused — filtering is off.":"防护已暂停——过滤已关闭。","Coverage paused — finishing network release…":"覆盖已暂停——正在完成网络释放…","Protection starts as soon as setup is finished.":"设置一完成，防护就会开始。","Coverage is on — devices will appear as they browse.":"覆盖已开启——设备上网后会陆续出现。","Coverage starting…":"覆盖正在启动…","Coverage paused — the internet is open.":"覆盖已暂停——网络未受保护。","Coverage is off.":"覆盖已关闭。","Coverage has not started — check the box.":"覆盖尚未启动——请检查设备。","Coverage status unavailable — check the box.":"无法获取覆盖状态——请检查设备。","Protection: starts after setup":"防护：设置后开始","Finish setup to switch protection on for the whole home.":"完成设置，为全家开启防护。","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"设置完成。正在为全家开启防护——控制面板会显示进度。","Coverage status is out of date — check the box.":"覆盖状态已过期——请检查设备。","Coverage unavailable on this network — contact support.":"此网络无法提供覆盖——请联系支持。","Network release still finishing — check the box.":"网络释放仍在进行——请检查设备。","Coverage could not start — restart the box or contact support.":"覆盖无法启动——请重启设备或联系支持。","Internal error — try again.":"内部错误——请重试。","That network name is not supported — choose another network.":"不支持该网络名称——请选择其他网络。","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"会清除控制面板密码、设置和统计数据。过滤会继续运行，Wi-Fi 设置会保留。此操作无法撤销——如果忘记密码，请按住设备上的 RESET 按钮 5 秒。","Protection lists need attention — the box is repairing them.":"保护列表需要注意——设备正在修复。","Filtering is on — coverage status unavailable.":"过滤已开启——无法获取覆盖状态。","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"保护列表还在准备中——请保持设备通电并连接，几分钟后再试。","Filtering is already running for your whole home.":"全家的过滤已经在运行了。","Protection is starting — no action needed.":"防护正在启动——无需操作。","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"控制面板和统计是可选的。想用就设置密码——否则直接关闭此页面，享受清净就好。","Set up the dashboard":"设置控制面板","Choose your dashboard password":"设置控制面板密码","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"这个密码保护控制面板和高级视图。请记下来，放在安全的地方。如果忘记了，请按住设备上的 RESET 按钮 5 秒。","You're all set 🛡️":"一切就绪 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"全家的过滤已在运行——控制面板会显示进展。","Queries today":"今日查询","Blocked":"已拦截","Blocked share":"拦截占比","ads and trackers":"广告和跟踪器","lookups today":"今日查询次数","Each bar is 10 minutes · busiest:":"每根柱子代表 10 分钟 · 高峰：","since midnight":"自午夜起","waiting for traffic":"等待流量","Queries":"查询","Keep the box updated automatically":"自动保持设备更新","Security fixes and filtering improvements only — no personal data leaves the box.":"仅包含安全修复和过滤改进——不会将任何个人数据传出设备。","Share anonymous diagnostic reports":"共享匿名诊断报告","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"帮助我们解决问题的错误日志和健康检查。不包含浏览记录、设备名称或个人数据——仅发送匿名技术详情，并私下发送给我们。","Language":"语言","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"设备无法识别打开此页面的地址。请打开 http://filterbox.lan 后重试。","Pause":"暂停","This dashboard is private to your home. Enter the password you chose during setup.":"此面板仅供您的家庭使用。请输入您在设置时设定的密码。","FilterBox — Sign in":"FilterBox — 登录"," queries · ":" 次查询 · ","Wait a minute, then":"请稍等一分钟，然后"},"hi":{"FilterBox — Setup":"FilterBox — सेटअप","Your filter box is online 🎉":"आपका फ़िल्टर बॉक्स ऑनलाइन है 🎉","Checking your setup…":"आपका सेटअप जाँचा जा रहा है…","Protection…":"सुरक्षा…","Internet…":"इंटरनेट…","Get started":"शुरू करें","Choose your admin password":"अपना एडमिन पासवर्ड चुनें","This protects your filter's settings page. Write it down somewhere safe.":"यह आपके फ़िल्टर के सेटिंग्स पेज की सुरक्षा करता है। इसे कहीं सुरक्षित लिख लें।","Password (at least 8 characters)":"पासवर्ड (कम से कम 8 अक्षर)","Repeat password":"पासवर्ड दोहराएँ","Save password":"पासवर्ड सहेजें","Internet connection":"इंटरनेट कनेक्शन","Choose how this box reaches the internet.":"चुनें कि यह बॉक्स इंटरनेट तक कैसे पहुँचेगा।","Ethernet":"ईथरनेट","Scan for Wi-Fi networks":"Wi-Fi नेटवर्क खोजें","Wi-Fi password":"Wi-Fi पासवर्ड","Connect":"कनेक्ट करें","Continue":"जारी रखें","All set! 🛡️":"सब तैयार! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"आपका नेटवर्क अब सुरक्षित है। इस बॉक्स का उपयोग करने वाले हर डिवाइस के लिए विज्ञापन और ट्रैकर फ़िल्टर हो रहे हैं।","Opening your dashboard…":"आपका डैशबोर्ड खुल रहा है…","Open dashboard":"डैशबोर्ड खोलें","Setup already complete":"सेटअप पहले ही पूरा हो चुका है","This box has already been set up. Head to the dashboard to see how it's doing.":"यह बॉक्स पहले ही सेट हो चुका है। यह कैसा चल रहा है देखने के लिए डैशबोर्ड पर जाएँ।","· your data stays on this device":"· आपका डेटा इस डिवाइस पर ही रहता है","Bad response":"गलत प्रतिक्रिया","Protection: active":"सुरक्षा: सक्रिय","Protection: warming up":"सुरक्षा: तैयार हो रही है","Internet: connected":"इंटरनेट: जुड़ा हुआ","Internet: not yet":"इंटरनेट: अभी नहीं","This box: ":"यह बॉक्स: ","Good news — filtering is already working.":"अच्छी ख़बर — फ़िल्टरिंग पहले से काम कर रही है।","Almost there — let’s finish the quick setup.":"बस थोड़ा और — तेज़ सेटअप पूरा करें।","Ethernet: cable connected":"Ethernet: केबल जुड़ी है","Ethernet: no cable detected":"Ethernet: कोई केबल नहीं मिली","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"इस बॉक्स में Wi-Fi उपलब्ध है — आप इसका उपयोग कर सकते हैं या Ethernet रख सकते हैं।","This box filters through its network cable — nothing to configure here.":"यह बॉक्स अपनी नेटवर्क केबल से फ़िल्टर करता है — यहाँ कुछ सेट करने की ज़रूरत नहीं।","Password needs at least 8 characters.":"पासवर्ड कम से कम 8 अक्षरों का होना चाहिए।","The two passwords don’t match.":"दोनों पासवर्ड मेल नहीं खाते।","Something went wrong.":"कुछ गड़बड़ हो गई।","Saving…":"सहेजा जा रहा है…","Scanning…":"खोजा जा रहा है…","Scan again":"फिर से खोजें","Password for “":"इसका पासवर्ड: “","Connecting…":"कनेक्ट हो रहा है…","Connected.":"जुड़ गया।","Could not connect.":"कनेक्ट नहीं हो सका।","Not ready yet.":"अभी तैयार नहीं।","No networks found. Try again, or keep using Ethernet.":"कोई नेटवर्क नहीं मिला। फिर कोशिश करें, या Ethernet ही उपयोग करें।","Checking on your filter…":"आपका फ़िल्टर जाँचा जा रहा है…","Turn back on":"फिर से चालू करें","blocked today":"आज ब्लॉक हुए","Last 7 days":"पिछले 7 दिन","Top blocked today":"आज सबसे ज़्यादा ब्लॉक","Warming up…":"तैयार हो रहा है…","Nothing blocked yet — enjoy the quiet.":"अभी कुछ भी ब्लॉक नहीं हुआ — शांति का आनंद लें।","Pause filtering?":"फ़िल्टरिंग रोकें?","Filtering will pause for a short break.":"फ़िल्टरिंग थोड़ी देर के लिए रुकेगी।","Pause 30 minutes":"30 मिनट रोकें","Pause 1 hour":"1 घंटा रोकें","Pause until I turn it back on":"चालू करने तक रोकें","Cancel":"रद्द करें","Enter your dashboard password":"अपना डैशबोर्ड पासवर्ड डालें","Password":"पासवर्ड","Settings":"सेटिंग्स","Tap to pause filtering":"फ़िल्टरिंग रोकने के लिए टैप करें","Back in ":"वापसी: ","Back in ~":"वापसी ~"," h ":" घं "," min":" मिनट","Could not reach the panel — reload in a moment.":"पैनल तक नहीं पहुँच सके — थोड़ी देर में फिर लोड करें।","Too many requests — wait a minute.":"बहुत ज़्यादा अनुरोध — एक मिनट रुकें।","Something went wrong — try again.":"कुछ गड़बड़ हो गई — फिर कोशिश करें।","Paused until you turn it back on.":"चालू करने तक रोका गया।","Paused for 30 minutes.":"30 मिनट के लिए रोका गया।","Paused for 1 hour.":"1 घंटे के लिए रोका गया।","Protection is back on.":"सुरक्षा फिर से चालू है।","Paused until you turn it back on":"चालू करने तक रोका गया","Protection: paused":"सुरक्षा: रोकी गई","Protection: checking…":"सुरक्षा: जाँच हो रही है…","Protection: needs attention":"सुरक्षा: ध्यान चाहिए","Filter engine starting up — stats will appear shortly.":"फ़िल्टर इंजन शुरू हो रहा है — आँकड़े थोड़ी देर में दिखेंगे।","Ad blocking seems off — try restarting the box, or contact support.":"विज्ञापन ब्लॉकिंग बंद लगती है — बॉक्स को फिर शुरू करें या सहायता से संपर्क करें।","Working quietly in the background.":"पर्दे के पीछे चुपचाप काम कर रहा है।","Internet: not reaching the internet":"इंटरनेट: इंटरनेट तक नहीं पहुँच रहा","Internet: checking…":"इंटरनेट: जाँच हो रही है…","waiting for the filter engine…":"फ़िल्टर इंजन की प्रतीक्षा…","% of all queries · ":"सभी क्वेरी का % · "," domains in your protection lists":" डोमेन आपकी सुरक्षा सूचियों में","Every bar is a slice of the week — taller means more ads blocked.":"हर बार सप्ताह का एक हिस्सा है — ऊँचाई यानी ज़्यादा विज्ञापन ब्लॉक हुए।","The chart fills in as the week goes.":"सप्ताह बढ़ने के साथ चार्ट भरता जाता है।","That password doesn't match — try again.":"यह पासवर्ड मेल नहीं खाता — फिर कोशिश करें।"," blocked":" ब्लॉक","FilterBox — Settings":"FilterBox — सेटिंग्स","← Dashboard":"← डैशबोर्ड","Change password":"पासवर्ड बदलें","This is the password for the dashboard and the advanced view.":"यह डैशबोर्ड और एडवांस्ड व्यू का पासवर्ड है।","Current password":"मौजूदा पासवर्ड","New password (at least 8 characters)":"नया पासवर्ड (कम से कम 8 अक्षर)","Repeat new password":"नया पासवर्ड दोहराएँ","Password updated.":"पासवर्ड अपडेट हो गया।","Save new password":"नया पासवर्ड सहेजें","Restart the box":"बॉक्स फिर शुरू करें","Takes about a minute. Filtering pauses briefly while it restarts.":"लगभग एक मिनट लगता है। फिर शुरू होते समय फ़िल्टरिंग थोड़ी देर रुकती है।","Restart now":"अभी फिर शुरू करें","Factory reset":"फ़ैक्टरी रीसेट","Reset this box…":"इस बॉक्स को रीसेट करें…","Type RESET to confirm":"पुष्टि के लिए RESET लिखें","Dashboard password":"डैशबोर्ड पासवर्ड","Erase everything and reset":"सब कुछ मिटाएँ और रीसेट करें","About":"जानकारी","Panel version":"पैनल संस्करण","Filter engine":"फ़िल्टर इंजन","Uptime":"चालू समय","Address":"पता","Working…":"काम हो रहा है…","Please wait.":"कृपया प्रतीक्षा करें।","Password must be at least 8 characters.":"पासवर्ड कम से कम 8 अक्षरों का होना चाहिए।","The two new passwords don’t match.":"दोनों नए पासवर्ड मेल नहीं खाते।","Restart now? Tap again to confirm":"अभी फिर शुरू करें? पुष्टि के लिए फिर टैप करें","Restarting…":"फिर शुरू हो रहा है…","Back online.":"फिर ऑनलाइन।","This takes about a minute. Filtering pauses briefly while it restarts.":"इसमें लगभग एक मिनट लगता है। फिर शुरू होते समय फ़िल्टरिंग थोड़ी देर रुकती है।","Restarting the box":"बॉक्स फिर शुरू हो रहा है","Still working…":"अभी भी काम चल रहा है…","Reloading…":"फिर लोड हो रहा है…","Type RESET exactly to confirm.":"पुष्टि के लिए ठीक RESET लिखें।","Resetting the box":"बॉक्स रीसेट हो रहा है","Erasing settings and returning to setup mode — the box will restart.":"सेटिंग्स मिटाई जा रही हैं और सेटअप मोड पर लौटा जा रहा है — बॉक्स फिर शुरू होगा।","Back to setup — reloading…":"सेटअप पर वापस — फिर लोड हो रहा है…"," d ":" दि ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"बॉक्स अभी तक वापस नहीं आया। देखें कि उसमें बिजली है, फिर यह पेज फिर लोड करें।","Too many requests":"बहुत ज़्यादा अनुरोध","Wait a minute, then ":"एक मिनट रुकें, फिर ","reload the dashboard":"डैशबोर्ड फिर लोड करें","Nothing here":"यहाँ कुछ नहीं","That page doesn't exist.":"वह पेज मौजूद नहीं है।","Back to FilterBox":"FilterBox पर वापस","not found":"नहीं मिला","Too many attempts — wait a minute.":"बहुत ज़्यादा कोशिशें — एक मिनट रुकें।","Session expired — enter the password again.":"सत्र समाप्त — पासवर्ड फिर डालें।","Pick 30 minutes, 1 hour, or until you turn it back on.":"30 मिनट, 1 घंटा, या चालू करने तक चुनें।","Setup is already complete.":"सेटअप पहले ही पूरा है।","That's not the current password — try again.":"यह मौजूदा पासवर्ड नहीं है — फिर कोशिश करें।","Password is too long (max 128 characters).":"पासवर्ड बहुत लंबा है (अधिकतम 128 अक्षर)।","Couldn't start the restart — check that the box is powered, then try again.":"फिर शुरू करना शुरू नहीं हो सका — देखें कि बॉक्स में बिजली है, फिर कोशिश करें।","Could not set the password (service not ready?). Try again in a moment.":"पासवर्ड सेट नहीं हो सका (सेवा तैयार नहीं?)। थोड़ी देर में फिर कोशिश करें।","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"इस बॉक्स में कोई Wi-Fi एडाप्टर नहीं मिला — यह Ethernet उपयोग करता है। सब तैयार है।","Pick a network and enter its password (at least 8 chars).":"एक नेटवर्क चुनें और उसका पासवर्ड डालें (कम से कम 8 अक्षर)।","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"इस बॉक्स में Wi-Fi एडाप्टर नहीं है — Ethernet ही रास्ता है। यहाँ कुछ नहीं करना है।","Wi-Fi tools are not available on this box.":"इस बॉक्स पर Wi-Fi टूल उपलब्ध नहीं हैं।","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"Wi-Fi सेटिंग्स सहेजी गईं, पर अभी कोई पता नहीं — एक मिनट दें और यह पेज फिर लोड करें।","Set an admin password first.":"पहले एक एडमिन पासवर्ड सेट करें।","Connected to ":"जुड़ गए: ","Could not update Wi-Fi config: ":"Wi-Fi कॉन्फ़िग अपडेट नहीं हो सका: ","queries today":"आज की क्वेरी"," blocked (":" ब्लॉक (","answered from cache: ":"कैश से उत्तर: "," · forwarded: ":" · फ़ॉरवर्ड: ","Today":"आज","Each bar is 10 minutes — the purple part was blocked.":"हर बार 10 मिनट है — बैंगनी हिस्सा ब्लॉक हुआ।","The chart fills in as the day goes.":"दिन बढ़ने के साथ चार्ट भरता जाता है।","Most visited today":"आज सबसे ज़्यादा देखे गए","Busiest devices":"सबसे व्यस्त डिवाइस","Where answers came from":"उत्तर कहाँ से आए","Traffic mix":"ट्रैफ़िक मिश्रण","Advanced view":"एडवांस्ड व्यू","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"एडवांस्ड उपयोगकर्ताओं के लिए — पूरा तकनीकी डैशबोर्ड: क्वेरी लॉग, ब्लॉकलिस्ट प्रबंधन और विस्तृत सेटिंग्स।","Open advanced view":"एडवांस्ड व्यू खोलें","Uses the same password as this page. Changes there affect filtering for the whole home.":"इस पेज जैसा ही पासवर्ड उपयोग करता है। वहाँ के बदलाव पूरे घर की फ़िल्टरिंग पर लागू होते हैं।","Whole home":"पूरा घर","Covered — ":"कवर — "," devices seen on your network":" डिवाइस आपके नेटवर्क पर दिखे","Protection is paused — filtering is off.":"सुरक्षा रोकी गई है — फ़िल्टरिंग बंद है।","Coverage paused — finishing network release…":"कवरेज रोका गया — नेटवर्क रिलीज़ पूरी हो रही है…","Protection starts as soon as setup is finished.":"सेटअप पूरा होते ही सुरक्षा शुरू हो जाती है।","Coverage is on — devices will appear as they browse.":"कवरेज चालू है — डिवाइस ब्राउज़ करते ही दिखेंगे।","Coverage starting…":"कवरेज शुरू हो रही है…","Coverage paused — the internet is open.":"कवरेज रोका गया — इंटरनेट खुला है।","Coverage is off.":"कवरेज बंद है।","Coverage has not started — check the box.":"कवरेज शुरू नहीं हुई — बॉक्स जाँचें।","Coverage status unavailable — check the box.":"कवरेज स्थिति उपलब्ध नहीं — बॉक्स जाँचें।","Protection: starts after setup":"सुरक्षा: सेटअप के बाद शुरू होगी","Finish setup to switch protection on for the whole home.":"पूरे घर के लिए सुरक्षा चालू करने के लिए सेटअप पूरा करें।","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"सेटअप पूरा हुआ। आपके पूरे घर के लिए सुरक्षा चालू हो रही है — डैशबोर्ड प्रगति दिखाता है।","Coverage status is out of date — check the box.":"कवरेज स्थिति पुरानी है — बॉक्स जाँचें।","Coverage unavailable on this network — contact support.":"इस नेटवर्क पर कवरेज उपलब्ध नहीं — सहायता से संपर्क करें।","Network release still finishing — check the box.":"नेटवर्क रिलीज़ अभी पूरी हो रही है — बॉक्स जाँचें।","Coverage could not start — restart the box or contact support.":"कवरेज शुरू नहीं हो सकी — बॉक्स फिर शुरू करें या सहायता से संपर्क करें।","Internal error — try again.":"आंतरिक त्रुटि — फिर कोशिश करें।","That network name is not supported — choose another network.":"यह नेटवर्क नाम समर्थित नहीं है — दूसरा नेटवर्क चुनें।","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"आपका डैशबोर्ड पासवर्ड, सेटिंग्स और आँकड़े मिटाता है। फ़िल्टरिंग चलती रहती है, और Wi-Fi सेटिंग्स बनी रहती हैं। इसे पूर्ववत नहीं किया जा सकता — अगर कभी पासवर्ड भूल जाएँ, तो बॉक्स का RESET बटन 5 सेकंड दबाए रखें।","Protection lists need attention — the box is repairing them.":"सुरक्षा सूचियों पर ध्यान चाहिए — बॉक्स उन्हें ठीक कर रहा है।","Filtering is on — coverage status unavailable.":"फ़िल्टरिंग चालू है — कवरेज स्थिति उपलब्ध नहीं।","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"आपकी सुरक्षा सूचियाँ अभी तैयार हो रही हैं — बॉक्स को चालू और जुड़ा रखें, फिर कुछ मिनट में कोशिश करें।","Filtering is already running for your whole home.":"फ़िल्टरिंग आपके पूरे घर के लिए पहले से चल रही है।","Protection is starting — no action needed.":"सुरक्षा शुरू हो रही है — कुछ करने की ज़रूरत नहीं।","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"डैशबोर्ड और आँकड़े वैकल्पिक हैं। इनका उपयोग करने के लिए पासवर्ड सेट करें — वरना यह पेज बंद करें और शांति का आनंद लें।","Set up the dashboard":"डैशबोर्ड सेट करें","Choose your dashboard password":"अपना डैशबोर्ड पासवर्ड चुनें","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"यह डैशबोर्ड और एडवांस्ड व्यू की सुरक्षा करता है। इसे कहीं सुरक्षित लिख लें। भूल जाएँ तो बॉक्स का RESET बटन 5 सेकंड दबाए रखें।","You're all set 🛡️":"सब तैयार है 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"फ़िल्टरिंग आपके पूरे घर के लिए पहले से चल रही है — डैशबोर्ड दिखाता है कि कैसी चल रही है।","Queries today":"आज की क्वेरी","Blocked":"ब्लॉक","Blocked share":"ब्लॉक हिस्सा","ads and trackers":"विज्ञापन और ट्रैकर","lookups today":"आज के लुकअप","Each bar is 10 minutes · busiest:":"हर बार 10 मिनट · सबसे व्यस्त:","since midnight":"आधी रात से","waiting for traffic":"ट्रैफ़िक की प्रतीक्षा","Queries":"क्वेरी","Keep the box updated automatically":"बॉक्स को अपने आप अपडेट रखें","Security fixes and filtering improvements only — no personal data leaves the box.":"केवल सुरक्षा सुधार और फ़िल्टरिंग सुधार — कोई भी व्यक्तिगत डेटा बॉक्स से बाहर नहीं जाता।","Share anonymous diagnostic reports":"अनाम निदान रिपोर्ट साझा करें","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"त्रुटि लॉग और स्वास्थ्य जाँचें जो हमें समस्याएँ ठीक करने में मदद करती हैं। कोई ब्राउज़िंग इतिहास, डिवाइस नाम या व्यक्तिगत डेटा नहीं — केवल अनाम तकनीकी विवरण, जो हमें निजी रूप से भेजे जाते हैं।","Language":"भाषा","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"इस बॉक्स ने वह पता नहीं पहचाना जिससे यह पेज खोला गया। http://filterbox.lan खोलें और फिर से कोशिश करें।","Pause":"रोकें","This dashboard is private to your home. Enter the password you chose during setup.":"यह डैशबोर्ड आपके घर के लिए निजी है। सेटअप के दौरान चुना गया पासवर्ड दर्ज करें।","FilterBox — Sign in":"FilterBox — साइन इन"," queries · ":" क्वेरी · ","Wait a minute, then":"एक मिनट रुकें, फिर "},"id":{"FilterBox — Setup":"FilterBox — Penyiapan","Your filter box is online 🎉":"Kotak filter Anda sudah online 🎉","Checking your setup…":"Memeriksa penyiapan Anda…","Protection…":"Perlindungan…","Internet…":"Internet…","Get started":"Mulai","Choose your admin password":"Pilih kata sandi admin Anda","This protects your filter's settings page. Write it down somewhere safe.":"Ini melindungi halaman pengaturan filter Anda. Catat di tempat yang aman.","Password (at least 8 characters)":"Kata sandi (minimal 8 karakter)","Repeat password":"Ulangi kata sandi","Save password":"Simpan kata sandi","Internet connection":"Koneksi internet","Choose how this box reaches the internet.":"Pilih cara kotak ini terhubung ke internet.","Ethernet":"Ethernet","Scan for Wi-Fi networks":"Pindai jaringan Wi-Fi","Wi-Fi password":"Kata sandi Wi-Fi","Connect":"Hubungkan","Continue":"Lanjutkan","All set! 🛡️":"Semua siap! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"Jaringan Anda kini terlindungi. Iklan dan pelacak difilter untuk setiap perangkat yang memakai kotak ini.","Opening your dashboard…":"Membuka dasbor Anda…","Open dashboard":"Buka dasbor","Setup already complete":"Penyiapan sudah selesai","This box has already been set up. Head to the dashboard to see how it's doing.":"Kotak ini sudah disiapkan. Buka dasbor untuk melihat kondisinya.","· your data stays on this device":"· data Anda tetap di perangkat ini","Bad response":"Respons tidak valid","Protection: active":"Perlindungan: aktif","Protection: warming up":"Perlindungan: bersiap","Internet: connected":"Internet: terhubung","Internet: not yet":"Internet: belum","This box: ":"Kotak ini: ","Good news — filtering is already working.":"Kabar baik — pemfilteran sudah berjalan.","Almost there — let’s finish the quick setup.":"Hampir selesai — ayo tuntaskan penyiapan cepatnya.","Ethernet: cable connected":"Ethernet: kabel terpasang","Ethernet: no cable detected":"Ethernet: kabel tidak terdeteksi","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"Wi-Fi tersedia di kotak ini — Anda bisa memakainya, atau tetap pakai Ethernet.","This box filters through its network cable — nothing to configure here.":"Kotak ini memfilter lewat kabel jaringannya — tidak ada yang perlu diatur di sini.","Password needs at least 8 characters.":"Kata sandi harus minimal 8 karakter.","The two passwords don’t match.":"Kedua kata sandi tidak sama.","Something went wrong.":"Terjadi kesalahan.","Saving…":"Menyimpan…","Scanning…":"Memindai…","Scan again":"Pindai lagi","Password for “":"Kata sandi untuk “","Connecting…":"Menghubungkan…","Connected.":"Terhubung.","Could not connect.":"Tidak bisa terhubung.","Not ready yet.":"Belum siap.","No networks found. Try again, or keep using Ethernet.":"Jaringan tidak ditemukan. Coba lagi, atau tetap pakai Ethernet.","Checking on your filter…":"Memeriksa filter Anda…","Turn back on":"Nyalakan lagi","blocked today":"diblokir hari ini","Last 7 days":"7 hari terakhir","Top blocked today":"Paling banyak diblokir hari ini","Warming up…":"Bersiap…","Nothing blocked yet — enjoy the quiet.":"Belum ada yang diblokir — nikmati ketenangannya.","Pause filtering?":"Jeda pemfilteran?","Filtering will pause for a short break.":"Pemfilteran akan dijeda sebentar.","Pause 30 minutes":"Jeda 30 menit","Pause 1 hour":"Jeda 1 jam","Pause until I turn it back on":"Jeda sampai saya nyalakan lagi","Cancel":"Batal","Enter your dashboard password":"Masukkan kata sandi dasbor Anda","Password":"Kata sandi","Settings":"Pengaturan","Tap to pause filtering":"Ketuk untuk menjeda pemfilteran","Back in ":"Kembali dalam ","Back in ~":"Kembali ~"," h ":" jam "," min":" mnt","Could not reach the panel — reload in a moment.":"Panel tidak bisa dihubungi — muat ulang sebentar lagi.","Too many requests — wait a minute.":"Terlalu banyak permintaan — tunggu satu menit.","Something went wrong — try again.":"Terjadi kesalahan — coba lagi.","Paused until you turn it back on.":"Dijeda sampai Anda menyalakannya lagi.","Paused for 30 minutes.":"Dijeda selama 30 menit.","Paused for 1 hour.":"Dijeda selama 1 jam.","Protection is back on.":"Perlindungan aktif kembali.","Paused until you turn it back on":"Dijeda sampai Anda menyalakannya lagi","Protection: paused":"Perlindungan: dijeda","Protection: checking…":"Perlindungan: memeriksa…","Protection: needs attention":"Perlindungan: perlu perhatian","Filter engine starting up — stats will appear shortly.":"Mesin filter mulai — statistik akan muncul sebentar lagi.","Ad blocking seems off — try restarting the box, or contact support.":"Pemblokiran iklan tampaknya mati — coba nyalakan ulang kotak, atau hubungi dukungan.","Working quietly in the background.":"Bekerja diam-diam di latar belakang.","Internet: not reaching the internet":"Internet: tidak terhubung ke internet","Internet: checking…":"Internet: memeriksa…","waiting for the filter engine…":"menunggu mesin filter…","% of all queries · ":"% dari semua kueri · "," domains in your protection lists":" domain di daftar perlindungan Anda","Every bar is a slice of the week — taller means more ads blocked.":"Setiap batang adalah sebagian minggu — makin tinggi berarti makin banyak iklan diblokir.","The chart fills in as the week goes.":"Grafik terisi seiring berjalannya minggu.","That password doesn't match — try again.":"Kata sandi itu tidak cocok — coba lagi."," blocked":" diblokir","FilterBox — Settings":"FilterBox — Pengaturan","← Dashboard":"← Dasbor","Change password":"Ubah kata sandi","This is the password for the dashboard and the advanced view.":"Ini kata sandi untuk dasbor dan tampilan lanjutan.","Current password":"Kata sandi saat ini","New password (at least 8 characters)":"Kata sandi baru (minimal 8 karakter)","Repeat new password":"Ulangi kata sandi baru","Password updated.":"Kata sandi diperbarui.","Save new password":"Simpan kata sandi baru","Restart the box":"Nyalakan ulang kotak","Takes about a minute. Filtering pauses briefly while it restarts.":"Butuh sekitar satu menit. Pemfilteran berhenti sebentar saat kotak dinyalakan ulang.","Restart now":"Nyalakan ulang sekarang","Factory reset":"Reset pabrik","Reset this box…":"Reset kotak ini…","Type RESET to confirm":"Ketik RESET untuk konfirmasi","Dashboard password":"Kata sandi dasbor","Erase everything and reset":"Hapus semua dan reset","About":"Tentang","Panel version":"Versi panel","Filter engine":"Mesin filter","Uptime":"Waktu aktif","Address":"Alamat","Working…":"Memproses…","Please wait.":"Mohon tunggu.","Password must be at least 8 characters.":"Kata sandi harus minimal 8 karakter.","The two new passwords don’t match.":"Kedua kata sandi baru tidak sama.","Restart now? Tap again to confirm":"Nyalakan ulang sekarang? Ketuk lagi untuk konfirmasi","Restarting…":"Menyalakan ulang…","Back online.":"Online kembali.","This takes about a minute. Filtering pauses briefly while it restarts.":"Ini butuh sekitar satu menit. Pemfilteran berhenti sebentar saat kotak dinyalakan ulang.","Restarting the box":"Menyalakan ulang kotak","Still working…":"Masih memproses…","Reloading…":"Memuat ulang…","Type RESET exactly to confirm.":"Ketik RESET dengan tepat untuk konfirmasi.","Resetting the box":"Mereset kotak","Erasing settings and returning to setup mode — the box will restart.":"Menghapus pengaturan dan kembali ke mode penyiapan — kotak akan menyala ulang.","Back to setup — reloading…":"Kembali ke penyiapan — memuat ulang…"," d ":" hr ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"Kotak belum kembali. Pastikan kotak menyala, lalu muat ulang halaman ini.","Too many requests":"Terlalu banyak permintaan","Wait a minute, then ":"Tunggu satu menit, lalu ","reload the dashboard":"muat ulang dasbor","Nothing here":"Tidak ada apa-apa di sini","That page doesn't exist.":"Halaman itu tidak ada.","Back to FilterBox":"Kembali ke FilterBox","not found":"tidak ditemukan","Too many attempts — wait a minute.":"Terlalu banyak percobaan — tunggu satu menit.","Session expired — enter the password again.":"Sesi berakhir — masukkan kata sandi lagi.","Pick 30 minutes, 1 hour, or until you turn it back on.":"Pilih 30 menit, 1 jam, atau sampai Anda menyalakannya lagi.","Setup is already complete.":"Penyiapan sudah selesai.","That's not the current password — try again.":"Itu bukan kata sandi saat ini — coba lagi.","Password is too long (max 128 characters).":"Kata sandi terlalu panjang (maksimal 128 karakter).","Couldn't start the restart — check that the box is powered, then try again.":"Tidak bisa memulai penyalakan ulang — pastikan kotak menyala, lalu coba lagi.","Could not set the password (service not ready?). Try again in a moment.":"Tidak bisa menyetel kata sandi (layanan belum siap?). Coba lagi sebentar lagi.","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"Tidak ada adaptor Wi-Fi di kotak ini — kotak memakai Ethernet. Semua sudah siap.","Pick a network and enter its password (at least 8 chars).":"Pilih jaringan dan masukkan kata sandinya (minimal 8 karakter).","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"Tidak ada adaptor Wi-Fi di kotak ini — Ethernet adalah jalannya. Tidak ada yang perlu dilakukan.","Wi-Fi tools are not available on this box.":"Alat Wi-Fi tidak tersedia di kotak ini.","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"Pengaturan Wi-Fi tersimpan, tetapi alamatnya belum ada — beri satu menit lalu muat ulang halaman ini.","Set an admin password first.":"Setel kata sandi admin dulu.","Connected to ":"Terhubung ke ","Could not update Wi-Fi config: ":"Tidak bisa memperbarui konfigurasi Wi-Fi: ","queries today":"kueri hari ini"," blocked (":" diblokir (","answered from cache: ":"dijawab dari cache: "," · forwarded: ":" · diteruskan: ","Today":"Hari ini","Each bar is 10 minutes — the purple part was blocked.":"Setiap batang 10 menit — bagian ungu diblokir.","The chart fills in as the day goes.":"Grafik terisi seiring berjalannya hari.","Most visited today":"Paling banyak dikunjungi hari ini","Busiest devices":"Perangkat paling sibuk","Where answers came from":"Asal jawaban","Traffic mix":"Komposisi lalu lintas","Advanced view":"Tampilan lanjutan","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"Untuk pengguna mahir — dasbor teknis lengkap: log kueri, pengelolaan daftar blokir, dan pengaturan terperinci.","Open advanced view":"Buka tampilan lanjutan","Uses the same password as this page. Changes there affect filtering for the whole home.":"Memakai kata sandi yang sama dengan halaman ini. Perubahan di sana memengaruhi pemfilteran seluruh rumah.","Whole home":"Seluruh rumah","Covered — ":"Tercakup — "," devices seen on your network":" perangkat terlihat di jaringan Anda","Protection is paused — filtering is off.":"Perlindungan dijeda — pemfilteran mati.","Coverage paused — finishing network release…":"Cakupan dijeda — menyelesaikan pelepasan jaringan…","Protection starts as soon as setup is finished.":"Perlindungan mulai begitu penyiapan selesai.","Coverage is on — devices will appear as they browse.":"Cakupan aktif — perangkat akan muncul saat mereka menjelajah.","Coverage starting…":"Cakupan dimulai…","Coverage paused — the internet is open.":"Cakupan dijeda — internet terbuka.","Coverage is off.":"Cakupan mati.","Coverage has not started — check the box.":"Cakupan belum dimulai — periksa kotak.","Coverage status unavailable — check the box.":"Status cakupan tidak tersedia — periksa kotak.","Protection: starts after setup":"Perlindungan: mulai setelah penyiapan","Finish setup to switch protection on for the whole home.":"Selesaikan penyiapan untuk menyalakan perlindungan bagi seluruh rumah.","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"Penyiapan selesai. Perlindungan dinyalakan untuk seluruh rumah Anda — dasbor menampilkan kemajuannya.","Coverage status is out of date — check the box.":"Status cakupan sudah usang — periksa kotak.","Coverage unavailable on this network — contact support.":"Cakupan tidak tersedia di jaringan ini — hubungi dukungan.","Network release still finishing — check the box.":"Pelepasan jaringan masih berjalan — periksa kotak.","Coverage could not start — restart the box or contact support.":"Cakupan tidak bisa dimulai — nyalakan ulang kotak atau hubungi dukungan.","Internal error — try again.":"Kesalahan internal — coba lagi.","That network name is not supported — choose another network.":"Nama jaringan itu tidak didukung — pilih jaringan lain.","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"Menghapus kata sandi dasbor, pengaturan, dan statistik Anda. Pemfilteran tetap berjalan, dan pengaturan Wi-Fi tetap ada. Ini tidak bisa dibatalkan — jika Anda lupa kata sandi, tahan tombol RESET di kotak selama 5 detik.","Protection lists need attention — the box is repairing them.":"Daftar perlindungan perlu perhatian — kotak sedang memperbaikinya.","Filtering is on — coverage status unavailable.":"Pemfilteran aktif — status cakupan tidak tersedia.","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"Daftar perlindungan Anda masih disiapkan — biarkan kotak menyala dan terhubung, lalu coba lagi beberapa menit lagi.","Filtering is already running for your whole home.":"Pemfilteran sudah berjalan untuk seluruh rumah Anda.","Protection is starting — no action needed.":"Perlindungan mulai — tidak perlu tindakan.","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"Dasbor dan statistik bersifat opsional. Setel kata sandi untuk memakainya — jika tidak, cukup tutup halaman ini dan nikmati ketenangannya.","Set up the dashboard":"Siapkan dasbor","Choose your dashboard password":"Pilih kata sandi dasbor Anda","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"Ini melindungi dasbor dan tampilan lanjutan. Catat di tempat yang aman. Jika lupa, tahan tombol RESET di kotak selama 5 detik.","You're all set 🛡️":"Semua sudah siap 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"Pemfilteran sudah berjalan untuk seluruh rumah Anda — dasbor menunjukkan perkembangannya.","Queries today":"Kueri hari ini","Blocked":"Diblokir","Blocked share":"Porsi diblokir","ads and trackers":"iklan dan pelacak","lookups today":"pencarian hari ini","Each bar is 10 minutes · busiest:":"Setiap batang 10 menit · tersibuk:","since midnight":"sejak tengah malam","waiting for traffic":"menunggu lalu lintas","Queries":"Kueri","Keep the box updated automatically":"Jaga kotak tetap diperbarui secara otomatis","Security fixes and filtering improvements only — no personal data leaves the box.":"Hanya perbaikan keamanan dan peningkatan penyaringan — tidak ada data pribadi yang keluar dari kotak.","Share anonymous diagnostic reports":"Bagikan laporan diagnostik anonim","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"Log kesalahan dan pemeriksaan kesehatan yang membantu kami memperbaiki masalah. Tanpa riwayat penjelajahan, nama perangkat, atau data pribadi — hanya detail teknis anonim yang dikirim kepada kami secara pribadi.","Language":"Bahasa","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"Kotak ini tidak mengenali alamat tempat halaman ini dibuka. Buka http://filterbox.lan dan coba lagi.","Pause":"Jeda","This dashboard is private to your home. Enter the password you chose during setup.":"Dasbor ini bersifat pribadi untuk rumah Anda. Masukkan kata sandi yang Anda pilih saat penyiapan.","FilterBox — Sign in":"FilterBox — Masuk"," queries · ":" kueri · ","Wait a minute, then":"Tunggu sebentar, lalu "},"ko":{"FilterBox — Setup":"FilterBox — 설정","Your filter box is online 🎉":"필터 박스가 온라인입니다 🎉","Checking your setup…":"설정을 확인하는 중…","Protection…":"보호…","Internet…":"인터넷…","Get started":"시작하기","Choose your admin password":"관리자 비밀번호 선택","This protects your filter's settings page. Write it down somewhere safe.":"필터의 설정 페이지를 보호합니다. 안전한 곳에 적어 두세요.","Password (at least 8 characters)":"비밀번호 (8자 이상)","Repeat password":"비밀번호 확인","Save password":"비밀번호 저장","Internet connection":"인터넷 연결","Choose how this box reaches the internet.":"이 박스가 인터넷에 연결되는 방식을 선택하세요.","Ethernet":"이더넷","Scan for Wi-Fi networks":"Wi-Fi 네트워크 검색","Wi-Fi password":"Wi-Fi 비밀번호","Connect":"연결","Continue":"계속","All set! 🛡️":"모두 완료! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"이제 네트워크가 보호됩니다. 이 박스를 사용하는 모든 기기에서 광고와 추적기가 필터링됩니다.","Opening your dashboard…":"대시보드를 여는 중…","Open dashboard":"대시보드 열기","Setup already complete":"설치 이미 완료됨","This box has already been set up. Head to the dashboard to see how it's doing.":"이 박스는 이미 설정되었습니다. 대시보드에서 상태를 확인하세요.","· your data stays on this device":"· 데이터는 이 기기에 보관됩니다","Bad response":"잘못된 응답","Protection: active":"보호: 활성","Protection: warming up":"보호: 준비 중","Internet: connected":"인터넷: 연결됨","Internet: not yet":"인터넷: 아직 아님","This box: ":"이 박스: ","Good news — filtering is already working.":"좋은 소식입니다 — 필터링이 이미 작동 중입니다.","Almost there — let’s finish the quick setup.":"거의 다 됐습니다 — 빠른 설정을 마무리해요.","Ethernet: cable connected":"이더넷: 케이블 연결됨","Ethernet: no cable detected":"이더넷: 케이블 없음","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"이 박스에서 Wi-Fi를 사용할 수 있습니다 — Wi-Fi를 쓰거나 이더넷을 유지하세요.","This box filters through its network cable — nothing to configure here.":"이 박스는 네트워크 케이블로 필터링합니다 — 여기서 설정할 것은 없습니다.","Password needs at least 8 characters.":"비밀번호는 8자 이상이어야 합니다.","The two passwords don’t match.":"두 비밀번호가 일치하지 않습니다.","Something went wrong.":"문제가 발생했습니다.","Saving…":"저장 중…","Scanning…":"검색 중…","Scan again":"다시 검색","Password for “":"비밀번호: “","Connecting…":"연결 중…","Connected.":"연결되었습니다.","Could not connect.":"연결할 수 없습니다.","Not ready yet.":"아직 준비되지 않았습니다.","No networks found. Try again, or keep using Ethernet.":"네트워크를 찾지 못했습니다. 다시 시도하거나 이더넷을 계속 사용하세요.","Checking on your filter…":"필터 상태 확인 중…","Turn back on":"다시 켜기","blocked today":"오늘 차단됨","Last 7 days":"최근 7일","Top blocked today":"오늘 많이 차단된 항목","Warming up…":"준비 중…","Nothing blocked yet — enjoy the quiet.":"아직 차단된 항목이 없습니다 — 조용함을 즐기세요.","Pause filtering?":"필터링을 일시중지할까요?","Filtering will pause for a short break.":"잠시 동안 필터링이 중지됩니다.","Pause 30 minutes":"30분 중지","Pause 1 hour":"1시간 중지","Pause until I turn it back on":"다시 켤 때까지 중지","Cancel":"취소","Enter your dashboard password":"대시보드 비밀번호 입력","Password":"비밀번호","Settings":"설정","Tap to pause filtering":"탭하여 필터링 중지","Back in ":"복귀까지 ","Back in ~":"복귀까지 약 "," h ":"시간 "," min":"분","Could not reach the panel — reload in a moment.":"패널에 연결할 수 없습니다 — 잠시 후 새로고침하세요.","Too many requests — wait a minute.":"요청이 너무 많습니다 — 1분 기다리세요.","Something went wrong — try again.":"문제가 발생했습니다 — 다시 시도하세요.","Paused until you turn it back on.":"다시 켤 때까지 중지되었습니다.","Paused for 30 minutes.":"30분 동안 중지되었습니다.","Paused for 1 hour.":"1시간 동안 중지되었습니다.","Protection is back on.":"보호가 다시 켜졌습니다.","Paused until you turn it back on":"다시 켤 때까지 중지됨","Protection: paused":"보호: 중지됨","Protection: checking…":"보호: 확인 중…","Protection: needs attention":"보호: 주의 필요","Filter engine starting up — stats will appear shortly.":"필터 엔진 시작 중 — 통계가 곧 나타납니다.","Ad blocking seems off — try restarting the box, or contact support.":"광고 차단이 꺼진 것 같습니다 — 박스를 재시작하거나 지원팀에 문의하세요.","Working quietly in the background.":"백그라운드에서 조용히 작동 중입니다.","Internet: not reaching the internet":"인터넷: 연결되지 않음","Internet: checking…":"인터넷: 확인 중…","waiting for the filter engine…":"필터 엔진을 기다리는 중…","% of all queries · ":"전체 쿼리의 % · "," domains in your protection lists":"개의 도메인이 보호 목록에 있습니다","Every bar is a slice of the week — taller means more ads blocked.":"각 막대는 그 주의 한 조각입니다 — 높을수록 더 많은 광고가 차단된 것입니다.","The chart fills in as the week goes.":"주가 지나면서 차트가 채워집니다.","That password doesn't match — try again.":"비밀번호가 일치하지 않습니다 — 다시 시도하세요."," blocked":" 차단됨","FilterBox — Settings":"FilterBox — 설정","← Dashboard":"← 대시보드","Change password":"비밀번호 변경","This is the password for the dashboard and the advanced view.":"대시보드와 고급 보기에 사용하는 비밀번호입니다.","Current password":"현재 비밀번호","New password (at least 8 characters)":"새 비밀번호 (8자 이상)","Repeat new password":"새 비밀번호 확인","Password updated.":"비밀번호가 변경되었습니다.","Save new password":"새 비밀번호 저장","Restart the box":"박스 재시작","Takes about a minute. Filtering pauses briefly while it restarts.":"약 1분 걸립니다. 재시작하는 동안 필터링이 잠시 중지됩니다.","Restart now":"지금 재시작","Factory reset":"공장 초기화","Reset this box…":"이 박스 초기화…","Type RESET to confirm":"확인하려면 RESET 입력","Dashboard password":"대시보드 비밀번호","Erase everything and reset":"모두 지우고 초기화","About":"정보","Panel version":"패널 버전","Filter engine":"필터 엔진","Uptime":"가동 시간","Address":"주소","Working…":"처리 중…","Please wait.":"잠시 기다려 주세요.","Password must be at least 8 characters.":"비밀번호는 8자 이상이어야 합니다.","The two new passwords don’t match.":"새 비밀번호 두 개가 일치하지 않습니다.","Restart now? Tap again to confirm":"지금 재시작할까요? 확인하려면 다시 탭하세요","Restarting…":"재시작 중…","Back online.":"다시 온라인입니다.","This takes about a minute. Filtering pauses briefly while it restarts.":"약 1분 걸립니다. 재시작하는 동안 필터링이 잠시 중지됩니다.","Restarting the box":"박스 재시작 중","Still working…":"계속 처리 중…","Reloading…":"새로고침 중…","Type RESET exactly to confirm.":"확인하려면 RESET을 정확히 입력하세요.","Resetting the box":"박스 초기화 중","Erasing settings and returning to setup mode — the box will restart.":"설정을 지우고 설치 모드로 돌아갑니다 — 박스가 재시작됩니다.","Back to setup — reloading…":"설치로 돌아가는 중 — 새로고침…"," d ":"일 ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"박스가 아직 돌아오지 않았습니다. 전원이 켜져 있는지 확인한 뒤 이 페이지를 새로고침하세요.","Too many requests":"요청이 너무 많습니다","Wait a minute, then ":"1분 기다린 뒤 ","reload the dashboard":"대시보드를 새로고침하세요","Nothing here":"여기에는 아무것도 없습니다","That page doesn't exist.":"그 페이지는 존재하지 않습니다.","Back to FilterBox":"FilterBox로 돌아가기","not found":"찾을 수 없음","Too many attempts — wait a minute.":"시도가 너무 많습니다 — 1분 기다리세요.","Session expired — enter the password again.":"세션이 만료되었습니다 — 비밀번호를 다시 입력하세요.","Pick 30 minutes, 1 hour, or until you turn it back on.":"30분, 1시간 또는 다시 켤 때까지 중 선택하세요.","Setup is already complete.":"설정이 이미 완료되었습니다.","That's not the current password — try again.":"현재 비밀번호가 아닙니다 — 다시 시도하세요.","Password is too long (max 128 characters).":"비밀번호가 너무 깁니다 (최대 128자).","Couldn't start the restart — check that the box is powered, then try again.":"재시작을 시작할 수 없습니다 — 박스 전원을 확인한 뒤 다시 시도하세요.","Could not set the password (service not ready?). Try again in a moment.":"비밀번호를 설정할 수 없습니다 (서비스가 준비되지 않음?). 잠시 후 다시 시도하세요.","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"이 박스에는 Wi-Fi 어댑터가 없습니다 — 이더넷을 사용합니다. 모두 준비되었습니다.","Pick a network and enter its password (at least 8 chars).":"네트워크를 선택하고 비밀번호를 입력하세요 (8자 이상).","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"이 박스에는 Wi-Fi 어댑터가 없습니다 — 이더넷을 사용하세요. 여기서 할 일은 없습니다.","Wi-Fi tools are not available on this box.":"이 박스에서는 Wi-Fi 도구를 사용할 수 없습니다.","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"Wi-Fi 설정을 저장했지만 아직 주소가 없습니다 — 1분 정도 기다린 뒤 이 페이지를 새로고침하세요.","Set an admin password first.":"먼저 관리자 비밀번호를 설정하세요.","Connected to ":"연결됨: ","Could not update Wi-Fi config: ":"Wi-Fi 설정을 업데이트할 수 없습니다: ","queries today":"오늘의 쿼리"," blocked (":" 차단 (","answered from cache: ":"캐시에서 응답: "," · forwarded: ":" · 전달됨: ","Today":"오늘","Each bar is 10 minutes — the purple part was blocked.":"각 막대는 10분입니다 — 보라색 부분이 차단된 양입니다.","The chart fills in as the day goes.":"하루가 지나면서 차트가 채워집니다.","Most visited today":"오늘 가장 많이 방문한 곳","Busiest devices":"가장 활발한 기기","Where answers came from":"응답이 온 곳","Traffic mix":"트래픽 구성","Advanced view":"고급 보기","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"고급 사용자를 위한 전체 기술 대시보드: 쿼리 로그, 차단 목록 관리, 상세 설정.","Open advanced view":"고급 보기 열기","Uses the same password as this page. Changes there affect filtering for the whole home.":"이 페이지와 같은 비밀번호를 사용합니다. 그곳의 변경은 집 전체의 필터링에 영향을 줍니다.","Whole home":"집 전체","Covered — ":"보호됨 — "," devices seen on your network":"개의 기기가 네트워크에서 확인됨","Protection is paused — filtering is off.":"보호가 중지되었습니다 — 필터링이 꺼져 있습니다.","Coverage paused — finishing network release…":"보호 중지됨 — 네트워크 해제를 마무리하는 중…","Protection starts as soon as setup is finished.":"설정이 끝나면 바로 보호가 시작됩니다.","Coverage is on — devices will appear as they browse.":"보호가 켜졌습니다 — 기기가 인터넷을 사용하면 여기에 나타납니다.","Coverage starting…":"보호 시작 중…","Coverage paused — the internet is open.":"보호 중지됨 — 인터넷이 열려 있습니다.","Coverage is off.":"보호가 꺼져 있습니다.","Coverage has not started — check the box.":"보호가 시작되지 않았습니다 — 박스를 확인하세요.","Coverage status unavailable — check the box.":"보호 상태를 확인할 수 없습니다 — 박스를 확인하세요.","Protection: starts after setup":"보호: 설정 후 시작","Finish setup to switch protection on for the whole home.":"설정을 마치면 집 전체의 보호가 켜집니다.","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"설정 완료. 집 전체의 보호가 켜지는 중입니다 — 대시보드에서 진행 상황을 볼 수 있습니다.","Coverage status is out of date — check the box.":"보호 상태가 오래되었습니다 — 박스를 확인하세요.","Coverage unavailable on this network — contact support.":"이 네트워크에서는 보호를 사용할 수 없습니다 — 지원팀에 문의하세요.","Network release still finishing — check the box.":"네트워크 해제가 아직 진행 중입니다 — 박스를 확인하세요.","Coverage could not start — restart the box or contact support.":"보호를 시작할 수 없습니다 — 박스를 재시작하거나 지원팀에 문의하세요.","Internal error — try again.":"내부 오류 — 다시 시도하세요.","That network name is not supported — choose another network.":"지원되지 않는 네트워크 이름입니다 — 다른 네트워크를 선택하세요.","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"대시보드 비밀번호, 설정, 통계가 지워집니다. 필터링은 계속되고 Wi-Fi 설정은 유지됩니다. 되돌릴 수 없습니다 — 비밀번호를 잊으면 박스의 RESET 버튼을 5초 동안 누르세요.","Protection lists need attention — the box is repairing them.":"보호 목록에 주의가 필요합니다 — 박스가 복구 중입니다.","Filtering is on — coverage status unavailable.":"필터링이 켜져 있습니다 — 보호 상태를 확인할 수 없습니다.","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"보호 목록을 아직 준비 중입니다 — 박스의 전원과 연결을 유지한 뒤 몇 분 후 다시 시도하세요.","Filtering is already running for your whole home.":"집 전체에 필터링이 이미 작동 중입니다.","Protection is starting — no action needed.":"보호가 시작 중입니다 — 별도 작업이 필요 없습니다.","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"대시보드와 통계는 선택 사항입니다. 사용하려면 비밀번호를 설정하세요 — 아니면 이 페이지를 닫고 조용함을 즐기세요.","Set up the dashboard":"대시보드 설정","Choose your dashboard password":"대시보드 비밀번호 선택","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"대시보드와 고급 보기를 보호합니다. 안전한 곳에 적어 두세요. 잊으면 박스의 RESET 버튼을 5초 동안 누르세요.","You're all set 🛡️":"모두 준비되었습니다 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"집 전체에 필터링이 이미 작동 중입니다 — 대시보드에서 상태를 볼 수 있습니다.","Queries today":"오늘의 쿼리","Blocked":"차단됨","Blocked share":"차단 비율","ads and trackers":"광고 및 추적기","lookups today":"오늘의 조회","Each bar is 10 minutes · busiest:":"각 막대는 10분 · 가장 활발:","since midnight":"자정 이후","waiting for traffic":"트래픽 대기 중","Queries":"쿼리","Keep the box updated automatically":"박스를 자동으로 업데이트","Security fixes and filtering improvements only — no personal data leaves the box.":"보안 수정 및 필터링 개선만 — 어떤 개인 데이터도 박스 밖으로 나가지 않습니다.","Share anonymous diagnostic reports":"익명 진단 보고서 공유","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"문제를 해결하는 데 도움이 되는 오류 로그와 상태 점검. 방문 기록, 기기 이름, 개인 데이터는 포함되지 않으며 익명화된 기술 정보만 비공개로 전송됩니다.","Language":"언어","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"박스가 이 페이지를 연 주소를 인식하지 못했습니다. http://filterbox.lan 을 열고 다시 시도하세요.","Pause":"일시정지","This dashboard is private to your home. Enter the password you chose during setup.":"이 대시보드는 가정 전용입니다. 설정할 때 선택한 비밀번호를 입력하세요.","FilterBox — Sign in":"FilterBox — 로그인"," queries · ":" 쿼리 · ","Wait a minute, then":"1분 후에 "},"th":{"FilterBox — Setup":"FilterBox — ตั้งค่า","Your filter box is online 🎉":"กล่องกรองของคุณออนไลน์แล้ว 🎉","Checking your setup…":"กำลังตรวจสอบการตั้งค่า…","Protection…":"การป้องกัน…","Internet…":"อินเทอร์เน็ต…","Get started":"เริ่มต้น","Choose your admin password":"ตั้งรหัสผ่านผู้ดูแล","This protects your filter's settings page. Write it down somewhere safe.":"รหัสนี้ปกป้องหน้าตั้งค่าของกล่องกรอง จดไว้ในที่ปลอดภัย","Password (at least 8 characters)":"รหัสผ่าน (อย่างน้อย 8 ตัวอักษร)","Repeat password":"ยืนยันรหัสผ่าน","Save password":"บันทึกรหัสผ่าน","Internet connection":"การเชื่อมต่ออินเทอร์เน็ต","Choose how this box reaches the internet.":"เลือกวิธีที่กล่องนี้เชื่อมต่ออินเทอร์เน็ต","Ethernet":"อีเทอร์เน็ต","Scan for Wi-Fi networks":"ค้นหาเครือข่าย Wi-Fi","Wi-Fi password":"รหัสผ่าน Wi-Fi","Connect":"เชื่อมต่อ","Continue":"ต่อไป","All set! 🛡️":"เสร็จแล้ว! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"เครือข่ายของคุณได้รับการป้องกันแล้ว ระบบกำลังกรองโฆษณาและตัวติดตามให้ทุกอุปกรณ์ที่ใช้กล่องนี้","Opening your dashboard…":"กำลังเปิดแดชบอร์ด…","Open dashboard":"เปิดแดชบอร์ด","Setup already complete":"ตั้งค่าเสร็จแล้ว","This box has already been set up. Head to the dashboard to see how it's doing.":"กล่องนี้ตั้งค่าเรียบร้อยแล้ว ไปที่แดชบอร์ดเพื่อดูสถานะ","· your data stays on this device":"· ข้อมูลอยู่บนอุปกรณ์นี้","Bad response":"การตอบกลับผิดพลาด","Protection: active":"การป้องกัน: ทำงาน","Protection: warming up":"การป้องกัน: กำลังเตรียม","Internet: connected":"อินเทอร์เน็ต: เชื่อมต่อแล้ว","Internet: not yet":"อินเทอร์เน็ต: ยังไม่เชื่อมต่อ","This box: ":"กล่องนี้: ","Good news — filtering is already working.":"ข่าวดี — ระบบกรองทำงานอยู่แล้ว","Almost there — let’s finish the quick setup.":"อีกนิดเดียว — มาตั้งค่าแบบเร็วให้เสร็จกัน","Ethernet: cable connected":"อีเทอร์เน็ต: ต่อสายแล้ว","Ethernet: no cable detected":"อีเทอร์เน็ต: ไม่พบสาย","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"กล่องนี้มี Wi-Fi — ใช้ Wi-Fi หรือใช้อีเทอร์เน็ตต่อก็ได้","This box filters through its network cable — nothing to configure here.":"กล่องนี้กรองผ่านสายเครือข่าย — ไม่ต้องตั้งค่าอะไรตรงนี้","Password needs at least 8 characters.":"รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร","The two passwords don’t match.":"รหัสผ่านสองช่องไม่ตรงกัน","Something went wrong.":"เกิดข้อผิดพลาด","Saving…":"กำลังบันทึก…","Scanning…":"กำลังค้นหา…","Scan again":"ค้นหาอีกครั้ง","Password for “":"รหัสผ่านของ “","Connecting…":"กำลังเชื่อมต่อ…","Connected.":"เชื่อมต่อแล้ว","Could not connect.":"เชื่อมต่อไม่ได้","Not ready yet.":"ยังไม่พร้อม","No networks found. Try again, or keep using Ethernet.":"ไม่พบเครือข่าย ลองอีกครั้ง หรือใช้อีเทอร์เน็ตต่อไป","Checking on your filter…":"กำลังตรวจสอบกล่องกรอง…","Turn back on":"เปิดอีกครั้ง","blocked today":"ที่ถูกบล็อกวันนี้","Last 7 days":"7 วันที่ผ่านมา","Top blocked today":"ถูกบล็อกมากที่สุดวันนี้","Warming up…":"กำลังเตรียม…","Nothing blocked yet — enjoy the quiet.":"ยังไม่มีอะไรถูกบล็อก — ขอให้สงบสุข","Pause filtering?":"หยุดกรองชั่วคราว?","Filtering will pause for a short break.":"ระบบจะหยุดกรองชั่วครู่","Pause 30 minutes":"หยุด 30 นาที","Pause 1 hour":"หยุด 1 ชั่วโมง","Pause until I turn it back on":"หยุดจนกว่าจะเปิดอีกครั้ง","Cancel":"ยกเลิก","Enter your dashboard password":"ใส่รหัสผ่านแดชบอร์ด","Password":"รหัสผ่าน","Settings":"การตั้งค่า","Tap to pause filtering":"แตะเพื่อหยุดกรอง","Back in ":"กลับมาอีก ","Back in ~":"กลับมาอีกประมาณ "," h ":" ชม. "," min":" นาที","Could not reach the panel — reload in a moment.":"เข้าถึงแผงควบคุมไม่ได้ — โหลดใหม่ในอีกสักครู่","Too many requests — wait a minute.":"คำขอมากเกินไป — รอสักหนึ่งนาที","Something went wrong — try again.":"เกิดข้อผิดพลาด — ลองอีกครั้ง","Paused until you turn it back on.":"หยุดชั่วคราวจนกว่าจะเปิดอีกครั้ง","Paused for 30 minutes.":"หยุดชั่วคราว 30 นาที","Paused for 1 hour.":"หยุดชั่วคราว 1 ชั่วโมง","Protection is back on.":"การป้องกันกลับมาทำงานแล้ว","Paused until you turn it back on":"หยุดไว้จนกว่าจะเปิดอีกครั้ง","Protection: paused":"การป้องกัน: หยุดชั่วคราว","Protection: checking…":"การป้องกัน: กำลังตรวจสอบ…","Protection: needs attention":"การป้องกัน: ต้องตรวจสอบ","Filter engine starting up — stats will appear shortly.":"ระบบกรองกำลังเริ่มทำงาน — สถิติจะแสดงในอีกสักครู่","Ad blocking seems off — try restarting the box, or contact support.":"การบล็อกโฆษณาอาจปิดอยู่ — ลองรีสตาร์ทกล่อง หรือติดต่อฝ่ายสนับสนุน","Working quietly in the background.":"ทำงานเงียบ ๆ อยู่เบื้องหลัง","Internet: not reaching the internet":"อินเทอร์เน็ต: เชื่อมต่ออินเทอร์เน็ตไม่ได้","Internet: checking…":"อินเทอร์เน็ต: กำลังตรวจสอบ…","waiting for the filter engine…":"กำลังรอระบบกรอง…","% of all queries · ":"% ของคำขอทั้งหมด · "," domains in your protection lists":" โดเมนในรายการป้องกันของคุณ","Every bar is a slice of the week — taller means more ads blocked.":"แต่ละแท่งคือหนึ่งช่วงของสัปดาห์ — ยิ่งสูงยิ่งบล็อกโฆษณาได้มาก","The chart fills in as the week goes.":"กราฟจะค่อย ๆ เติมเต็มเมื่อสัปดาห์ดำเนินไป","That password doesn't match — try again.":"รหัสผ่านไม่ตรง — ลองอีกครั้ง"," blocked":" ที่ถูกบล็อก","FilterBox — Settings":"FilterBox — การตั้งค่า","← Dashboard":"← แดชบอร์ด","Change password":"เปลี่ยนรหัสผ่าน","This is the password for the dashboard and the advanced view.":"นี่คือรหัสผ่านสำหรับแดชบอร์ดและมุมมองขั้นสูง","Current password":"รหัสผ่านปัจจุบัน","New password (at least 8 characters)":"รหัสผ่านใหม่ (อย่างน้อย 8 ตัวอักษร)","Repeat new password":"ยืนยันรหัสผ่านใหม่","Password updated.":"อัปเดตรหัสผ่านแล้ว","Save new password":"บันทึกรหัสผ่านใหม่","Restart the box":"รีสตาร์ทกล่อง","Takes about a minute. Filtering pauses briefly while it restarts.":"ใช้เวลาประมาณหนึ่งนาที ระบบจะหยุดกรองชั่วครู่ระหว่างรีสตาร์ท","Restart now":"รีสตาร์ทเลย","Factory reset":"รีเซ็ตเป็นค่าโรงงาน","Reset this box…":"รีเซ็ตกล่องนี้…","Type RESET to confirm":"พิมพ์ RESET เพื่อยืนยัน","Dashboard password":"รหัสผ่านแดชบอร์ด","Erase everything and reset":"ลบทุกอย่างและรีเซ็ต","About":"เกี่ยวกับ","Panel version":"เวอร์ชันแผงควบคุม","Filter engine":"ระบบกรอง","Uptime":"เวลาทำงาน","Address":"ที่อยู่","Working…":"กำลังทำงาน…","Please wait.":"โปรดรอ","Password must be at least 8 characters.":"รหัสผ่านต้องมีอย่างน้อย 8 ตัวอักษร","The two new passwords don’t match.":"รหัสผ่านใหม่ทั้งสองช่องไม่ตรงกัน","Restart now? Tap again to confirm":"รีสตาร์ทเลยหรือไม่? แตะอีกครั้งเพื่อยืนยัน","Restarting…":"กำลังรีสตาร์ท…","Back online.":"กลับมาออนไลน์แล้ว","This takes about a minute. Filtering pauses briefly while it restarts.":"ใช้เวลาประมาณหนึ่งนาที ระบบจะหยุดกรองชั่วครู่ระหว่างรีสตาร์ท","Restarting the box":"กำลังรีสตาร์ทกล่อง","Still working…":"ยังทำงานอยู่…","Reloading…":"กำลังโหลดใหม่…","Type RESET exactly to confirm.":"พิมพ์ RESET ให้ตรงเพื่อยืนยัน","Resetting the box":"กำลังรีเซ็ตกล่อง","Erasing settings and returning to setup mode — the box will restart.":"กำลังลบการตั้งค่าและกลับสู่โหมดตั้งค่า — กล่องจะรีสตาร์ท","Back to setup — reloading…":"กลับสู่การตั้งค่า — กำลังโหลดใหม่…"," d ":" วัน ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"กล่องยังไม่กลับมา ตรวจสอบว่าเปิดไฟอยู่ แล้วโหลดหน้านี้ใหม่","Too many requests":"คำขอมากเกินไป","Wait a minute, then ":"รอสักหนึ่งนาที แล้ว","reload the dashboard":"โหลดแดชบอร์ดใหม่","Nothing here":"ไม่มีอะไรที่นี่","That page doesn't exist.":"ไม่มีหน้านี้","Back to FilterBox":"กลับไปที่ FilterBox","not found":"ไม่พบ","Too many attempts — wait a minute.":"พยายามมากเกินไป — รอสักหนึ่งนาที","Session expired — enter the password again.":"เซสชันหมดอายุ — ใส่รหัสผ่านอีกครั้ง","Pick 30 minutes, 1 hour, or until you turn it back on.":"เลือก 30 นาที 1 ชั่วโมง หรือจนกว่าจะเปิดอีกครั้ง","Setup is already complete.":"ตั้งค่าเสร็จเรียบร้อยแล้ว","That's not the current password — try again.":"ไม่ใช่รหัสผ่านปัจจุบัน — ลองอีกครั้ง","Password is too long (max 128 characters).":"รหัสผ่านยาวเกินไป (ไม่เกิน 128 ตัวอักษร)","Couldn't start the restart — check that the box is powered, then try again.":"เริ่มการรีสตาร์ทไม่ได้ — ตรวจสอบว่าเปิดไฟกล่องแล้ว ลองอีกครั้ง","Could not set the password (service not ready?). Try again in a moment.":"ตั้งรหัสผ่านไม่ได้ (บริการยังไม่พร้อม?) ลองอีกครั้งในอีกสักครู่","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"ไม่พบอะแดปเตอร์ Wi-Fi ในกล่องนี้ — ใช้สายอีเทอร์เน็ต ทุกอย่างพร้อมแล้ว","Pick a network and enter its password (at least 8 chars).":"เลือกเครือข่ายแล้วใส่รหัสผ่าน (อย่างน้อย 8 ตัวอักษร)","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"กล่องนี้ไม่มีอะแดปเตอร์ Wi-Fi — ใช้อีเทอร์เน็ต ไม่มีอะไรต้องทำตรงนี้","Wi-Fi tools are not available on this box.":"กล่องนี้ใช้เครื่องมือ Wi-Fi ไม่ได้","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"บันทึกการตั้งค่า Wi-Fi แล้ว แต่ยังไม่มีที่อยู่ — รอสักครู่แล้วโหลดหน้านี้ใหม่","Set an admin password first.":"ตั้งรหัสผ่านผู้ดูแลก่อน","Connected to ":"เชื่อมต่อกับ ","Could not update Wi-Fi config: ":"อัปเดตการตั้งค่า Wi-Fi ไม่ได้: ","queries today":"คำขอวันนี้"," blocked (":" ที่ถูกบล็อก (","answered from cache: ":"ตอบจากแคช: "," · forwarded: ":" · ส่งต่อ: ","Today":"วันนี้","Each bar is 10 minutes — the purple part was blocked.":"แต่ละแท่งคือ 10 นาที — ส่วนสีม่วงคือที่ถูกบล็อก","The chart fills in as the day goes.":"กราฟจะค่อย ๆ เติมเต็มเมื่อวันดำเนินไป","Most visited today":"เยี่ยมชมมากที่สุดวันนี้","Busiest devices":"อุปกรณ์ที่ใช้งานมากที่สุด","Where answers came from":"ที่มาของคำตอบ","Traffic mix":"สัดส่วนการรับส่ง","Advanced view":"มุมมองขั้นสูง","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"สำหรับผู้ใช้ขั้นสูง — แดชบอร์ดทางเทคนิคเต็มรูปแบบ: บันทึกคำขอ การจัดการรายการบล็อก และการตั้งค่าละเอียด","Open advanced view":"เปิดมุมมองขั้นสูง","Uses the same password as this page. Changes there affect filtering for the whole home.":"ใช้รหัสผ่านเดียวกับหน้านี้ การเปลี่ยนแปลงที่นั่นมีผลกับการกรองทั้งบ้าน","Whole home":"ทั้งบ้าน","Covered — ":"ครอบคลุม — "," devices seen on your network":" อุปกรณ์ที่พบในเครือข่ายของคุณ","Protection is paused — filtering is off.":"การป้องกันหยุดชั่วคราว — ระบบกรองปิดอยู่","Coverage paused — finishing network release…":"ความครอบคลุมหยุดชั่วคราว — กำลังปลดเครือข่ายให้เสร็จ…","Protection starts as soon as setup is finished.":"การป้องกันจะเริ่มทันทีที่ตั้งค่าเสร็จ","Coverage is on — devices will appear as they browse.":"ความครอบคลุมเปิดอยู่ — อุปกรณ์จะปรากฏเมื่อใช้งาน","Coverage starting…":"กำลังเริ่มความครอบคลุม…","Coverage paused — the internet is open.":"ความครอบคลุมหยุดชั่วคราว — อินเทอร์เน็ตเปิดอยู่","Coverage is off.":"ความครอบคลุมปิดอยู่","Coverage has not started — check the box.":"ความครอบคลุมยังไม่เริ่ม — ตรวจสอบกล่อง","Coverage status unavailable — check the box.":"ดูสถานะความครอบคลุมไม่ได้ — ตรวจสอบกล่อง","Protection: starts after setup":"การป้องกัน: เริ่มหลังตั้งค่า","Finish setup to switch protection on for the whole home.":"ตั้งค่าให้เสร็จเพื่อเปิดการป้องกันทั้งบ้าน","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"ตั้งค่าเสร็จแล้ว กำลังเปิดการป้องกันให้ทั้งบ้าน — แดชบอร์ดแสดงความคืบหน้า","Coverage status is out of date — check the box.":"สถานะความครอบคลุมล้าสมัย — ตรวจสอบกล่อง","Coverage unavailable on this network — contact support.":"ความครอบคลุมใช้ไม่ได้ในเครือข่ายนี้ — ติดต่อฝ่ายสนับสนุน","Network release still finishing — check the box.":"กำลังปลดเครือข่ายให้เสร็จ — ตรวจสอบกล่อง","Coverage could not start — restart the box or contact support.":"เริ่มความครอบคลุมไม่ได้ — รีสตาร์ทกล่องหรือติดต่อฝ่ายสนับสนุน","Internal error — try again.":"ข้อผิดพลาดภายใน — ลองอีกครั้ง","That network name is not supported — choose another network.":"ไม่รองรับชื่อเครือข่ายนี้ — เลือกเครือข่ายอื่น","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"ลบรหัสผ่านแดชบอร์ด การตั้งค่า และสถิติของคุณ ระบบกรองยังทำงานต่อ และการตั้งค่า Wi-Fi ยังอยู่ ย้อนกลับไม่ได้ — หากลืมรหัสผ่าน ให้กดปุ่ม RESET บนกล่องค้างไว้ 5 วินาที","Protection lists need attention — the box is repairing them.":"รายการป้องกันต้องตรวจสอบ — กล่องกำลังซ่อมแซม","Filtering is on — coverage status unavailable.":"ระบบกรองเปิดอยู่ — ดูสถานะความครอบคลุมไม่ได้","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"รายการป้องกันยังเตรียมอยู่ — ให้กล่องเสียบไฟและเชื่อมต่อไว้ แล้วลองอีกครั้งในไม่กี่นาที","Filtering is already running for your whole home.":"ระบบกรองทำงานทั้งบ้านอยู่แล้ว","Protection is starting — no action needed.":"การป้องกันกำลังเริ่ม — ไม่ต้องทำอะไร","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"แดชบอร์ดและสถิติเป็นทางเลือก ตั้งรหัสผ่านเพื่อใช้งาน — หรือปิดหน้านี้แล้วปล่อยให้สงบ","Set up the dashboard":"ตั้งค่าแดชบอร์ด","Choose your dashboard password":"ตั้งรหัสผ่านแดชบอร์ด","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"รหัสนี้ปกป้องแดชบอร์ดและมุมมองขั้นสูง จดไว้ในที่ปลอดภัย หากลืม ให้กดปุ่ม RESET บนกล่องค้างไว้ 5 วินาที","You're all set 🛡️":"พร้อมแล้ว 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"ระบบกรองทำงานทั้งบ้านอยู่แล้ว — แดชบอร์ดแสดงสถานะ","Queries today":"คำขอวันนี้","Blocked":"ถูกบล็อก","Blocked share":"สัดส่วนที่ถูกบล็อก","ads and trackers":"โฆษณาและตัวติดตาม","lookups today":"การค้นหาวันนี้","Each bar is 10 minutes · busiest:":"แต่ละแท่งคือ 10 นาที · มากที่สุด:","since midnight":"ตั้งแต่เที่ยงคืน","waiting for traffic":"กำลังรอทราฟฟิก","Queries":"คำขอ","Keep the box updated automatically":"อัปเดตกล่องโดยอัตโนมัติ","Security fixes and filtering improvements only — no personal data leaves the box.":"เฉพาะการแก้ไขด้านความปลอดภัยและการปรับปรุงการกรอง — ไม่มีข้อมูลส่วนบุคคลออกจากกล่อง","Share anonymous diagnostic reports":"แชร์รายงานการวินิจฉัยแบบไม่ระบุตัวตน","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"บันทึกข้อผิดพลาดและการตรวจสอบสุขภาพที่ช่วยให้เราแก้ไขปัญหา ไม่มีประวัติการเรียกดู ชื่ออุปกรณ์ หรือข้อมูลส่วนบุคคล — เฉพาะรายละเอียดทางเทคนิคที่ไม่ระบุตัวตน ส่งถึงเราเป็นการส่วนตัว","Language":"ภาษา","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"กล่องไม่รู้จักที่อยู่ที่ใช้เปิดหน้านี้ โปรดเปิด http://filterbox.lan แล้วลองอีกครั้ง","Pause":"หยุดชั่วคราว","This dashboard is private to your home. Enter the password you chose during setup.":"แดชบอร์ดนี้เป็นส่วนตัวสำหรับบ้านของคุณ ป้อนรหัสผ่านที่คุณตั้งไว้ตอนติดตั้ง","FilterBox — Sign in":"FilterBox — เข้าสู่ระบบ"," queries · ":" คำขอ · ","Wait a minute, then":"รอสักครู่ แล้ว"},"lo":{"FilterBox — Setup":"FilterBox — ຕັ້ງຄ່າ","Your filter box is online 🎉":"ກ່ອງກັ່ນຂອງທ່ານອອນລາຍແລ້ວ 🎉","Checking your setup…":"ກຳລັງກວດສອບການຕັ້ງຄ່າ…","Protection…":"ການປ້ອງກັນ…","Internet…":"ອິນເຕີເນັດ…","Get started":"ເລີ່ມຕົ້ນ","Choose your admin password":"ເລືອກລະຫັດຜ່ານຜູ້ດູແລ","This protects your filter's settings page. Write it down somewhere safe.":"ສິ່ງນີ້ປ້ອງກັນໜ້າຕັ້ງຄ່າຂອງກ່ອງກັ່ນ ຂຽນໄວ້ໃນບ່ອນປອດໄພ","Password (at least 8 characters)":"ລະຫັດຜ່ານ (ຢ່າງໜ້ອຍ 8 ຕົວອັກສອນ)","Repeat password":"ຢືນຢັນລະຫັດຜ່ານ","Save password":"ບັນທຶກລະຫັດຜ່ານ","Internet connection":"ການເຊື່ອມຕໍ່ອິນເຕີເນັດ","Choose how this box reaches the internet.":"ເລືອກວິທີທີ່ກ່ອງນີ້ເຊື່ອມຕໍ່ອິນເຕີເນັດ","Ethernet":"ອີເທີເນັດ","Scan for Wi-Fi networks":"ຄົ້ນຫາເຄືອຂ່າຍ Wi-Fi","Wi-Fi password":"ລະຫັດຜ່ານ Wi-Fi","Connect":"ເຊື່ອມຕໍ່","Continue":"ຕໍ່ໄປ","All set! 🛡️":"ສຳເລັດແລ້ວ! 🛡️","Your network is now protected. Adverts and trackers are being filtered for every device that uses this box.":"ເຄືອຂ່າຍຂອງທ່ານໄດ້ຮັບການປ້ອງກັນແລ້ວ ລະບົບກຳລັງກັ່ນໂຄສະນາ ແລະ ຕົວຕິດຕາມ ໃຫ້ທຸກອຸປະກອນທີ່ໃຊ້ກ່ອງນີ້","Opening your dashboard…":"ກຳລັງເປີດແດຊບອດ…","Open dashboard":"ເປີດແດຊບອດ","Setup already complete":"ຕັ້ງຄ່າສຳເລັດແລ້ວ","This box has already been set up. Head to the dashboard to see how it's doing.":"ກ່ອງນີ້ຖືກຕັ້ງຄ່າແລ້ວ ໄປທີ່ແດຊບອດເພື່ອເບິ່ງສະຖານະ","· your data stays on this device":"· ຂໍ້ມູນຢູ່ໃນອຸປະກອນນີ້","Bad response":"ການຕອບສະໜອງຜິດພາດ","Protection: active":"ການປ້ອງກັນ: ເປີດໃຊ້ງານ","Protection: warming up":"ການປ້ອງກັນ: ກຳລັງກະກຽມ","Internet: connected":"ອິນເຕີເນັດ: ເຊື່ອມຕໍ່ແລ້ວ","Internet: not yet":"ອິນເຕີເນັດ: ຍັງບໍ່ເຊື່ອມຕໍ່","This box: ":"ກ່ອງນີ້: ","Good news — filtering is already working.":"ຂ່າວດີ — ລະບົບກັ່ນກຳລັງເຮັດວຽກແລ້ວ","Almost there — let’s finish the quick setup.":"ອີກໜ້ອຍດຽວ — ມາຕັ້ງຄ່າແບບໄວໃຫ້ສຳເລັດ","Ethernet: cable connected":"ອີເທີເນັດ: ຕໍ່ສາຍແລ້ວ","Ethernet: no cable detected":"ອີເທີເນັດ: ບໍ່ພົບສາຍ","Wi-Fi is available on this box — you can use it, or keep Ethernet.":"ກ່ອງນີ້ມີ Wi-Fi — ໃຊ້ Wi-Fi ຫຼື ໃຊ້ອີເທີເນັດຕໍ່ໄປກໍໄດ້","This box filters through its network cable — nothing to configure here.":"ກ່ອງນີ້ກັ່ນຜ່ານສາຍເຄືອຂ່າຍ — ບໍ່ມີຫຍັງຕ້ອງຕັ້ງຄ່າຢູ່ນີ້","Password needs at least 8 characters.":"ລະຫັດຜ່ານຕ້ອງມີຢ່າງໜ້ອຍ 8 ຕົວອັກສອນ","The two passwords don’t match.":"ລະຫັດຜ່ານສອງອັນບໍ່ຕົງກັນ","Something went wrong.":"ເກີດຂໍ້ຜິດພາດ","Saving…":"ກຳລັງບັນທຶກ…","Scanning…":"ກຳລັງຄົ້ນຫາ…","Scan again":"ຄົ້ນຫາອີກຄັ້ງ","Password for “":"ລະຫັດຜ່ານຂອງ “","Connecting…":"ກຳລັງເຊື່ອມຕໍ່…","Connected.":"ເຊື່ອມຕໍ່ແລ້ວ","Could not connect.":"ເຊື່ອມຕໍ່ບໍ່ໄດ້","Not ready yet.":"ຍັງບໍ່ພ້ອມ","No networks found. Try again, or keep using Ethernet.":"ບໍ່ພົບເຄືອຂ່າຍ ລອງອີກຄັ້ງ ຫຼື ໃຊ້ອີເທີເນັດຕໍ່ໄປ","Checking on your filter…":"ກຳລັງກວດສອບກ່ອງກັ່ນ…","Turn back on":"ເປີດອີກຄັ້ງ","blocked today":"ຖືກບລັອກມື້ນີ້","Last 7 days":"7 ວັນຜ່ານມາ","Top blocked today":"ຖືກບລັອກຫຼາຍທີ່ສຸດມື້ນີ້","Warming up…":"ກຳລັງກະກຽມ…","Nothing blocked yet — enjoy the quiet.":"ຍັງບໍ່ມີຫຍັງຖືກບລັອກ — ຂໍໃຫ້ສະຫງົບສຸກ","Pause filtering?":"ຢຸດກັ່ນຊົ່ວຄາວ?","Filtering will pause for a short break.":"ລະບົບຈະຢຸດກັ່ນຊົ່ວຄາວ","Pause 30 minutes":"ຢຸດ 30 ນາທີ","Pause 1 hour":"ຢຸດ 1 ຊົ່ວໂມງ","Pause until I turn it back on":"ຢຸດຈົນກວ່າຈະເປີດອີກຄັ້ງ","Cancel":"ຍົກເລີກ","Enter your dashboard password":"ໃສ່ລະຫັດຜ່ານແດຊບອດ","Password":"ລະຫັດຜ່ານ","Settings":"ການຕັ້ງຄ່າ","Tap to pause filtering":"ແຕະເພື່ອຢຸດກັ່ນ","Back in ":"ກັບມາອີກ ","Back in ~":"ກັບມາອີກປະມານ "," h ":" ຊມ "," min":" ນາທີ","Could not reach the panel — reload in a moment.":"ເຂົ້າເຖິງແຜງຄວບຄຸມບໍ່ໄດ້ — ໂຫຼດໃໝ່ໃນໄວໆນີ້","Too many requests — wait a minute.":"ຄຳຮ້ອງຫຼາຍເກີນໄປ — ລໍຖ້າໜຶ່ງນາທີ","Something went wrong — try again.":"ເກີດຂໍ້ຜິດພາດ — ລອງອີກຄັ້ງ","Paused until you turn it back on.":"ຢຸດຊົ່ວຄາວຈົນກວ່າຈະເປີດອີກຄັ້ງ","Paused for 30 minutes.":"ຢຸດຊົ່ວຄາວ 30 ນາທີ","Paused for 1 hour.":"ຢຸດຊົ່ວຄາວ 1 ຊົ່ວໂມງ","Protection is back on.":"ການປ້ອງກັນກັບມາແລ້ວ","Paused until you turn it back on":"ຢຸດໄວ້ຈົນກວ່າຈະເປີດອີກຄັ້ງ","Protection: paused":"ການປ້ອງກັນ: ຢຸດຊົ່ວຄາວ","Protection: checking…":"ການປ້ອງກັນ: ກຳລັງກວດສອບ…","Protection: needs attention":"ການປ້ອງກັນ: ຕ້ອງກວດສອບ","Filter engine starting up — stats will appear shortly.":"ລະບົບກັ່ນກຳລັງເລີ່ມຕົ້ນ — ສະຖິຕິຈະສະແດງໃນໄວໆນີ້","Ad blocking seems off — try restarting the box, or contact support.":"ການບລັອກໂຄສະນາອາດປິດຢູ່ — ລອງຣີສະຕາດກ່ອງ ຫຼື ຕິດຕໍ່ຝ່າຍສະໜັບສະໜູນ","Working quietly in the background.":"ເຮັດວຽກງຽບໆຢູ່ເບື້ອງຫຼັງ","Internet: not reaching the internet":"ອິນເຕີເນັດ: ເຊື່ອມຕໍ່ອິນເຕີເນັດບໍ່ໄດ້","Internet: checking…":"ອິນເຕີເນັດ: ກຳລັງກວດສອບ…","waiting for the filter engine…":"ກຳລັງລໍຖ້າລະບົບກັ່ນ…","% of all queries · ":"% ຂອງຄຳຮ້ອງທັງໝົດ · "," domains in your protection lists":" ໂດເມນໃນລາຍການປ້ອງກັນຂອງທ່ານ","Every bar is a slice of the week — taller means more ads blocked.":"ແຕ່ລະແທ່ງແມ່ນສ່ວນໜຶ່ງຂອງອາທິດ — ສູງກວ່າໝາຍເຖິງບລັອກໂຄສະນາໄດ້ຫຼາຍກວ່າ","The chart fills in as the week goes.":"ເສັ້ນສະແດງຈະຄ່ອຍໆເຕັມເມື່ອອາທິດຜ່ານໄປ","That password doesn't match — try again.":"ລະຫັດຜ່ານບໍ່ຕົງ — ລອງອີກຄັ້ງ"," blocked":" ຖືກບລັອກ","FilterBox — Settings":"FilterBox — ການຕັ້ງຄ່າ","← Dashboard":"← ແດຊບອດ","Change password":"ປ່ຽນລະຫັດຜ່ານ","This is the password for the dashboard and the advanced view.":"ນີ້ແມ່ນລະຫັດຜ່ານສຳລັບແດຊບອດ ແລະ ມຸມມອງຂັ້ນສູງ","Current password":"ລະຫັດຜ່ານປັດຈຸບັນ","New password (at least 8 characters)":"ລະຫັດຜ່ານໃໝ່ (ຢ່າງໜ້ອຍ 8 ຕົວອັກສອນ)","Repeat new password":"ຢືນຢັນລະຫັດຜ່ານໃໝ່","Password updated.":"ອັບເດດລະຫັດຜ່ານແລ້ວ","Save new password":"ບັນທຶກລະຫັດຜ່ານໃໝ່","Restart the box":"ຣີສະຕາດກ່ອງ","Takes about a minute. Filtering pauses briefly while it restarts.":"ໃຊ້ເວລາປະມານໜຶ່ງນາທີ ລະບົບຈະຢຸດກັ່ນຊົ່ວຄາວລະຫວ່າງຣີສະຕາດ","Restart now":"ຣີສະຕາດດຽວນີ້","Factory reset":"ຣີເຊັດເປັນຄ່າໂຮງງານ","Reset this box…":"ຣີເຊັດກ່ອງນີ້…","Type RESET to confirm":"ພິມ RESET ເພື່ອຢືນຢັນ","Dashboard password":"ລະຫັດຜ່ານແດຊບອດ","Erase everything and reset":"ລຶບທຸກຢ່າງ ແລະ ຣີເຊັດ","About":"ກ່ຽວກັບ","Panel version":"ເວີຊັນແຜງຄວບຄຸມ","Filter engine":"ລະບົບກັ່ນ","Uptime":"ເວລາເຮັດວຽກ","Address":"ທີ່ຢູ່","Working…":"ກຳລັງເຮັດວຽກ…","Please wait.":"ກະລຸນາລໍຖ້າ","Password must be at least 8 characters.":"ລະຫັດຜ່ານຕ້ອງມີຢ່າງໜ້ອຍ 8 ຕົວອັກສອນ","The two new passwords don’t match.":"ລະຫັດຜ່ານໃໝ່ທັງສອງບໍ່ຕົງກັນ","Restart now? Tap again to confirm":"ຣີສະຕາດດຽວນີ້ບໍ? ແຕະອີກຄັ້ງເພື່ອຢືນຢັນ","Restarting…":"ກຳລັງຣີສະຕາດ…","Back online.":"ກັບມາອອນລາຍແລ້ວ","This takes about a minute. Filtering pauses briefly while it restarts.":"ໃຊ້ເວລາປະມານໜຶ່ງນາທີ ລະບົບຈະຢຸດກັ່ນຊົ່ວຄາວລະຫວ່າງຣີສະຕາດ","Restarting the box":"ກຳລັງຣີສະຕາດກ່ອງ","Still working…":"ຍັງເຮັດວຽກຢູ່…","Reloading…":"ກຳລັງໂຫຼດໃໝ່…","Type RESET exactly to confirm.":"ພິມ RESET ໃຫ້ຄືເພື່ອຢືນຢັນ","Resetting the box":"ກຳລັງຣີເຊັດກ່ອງ","Erasing settings and returning to setup mode — the box will restart.":"ກຳລັງລຶບການຕັ້ງຄ່າ ແລະ ກັບສູ່ໂໝດຕັ້ງຄ່າ — ກ່ອງຈະຣີສະຕາດ","Back to setup — reloading…":"ກັບສູ່ການຕັ້ງຄ່າ — ກຳລັງໂຫຼດໃໝ່…"," d ":" ວັນ ","The box hasn't come back yet. Check that it's powered on, then reload this page.":"ກ່ອງຍັງບໍ່ກັບມາ ກວດເບິ່ງວ່າເປີດໄຟຢູ່ ແລ້ວໂຫຼດໜ້ານີ້ໃໝ່","Too many requests":"ຄຳຮ້ອງຫຼາຍເກີນໄປ","Wait a minute, then ":"ລໍຖ້າໜຶ່ງນາທີ ແລ້ວ","reload the dashboard":"ໂຫຼດແດຊບອດໃໝ່","Nothing here":"ບໍ່ມີຫຍັງຢູ່ນີ້","That page doesn't exist.":"ບໍ່ມີໜ້ານີ້","Back to FilterBox":"ກັບໄປທີ່ FilterBox","not found":"ບໍ່ພົບ","Too many attempts — wait a minute.":"ພະຍາຍາມຫຼາຍເກີນໄປ — ລໍຖ້າໜຶ່ງນາທີ","Session expired — enter the password again.":"ເຊສຊັນໝົດອາຍຸ — ໃສ່ລະຫັດຜ່ານອີກຄັ້ງ","Pick 30 minutes, 1 hour, or until you turn it back on.":"ເລືອກ 30 ນາທີ, 1 ຊົ່ວໂມງ, ຫຼື ຈົນກວ່າຈະເປີດອີກຄັ້ງ","Setup is already complete.":"ຕັ້ງຄ່າສຳເລັດແລ້ວ","That's not the current password — try again.":"ບໍ່ແມ່ນລະຫັດຜ່ານປັດຈຸບັນ — ລອງອີກຄັ້ງ","Password is too long (max 128 characters).":"ລະຫັດຜ່ານຍາວເກີນໄປ (ສູງສຸດ 128 ຕົວອັກສອນ)","Couldn't start the restart — check that the box is powered, then try again.":"ເລີ່ມການຣີສະຕາດບໍ່ໄດ້ — ກວດເບິ່ງວ່າກ່ອງມີໄຟ ແລ້ວລອງອີກຄັ້ງ","Could not set the password (service not ready?). Try again in a moment.":"ຕັ້ງລະຫັດຜ່ານບໍ່ໄດ້ (ບໍລິການຍັງບໍ່ພ້ອມ?) ລອງອີກຄັ້ງໃນໄວໆນີ້","No Wi-Fi adapter detected on this box — it uses Ethernet. You are all set.":"ບໍ່ພົບອະແດັບເຕີ Wi-Fi ໃນກ່ອງນີ້ — ໃຊ້ອີເທີເນັດ ທຸກຢ່າງພ້ອມແລ້ວ","Pick a network and enter its password (at least 8 chars).":"ເລືອກເຄືອຂ່າຍ ແລ້ວໃສ່ລະຫັດຜ່ານ (ຢ່າງໜ້ອຍ 8 ຕົວອັກສອນ)","No Wi-Fi adapter on this box — Ethernet is the way. Nothing to do here.":"ກ່ອງນີ້ບໍ່ມີອະແດັບເຕີ Wi-Fi — ໃຊ້ອີເທີເນັດ ບໍ່ມີຫຍັງຕ້ອງເຮັດຢູ່ນີ້","Wi-Fi tools are not available on this box.":"ກ່ອງນີ້ໃຊ້ເຄື່ອງມື Wi-Fi ບໍ່ໄດ້","Saved the Wi-Fi settings, but no address yet — give it a minute and reload this page.":"ບັນທຶກການຕັ້ງຄ່າ Wi-Fi ແລ້ວ ແຕ່ຍັງບໍ່ມີທີ່ຢູ່ — ລໍຖ້າສັກຄູ່ ແລ້ວໂຫຼດໜ້ານີ້ໃໝ່","Set an admin password first.":"ຕັ້ງລະຫັດຜ່ານຜູ້ດູແລກ່ອນ","Connected to ":"ເຊື່ອມຕໍ່ກັບ ","Could not update Wi-Fi config: ":"ອັບເດດການຕັ້ງຄ່າ Wi-Fi ບໍ່ໄດ້: ","queries today":"ຄຳຮ້ອງມື້ນີ້"," blocked (":" ຖືກບລັອກ (","answered from cache: ":"ຕອບຈາກແຄຊ: "," · forwarded: ":" · ສົ່ງຕໍ່: ","Today":"ມື້ນີ້","Each bar is 10 minutes — the purple part was blocked.":"ແຕ່ລະແທ່ງແມ່ນ 10 ນາທີ — ສ່ວນສີມ່ວງແມ່ນຖືກບລັອກ","The chart fills in as the day goes.":"ເສັ້ນສະແດງຈະຄ່ອຍໆເຕັມເມື່ອວັນຜ່ານໄປ","Most visited today":"ເຂົ້າຊົມຫຼາຍທີ່ສຸດມື້ນີ້","Busiest devices":"ອຸປະກອນທີ່ໃຊ້ຫຼາຍທີ່ສຸດ","Where answers came from":"ຕົ້ນກຳເນີດຂອງຄຳຕອບ","Traffic mix":"ສັດສ່ວນການຈະລາຈອນ","Advanced view":"ມຸມມອງຂັ້ນສູງ","For advanced users — the full technical dashboard: query log, blocklist management and detailed settings.":"ສຳລັບຜູ້ໃຊ້ຂັ້ນສູງ — ແດຊບອດທາງເຕັກນິກເຕັມຮູບແບບ: ບັນທຶກຄຳຮ້ອງ, ການຈັດການລາຍການບລັອກ ແລະ ການຕັ້ງຄ່າລະອຽດ","Open advanced view":"ເປີດມຸມມອງຂັ້ນສູງ","Uses the same password as this page. Changes there affect filtering for the whole home.":"ໃຊ້ລະຫັດຜ່ານດຽວກັບໜ້ານີ້ ການປ່ຽນແປງຢູ່ນັ້ນມີຜົນກັບການກັ່ນທັງເຮືອນ","Whole home":"ທັງເຮືອນ","Covered — ":"ປົກຄຸມ — "," devices seen on your network":" ອຸປະກອນທີ່ພົບໃນເຄືອຂ່າຍຂອງທ່ານ","Protection is paused — filtering is off.":"ການປ້ອງກັນຢຸດຊົ່ວຄາວ — ລະບົບກັ່ນປິດຢູ່","Coverage paused — finishing network release…":"ຄວາມປົກຄຸມຢຸດຊົ່ວຄາວ — ກຳລັງປົດເຄືອຂ່າຍໃຫ້ສຳເລັດ…","Protection starts as soon as setup is finished.":"ການປ້ອງກັນຈະເລີ່ມທັນທີທີ່ຕັ້ງຄ່າແລ້ວ","Coverage is on — devices will appear as they browse.":"ຄວາມປົກຄຸມເປີດຢູ່ — ອຸປະກອນຈະປະກົດເມື່ອໃຊ້ງານ","Coverage starting…":"ກຳລັງເລີ່ມຄວາມປົກຄຸມ…","Coverage paused — the internet is open.":"ຄວາມປົກຄຸມຢຸດຊົ່ວຄາວ — ອິນເຕີເນັດເປີດຢູ່","Coverage is off.":"ຄວາມປົກຄຸມປິດຢູ່","Coverage has not started — check the box.":"ຄວາມປົກຄຸມຍັງບໍ່ເລີ່ມ — ກວດເບິ່ງກ່ອງ","Coverage status unavailable — check the box.":"ເບິ່ງສະຖານະຄວາມປົກຄຸມບໍ່ໄດ້ — ກວດເບິ່ງກ່ອງ","Protection: starts after setup":"ການປ້ອງກັນ: ເລີ່ມຫຼັງຕັ້ງຄ່າ","Finish setup to switch protection on for the whole home.":"ຕັ້ງຄ່າໃຫ້ສຳເລັດເພື່ອເປີດການປ້ອງກັນທັງເຮືອນ","Setup complete. Protection is switching on for your whole home — the dashboard shows its progress.":"ຕັ້ງຄ່າສຳເລັດ ກຳລັງເປີດການປ້ອງກັນໃຫ້ທັງເຮືອນ — ແດຊບອດສະແດງຄວາມຄືບໜ້າ","Coverage status is out of date — check the box.":"ສະຖານະຄວາມປົກຄຸມເກົ່າແລ້ວ — ກວດເບິ່ງກ່ອງ","Coverage unavailable on this network — contact support.":"ຄວາມປົກຄຸມໃຊ້ບໍ່ໄດ້ໃນເຄືອຂ່າຍນີ້ — ຕິດຕໍ່ຝ່າຍສະໜັບສະໜູນ","Network release still finishing — check the box.":"ກຳລັງປົດເຄືອຂ່າຍຍັງບໍ່ສຳເລັດ — ກວດເບິ່ງກ່ອງ","Coverage could not start — restart the box or contact support.":"ເລີ່ມຄວາມປົກຄຸມບໍ່ໄດ້ — ຣີສະຕາດກ່ອງ ຫຼື ຕິດຕໍ່ຝ່າຍສະໜັບສະໜູນ","Internal error — try again.":"ຂໍ້ຜິດພາດພາຍໃນ — ລອງອີກຄັ້ງ","That network name is not supported — choose another network.":"ບໍ່ຮອງຮັບຊື່ເຄືອຂ່າຍນີ້ — ເລືອກເຄືອຂ່າຍອື່ນ","Erases your dashboard password, settings and statistics. Filtering keeps running, and Wi-Fi settings stay. This cannot be undone — if you ever forget the password, hold the RESET button on the box for 5 seconds.":"ລຶບລະຫັດຜ່ານແດຊບອດ, ການຕັ້ງຄ່າ ແລະ ສະຖິຕິຂອງທ່ານ ລະບົບກັ່ນຍັງເຮັດວຽກຕໍ່ ແລະ ການຕັ້ງຄ່າ Wi-Fi ຍັງຢູ່ ຍ້ອນກັບບໍ່ໄດ້ — ຖ້າລືມລະຫັດຜ່ານ ໃຫ້ກົດປຸ່ມ RESET ເທິງກ່ອງຄ້າງໄວ້ 5 ວິນາທີ","Protection lists need attention — the box is repairing them.":"ລາຍການປ້ອງກັນຕ້ອງກວດສອບ — ກ່ອງກຳລັງສ້ອມແປງ","Filtering is on — coverage status unavailable.":"ລະບົບກັ່ນເປີດຢູ່ — ເບິ່ງສະຖານະຄວາມປົກຄຸມບໍ່ໄດ້","Your protection lists are still being prepared — keep the box powered and connected, then try again in a few minutes.":"ລາຍການປ້ອງກັນຍັງກະກຽມຢູ່ — ໃຫ້ກ່ອງເສັບໄຟ ແລະ ເຊື່ອມຕໍ່ໄວ້ ແລ້ວລອງອີກຄັ້ງໃນສອງສາມນາທີ","Filtering is already running for your whole home.":"ລະບົບກັ່ນເຮັດວຽກທັງເຮືອນຢູ່ແລ້ວ","Protection is starting — no action needed.":"ການປ້ອງກັນກຳລັງເລີ່ມ — ບໍ່ຕ້ອງເຮັດຫຍັງ","The dashboard and statistics are optional. Set a password to use them — otherwise just close this page and enjoy the quiet.":"ແດຊບອດ ແລະ ສະຖິຕິເປັນທາງເລືອກ ຕັ້ງລະຫັດຜ່ານເພື່ອໃຊ້ — ຫຼື ປິດໜ້ານີ້ແລ້ວປ່ອຍໃຫ້ສະຫງົບ","Set up the dashboard":"ຕັ້ງຄ່າແດຊບອດ","Choose your dashboard password":"ເລືອກລະຫັດຜ່ານແດຊບອດ","This protects the dashboard and the advanced view. Write it down somewhere safe. If you forget it, hold the RESET button on the box for 5 seconds.":"ສິ່ງນີ້ປ້ອງກັນແດຊບອດ ແລະ ມຸມມອງຂັ້ນສູງ ຂຽນໄວ້ໃນບ່ອນປອດໄພ ຖ້າລືມ ໃຫ້ກົດປຸ່ມ RESET ເທິງກ່ອງຄ້າງໄວ້ 5 ວິນາທີ","You're all set 🛡️":"ພ້ອມແລ້ວ 🛡️","Filtering is already running for your whole home — the dashboard shows how it's going.":"ລະບົບກັ່ນເຮັດວຽກທັງເຮືອນຢູ່ແລ້ວ — ແດຊບອດສະແດງສະຖານະ","Queries today":"ຄຳຮ້ອງມື້ນີ້","Blocked":"ຖືກບລັອກ","Blocked share":"ສັດສ່ວນທີ່ຖືກບລັອກ","ads and trackers":"ໂຄສະນາ ແລະ ຕົວຕິດຕາມ","lookups today":"ການຄົ້ນຫາມື້ນີ້","Each bar is 10 minutes · busiest:":"ແຕ່ລະແທ່ງແມ່ນ 10 ນາທີ · ຫຼາຍທີ່ສຸດ:","since midnight":"ຕັ້ງແຕ່ທ່ຽງຄືນ","waiting for traffic":"ກຳລັງລໍຖ້າການຈະລາຈອນ","Queries":"ຄຳຮ້ອງ","Keep the box updated automatically":"ອັບເດດກ່ອງໂດຍອັດຕະໂນມັດ","Security fixes and filtering improvements only — no personal data leaves the box.":"ແກ້ໄຂຄວາມປອດໄພ ແລະ ປັບປຸງການກັ່ນເທົ່ານັ້ນ — ບໍ່ມີຂໍ້ມູນສ່ວນຕົວອອກຈາກກ່ອງ","Share anonymous diagnostic reports":"ແບ່ງປັນລາຍງານການວິນິດໄສແບບບໍ່ລະບຸຕົວຕົນ","Error logs and health checks that help us fix problems. No browsing history, no device names, no personal data — only anonymised technical details, sent privately to us.":"ບັນທຶກຂໍ້ຜິດພາດ ແລະ ການກວດສຸຂະພາບທີ່ຊ່ວຍໃຫ້ພວກເຮົາແກ້ໄຂບັນຫາ. ບໍ່ມີປະຫວັດການທ່ອງເວັບ, ຊື່ອຸປະກອນ ຫຼື ຂໍ້ມູນສ່ວນຕົວ — ມີພຽງລາຍລະອຽດທາງເທັກນິກທີ່ບໍ່ລະບຸຕົວຕົນ, ສົ່ງມາຫາພວກເຮົາຢ່າງເປັນສ່ວນຕົວ.","Language":"ພາສາ","This box didn't recognise the address this page was opened from. Open http://filterbox.lan and try again.":"ກ່ອງບໍ່ຮູ້ຈັກທີ່ຢູ່ທີ່ໃຊ້ເປີດໜ້ານີ້. ເປີດ http://filterbox.lan ແລ້ວລອງອີກຄັ້ງ.","Pause":"ຢຸດຊົ່ວຄາວ","This dashboard is private to your home. Enter the password you chose during setup.":"ແດຊບອດນີ້ເປັນສ່ວນຕົວສຳລັບເຮືອນຂອງທ່ານ. ປ້ອນລະຫັດຜ່ານທີ່ທ່ານເລືອກໄວ້ຕອນຕັ້ງຄ່າ.","FilterBox — Sign in":"FilterBox — ເຂົ້າສູ່ລະບົບ"," queries · ":" ຄຳຖາມ · ","Wait a minute, then":"ລໍຖ້າສັກຄູ່ ແລ້ວ "}}""")

def trad(s, lang):
    """Translate one exact English string (server-side messages)."""
    return (I18N.get(lang) or {}).get(s, s)

def _req_lang(handler):
    """Pick the response language: ?lang= > cookie > Accept-Language > en."""
    from urllib.parse import parse_qs
    q = parse_qs(urlparse(handler.path).query)
    lp = (q.get('lang') or [''])[0].strip().lower()
    if lp in LANGS:
        return lp, True
    m = re.search(r'(?:^|;\s*)%s=([a-zA-Z]{2})(?:;|$)' % LANG_COOKIE,
                  handler.headers.get('Cookie', '') or '')
    if m and m.group(1).lower() in LANGS:
        return m.group(1).lower(), False
    for part in (handler.headers.get('Accept-Language', '') or '').split(','):
        base = part.split(';')[0].strip().lower().replace('_', '-').split('-')[0]
        if base == 'iw':
            base = 'he'
        if base in LANGS:
            return base, False
    return 'en', False

_LANG_CSS = ('<style>'
             '.fb-lang{max-width:520px;margin:10px auto 26px;text-align:center;font-size:13.5px;color:#9aa3bb;'
             'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Inter,"Noto Sans",sans-serif}'
             '.fb-lang a{color:#9aa3bb;text-decoration:none;padding:4px 8px}'
             '.fb-lang b a{color:#5b8cff;font-weight:650}'
             '.langpick{display:flex;gap:8px;margin:12px 0 2px}\n.langsel{width:100%;appearance:none;background:#0e1428 url(\'data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"12\" height=\"8\"><path d=\"M1 1l5 5 5-5\" stroke=\"%239aa3bb\" stroke-width=\"1.6\" fill=\"none\"/></svg>\') no-repeat right 14px center;color:#eef1f8;border:1px solid var(--line);border-radius:12px;padding:11px 36px 11px 12px;font-size:14.5px}\n.langsel:focus{outline:none;border-color:var(--acc)}'
             '.langpick a{flex:1;text-align:center;padding:11px 6px;border-radius:12px;border:1px solid var(--line);'
             'background:#0e1428;color:var(--ink);text-decoration:none;font-size:14.5px}'
             '.langpick a.on{border-color:var(--acc);color:#fff;font-weight:650;'
             'background:linear-gradient(100deg,rgba(91,140,255,.22),rgba(138,91,255,.22))}'
             '[dir=rtl] .gear{right:auto;left:0}'
             '[dir=rtl] .row b{text-align:left}'
             '[dir=rtl] #login-sheet .sheet-card{text-align:right}'
             '</style>')

def tl(html, lang):
    """Language layer for full pages: lang/dir attr, string table, switcher."""
    if lang != 'en':
        tbl = I18N.get(lang) or {}
        for en in sorted(tbl, key=len, reverse=True):
            pat = re.escape(en)
            if en[0].isascii() and en[0].isalpha():
                pat = r'(?<![A-Za-z])' + pat
            if en[-1].isascii() and en[-1].isalpha():
                pat = pat + r'(?![A-Za-z])'
            html = re.sub(pat, lambda m, x=tbl[en]: x, html)
        attr = 'lang="%s" dir="rtl"' % lang if lang in RTL_LANGS else 'lang="%s"' % lang
        html = html.replace('<html lang="en">', '<html ' + attr + '>', 1)
    opts = ''.join('<option value="%s"%s>%s</option>' % (c, ' selected' if c == lang else '', lab)
                   for c, lab in LANG_LABELS)
    sel = ('<select class="langsel" aria-label="%s" '
           'onchange="if(window.fbLangChange){fbLangChange(this)}else{location.href=\'?lang=\'+this.value}">%s</select>'
           % (trad('Language', lang), opts))
    html = html.replace('<!--FB-LANG-PICK-->', sel, 1)
    # Wizard pages carry the picker at the top; other pages keep the footer switcher.
    footer = '' if 'class="langsel"' in html else '<div class="fb-lang">%s</div>' % sel
    html = html.replace('</body>', footer + _LANG_CSS + '</body>', 1)
    return html

class H(BaseHTTPRequestHandler):
    server_version = 'FilterBox'
    sys_version = ''
    timeout = 20            # idle/slowloris sockets cannot pin a thread forever
    def log_message(self, format, *args):
        line = args[0] if args else ''
        # The watchdog probes /api/health every few seconds; logging every poll
        # fills the 50 MB tmpfs with noise. Keep real requests only.
        if '/api/health' in str(line) or '/favicon.ico' in str(line):
            return
        log(f'{self.client_address[0]} {format % args}')

    def _send(self, code, body, ctype='application/json', extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body)
        data = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Permissions-Policy', 'geolocation=(), microphone=(), camera=()')
        self.send_header('Content-Security-Policy',
                         "default-src 'self'; script-src 'self' 'unsafe-inline'; "
                         "style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                         "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        try: self.wfile.write(data)
        except Exception: pass

    def _page_send(self, body, code=200):
        # Version is baked into the page: a JS race (or a hidden card) must never
        # leave the footer reading "FilterBox v" with no number.
        body = body.replace('<span id="ver"></span>', '<span id="ver">%s</span>' % VERSION)
        lang, from_q = _req_lang(self)
        extra = {'Set-Cookie': '%s=%s; Path=/; Max-Age=31536000; SameSite=Lax'
                 % (LANG_COOKIE, lang)} if from_q else None
        return self._send(code, tl(body, lang), 'text/html; charset=utf-8', extra)

    def _cookie_token(self):
        raw = self.headers.get('Cookie', '')
        m = re.search(r'(?:^|;\s*)%s=([0-9a-f]{16,})' % SESSION_COOKIE, raw)
        return m.group(1) if m else ''

    def _origin_ok(self):
        return origin_ok(self.headers.get('Host'), self.headers.get('Origin'),
                         self.headers.get('Sec-Fetch-Site'))

    def _authed(self):
        """CSRF double-submit + session check for panel action POSTs."""
        tok = self.headers.get('X-FB-Token', '') or ''
        if not tok or tok != self._cookie_token():
            return False
        return session_check(tok, self.client_address[0])

    def _session_ok(self):
        """Cookie-only session check for read-only dashboard data."""
        tok = self._cookie_token()
        return bool(tok) and session_check(tok, self.client_address[0])

    def _dashboard_mode(self):
        return (os.path.exists(DONE_MARKER)
                and not os.path.exists(RESET_STATE)
                and not os.path.exists(NEEDS_SETUP))

    def _throttle(self, limit=240):
        ip = ip_key(self.client_address[0]); now = time.time()
        with _lock:
            arr = [t for t in _rl.get(ip, []) if now - t < 60]
            if len(arr) >= limit: return False
            arr.append(now); _rl[ip] = arr
            if len(_rl) > 2048:
                for k in list(_rl)[:1024]:
                    if not _rl.get(k):
                        _rl.pop(k, None)
        return True

    def _body(self):
        try:
            n = int(self.headers.get('Content-Length', '0'))
            if n <= 0 or n > 4096: return {}
            return json.loads(self.rfile.read(n))
        except Exception:
            return {}

    def _login_page(self, next_path):
        safe = next_path if next_path in ('/', '/settings') else '/'
        return LOGIN_PAGE.replace('__NEXT__', json.dumps(safe))

    def do_GET(self):
        p = urlparse(self.path).path
        # Setup mode is short-lived and PIN/rate-limited per client; the global
        # 240/min bucket let one /64 neighbour deny the owner's correct PIN and
        # even the setup page. Throttle only the dashboard surface.
        if self._dashboard_mode() and not self._throttle():
            if p.startswith('/api/'):
                return self._send(429, {'ok': False, 'error': trad('Too many requests — wait a minute.', _req_lang(self)[0])})
            return self._page_send(LIMIT_PAGE, 429)
        # Setup-mode status is expensive (two DNS probes, per-interface calls);
        # cap it per client so one LAN host cannot hold every worker thread.
        if not self._dashboard_mode() and p in ('/api/status', '/api/wifi/scan') \
                and not self._throttle(60):
            return self._send(429, {'ok': False, 'error': trad('Too many requests — wait a minute.', _req_lang(self)[0])})
        if p == '/':
            if not self._dashboard_mode():
                mark_setup_active()
                return self._page_send(PAGE)
            # The dashboard is owner-only: do not render it (or any stats) to
            # an unauthenticated LAN client. A full-page login is the gate.
            if not self._session_ok():
                return self._page_send(self._login_page('/'))
            return self._page_send(DASH_PAGE)
        if p == '/settings':
            if not self._dashboard_mode():
                return self._send(302, b'', 'text/html; charset=utf-8', {'Location': '/'})
            if not self._session_ok():
                return self._page_send(self._login_page('/settings'))
            return self._page_send(SETTINGS_PAGE)
        if p == '/admin':
            return self._send(302, b'', 'text/html; charset=utf-8', {'Location': '/'})
        if p == '/api/panel/stats':
            # Unclaimed box = no dashboard = no statistics on the LAN.
            if not self._dashboard_mode():
                return self._send(404, {'ok': False, 'error': 'not found'})
            # Browsing statistics are private to the owner: no anonymous LAN read.
            if not self._session_ok():
                return self._send(401, {'ok': False, 'code': 'auth',
                                        'error': trad('Session expired — enter the password again.', _req_lang(self)[0])})
            return self._send(200, panel_stats())
        if p == '/api/status': return self._send(200, json_state())
        if p == '/api/wifi/scan':
            ok, err, nets = wifi_scan()
            return self._send(200, {'ok': True, 'networks': nets} if ok else {'ok': False, 'error': trad(err, _req_lang(self)[0]), 'networks': nets})
        if p == '/api/health': return self._send(200, {'ok': True, 'version': VERSION})
        if p == '/api/ping':
            if not self._dashboard_mode():
                mark_setup_active()
            return self._send(200, {'ok': True})
        if p == '/favicon.ico': return self._send(204, b'')
        if p.startswith('/api/'):
            return self._send(404, {'ok': False, 'error': 'not found'})
        return self._page_send(NOT_FOUND_PAGE, 404)

    def do_POST(self):
        p = urlparse(self.path).path
        if self._dashboard_mode() and not self._throttle(): return self._send(429, {'ok': False, 'error': trad('Too many requests — wait a minute.', _req_lang(self)[0])})
        b = self._body()
        try:
            if p.startswith('/api/panel/'):
                if not self._dashboard_mode():
                    return self._send(404, {'ok': False, 'error': 'not found'})
                if not self._origin_ok():
                    log(f'origin rejected for {p}: host={self.headers.get("Host")} origin={self.headers.get("Origin")}')
                    return self._send(403, {'ok': False, 'error': trad('This box didn\'t recognise the address this page was opened from. Open http://filterbox.lan and try again.', _req_lang(self)[0])})
                ip = self.client_address[0]
                if p == '/api/panel/login':
                    if login_blocked(ip):
                        return self._send(429, {'ok': False, 'error': trad('Too many attempts — wait a minute.', _req_lang(self)[0])})
                    if _ftl_auth_pw(b.get('password')) or \
                       (_ftl_auth_transport_error and _secret_matches(b.get('password'))):
                        login_ok(ip)
                        if isinstance(b.get('password'), str):
                            _write_secret(b['password'])   # refresh the credential copy (self-heal)
                        tok = new_session(ip)
                        return self._send(200, {'ok': True, 'token': tok},
                                          extra={'Set-Cookie': f'{SESSION_COOKIE}={tok}; HttpOnly; SameSite=Strict; Path=/; Max-Age={SESSION_TTL}'})
                    login_failed(ip)
                    return self._send(401, {'ok': False, 'code': 'auth', 'error': trad("That password doesn't match — try again.", _req_lang(self)[0])})
                if not self._authed():
                    return self._send(401, {'ok': False, 'code': 'auth', 'error': trad('Session expired — enter the password again.', _req_lang(self)[0])})
                tok = self._cookie_token()
                if p == '/api/panel/logout':
                    session_drop(tok)
                    return self._send(200, {'ok': True}, extra={'Set-Cookie': f'{SESSION_COOKIE}=; Max-Age=0; Path=/'})
                if p == '/api/panel/pause':
                    m = b.get('minutes')
                    if m == 'indefinite':
                        timer = None
                    elif m in (30, 60):
                        timer = int(m) * 60
                    else:
                        return self._send(400, {'ok': False, 'error': trad('Pick 30 minutes, 1 hour, or until you turn it back on.', _req_lang(self)[0])})
                    ftl_set_blocking(False, timer)
                    stats_invalidate()
                    log(f'pause via panel: {m}')
                    return self._send(200, {'ok': True})
                if p == '/api/panel/resume':
                    ftl_set_blocking(True)
                    stats_invalidate()
                    log('resume via panel')
                    return self._send(200, {'ok': True})
                if p == '/api/panel/password':
                    ok, err = change_password(b.get('current'), b.get('new'))
                    return self._send(200, {'ok': ok, 'error': trad(err, _req_lang(self)[0])} if not ok else {'ok': True})
                if p == '/api/panel/reboot':
                    ok, err = do_reboot()
                    return self._send(200, {'ok': ok, 'error': trad(err, _req_lang(self)[0])} if not ok else {'ok': True})
                if p == '/api/panel/reset':
                    ok, err = factory_reset(b.get('password'), b.get('confirm'))
                    return self._send(200, {'ok': ok, 'error': trad(err, _req_lang(self)[0])} if not ok else {'ok': True})
                return self._send(404, {'ok': False, 'error': 'not found'})
            if self._dashboard_mode():
                # A claimed box has no unauthenticated writes — including the
                # legacy /api/finish "repair" path (it could disable signed
                # updates / enable diagnostics on the whole fleet).
                return self._send(403, {'ok': False, 'error': trad('Setup is already complete.', _req_lang(self)[0])})
            if not self._origin_ok():
                log(f'origin rejected for setup {p}: host={self.headers.get("Host")} origin={self.headers.get("Origin")}')
                return self._send(403, {'ok': False, 'error': trad('This box didn\'t recognise the address this page was opened from. Open http://filterbox.lan and try again.', _req_lang(self)[0])})
            if setup_rate_limited(self.client_address[0]):
                return self._send(429, {'ok': False, 'error': trad('Too many requests — wait a minute.', _req_lang(self)[0])})
            if p == '/api/password':
                mark_setup_active()
                ok, err = set_password(b.get('password'))
                return self._send(200, {'ok': ok, 'error': trad(err, _req_lang(self)[0])} if not ok else {'ok': True})
            if p == '/api/wifi/connect':
                ok, msg = wifi_connect(str(b.get('ssid', '')), b.get('psk'))
                return self._send(200, {'ok': ok, 'message': trad(msg, _req_lang(self)[0])} if ok else {'ok': False, 'error': trad(msg, _req_lang(self)[0])})
            if p == '/api/finish':
                mark_setup_active()
                set_updates_enabled(bool(b.get('updates', True)))
                set_diag_enabled(bool(b.get('diagnostics', False)))
                ok, err = finish(self.client_address[0])
                return self._send(200, {'ok': ok, 'error': trad(err, _req_lang(self)[0])} if not ok else {'ok': True})
        except Exception as e:
            log(f'handler error {p}: {e}')
            return self._send(500, {'ok': False, 'error': trad('Internal error — try again.', _req_lang(self)[0])})
        return self._send(404, {'ok': False, 'error': 'not found'})

class Srv(ThreadingHTTPServer):
    daemon_threads = True
    address_family = socket.AF_INET6
    _sem = threading.BoundedSemaphore(64)
    _held = set()
    def process_request(self, request, client_address):
        # Bounded concurrency: slowloris-style clients must not create arbitrary
        # threads on a 1 GB box. LOOPBACK IS EXEMPT: the watchdog probe must never
        # compete with (or be starved by) hostile LAN sockets.
        loop = client_address[0] in ('127.0.0.1', '::1', '::ffff:127.0.0.1')
        got = self._sem.acquire(blocking=False)
        if got:
            self._held.add(id(request))
        if not got and not loop:
            self.shutdown_request(request)
            return
        super().process_request(request, client_address)
    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            if id(request) in self._held:
                self._held.discard(id(request))
                try: self._sem.release()
                except Exception: pass
    def server_bind(self):
        try: self.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
        except Exception: pass
        super().server_bind()

class Srv4(ThreadingHTTPServer):
    daemon_threads = True   # IPv4-only fallback (no IPv6 stack, e.g. minimal containers)
    _sem = threading.BoundedSemaphore(64)
    _held = set()
    def process_request(self, request, client_address):
        loop = client_address[0] in ('127.0.0.1', '::1', '::ffff:127.0.0.1')
        got = self._sem.acquire(blocking=False)
        if got:
            self._held.add(id(request))
        if not got and not loop:
            self.shutdown_request(request)
            return
        super().process_request(request, client_address)
    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            if id(request) in self._held:
                self._held.discard(id(request))
                try: self._sem.release()
                except Exception: pass

def sd_notify(msg):
    addr = os.environ.get('NOTIFY_SOCKET')
    if not addr:
        return
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        s.connect(addr)
        s.sendall(msg.encode())
        s.close()
    except Exception:
        pass

def _server_probe():
    """Prove the accept/response path works — a heartbeat thread that pings
    without touching the server would happily feed the watchdog while the
    listener is wedged."""
    try:
        s = socket.create_connection(('127.0.0.1', PORT), timeout=3)
        s.sendall(b'GET /api/health HTTP/1.0\r\nHost: filterbox.local\r\n\r\n')
        data = s.recv(64)
        s.close()
        return b' 200 ' in data.split(b'\r\n', 1)[0]
    except Exception:
        return False

def _heartbeat():
    """Keep systemd's watchdog fed only while the HTTP server actually answers."""
    while True:
        if _server_probe():
            sd_notify('WATCHDOG=1')
        time.sleep(10)

def main():
    if '--check' in sys.argv:
        print(json.dumps(json_state(), indent=1)); return 0
    mode = 'dashboard' if (os.path.exists(DONE_MARKER)
                           and not os.path.exists(RESET_STATE)
                           and not os.path.exists(NEEDS_SETUP)) else 'setup'
    log(f'panel starting on :{PORT} (version {VERSION}, mode={mode})')
    try:
        srv = Srv(('::', PORT), H)
    except OSError as e:
        log(f'IPv6 bind unavailable ({e}) — falling back to IPv4')
        srv = Srv4(('0.0.0.0', PORT), H)
    threading.Thread(target=_heartbeat, daemon=True).start()
    sd_notify('READY=1')
    log('panel ready')
    try: srv.serve_forever()
    except KeyboardInterrupt: pass
    return 0

if __name__ == '__main__':
    sys.exit(main())
