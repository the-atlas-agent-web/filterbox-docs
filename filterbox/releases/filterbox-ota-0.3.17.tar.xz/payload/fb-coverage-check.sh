#!/usr/bin/env bash
# fb-coverage-check.sh — read-only truth check for a live FilterBox.
# Usage: sudo bash fb-coverage-check.sh
# Prints key=value lines; exit 0 only when the main LAN is actually covered.
set -u
OK=1
say(){ printf '%s=%s\n' "$1" "$2"; }

CV=/run/fb-cover/state.json
CV6=/run/fb-cover6/state.json
IFACE=$(ip route show default 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | head -n1)
GW=$(ip route show default 2>/dev/null | sed -n 's/.* via \([^ ]*\).*/\1/p' | head -n1)
[ -n "$IFACE" ] || { say overall no-lan-interface; exit 1; }
say iface "$IFACE"
say gateway "${GW:-none}"

# IPv4 claim: the box must be the gateway's neighbour entry.
if [ -n "$GW" ]; then
  OWN=$(cat "/sys/class/net/$IFACE/address" 2>/dev/null)
  NM=$(ip neigh show "$GW" dev "$IFACE" 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="lladdr") print $(i+1)}')
  say gateway_mac "${NM:-none}"
  say own_mac "${OWN:-none}"
  # From the box itself the gateway neighbour is the router; verify the claim
  # from a client with: ip neigh show 192.168.50.1
  if [ -n "$OWN" ] && [ "$NM" = "$OWN" ]; then say ipv4_gateway ok; else say ipv4_gateway not-verifiable-from-box; fi
fi

# Kernel forwarding and DNS capture rules.
say ip_forward "$(cat /proc/sys/net/ipv4/ip_forward 2>/dev/null || echo unknown)"
if iptables -w 5 -t nat -C FBNAT -p udp --dport 53 -j REDIRECT --to-ports 53 2>/dev/null; then
  say dns_capture ok
else
  say dns_capture missing; OK=0
fi

# Coverage state freshness.
if [ -f "$CV" ]; then
  ST=$(python3 -c 'import json,sys,time;d=json.load(open(sys.argv[1]));print(d.get("state","?"), int(time.time())-int(d.get("ts",0) or 0))' "$CV" 2>/dev/null)
  set -- $ST
  say ipv4_state "${1:-?}"
  say ipv4_state_age_s "${2:-?}"
  [ "${1:-}" = full ] && [ "${2:-9999}" -le 90 ] 2>/dev/null || OK=0
else
  say ipv4_state missing; OK=0
fi

# IPv6 is DNS-level only today; report honestly, do not fail the IPv4 verdict.
if [ -f "$CV6" ]; then
  say ipv6_state "$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1])).get("state","?"))' "$CV6" 2>/dev/null)"
else
  say ipv6_state missing
fi
if ip -6 -o addr show scope global 2>/dev/null | grep -q inet6; then
  say ipv6_present yes
  say ipv6_note "DNS/AAAA filtering only; packet-level IPv6 is not enforced"
else
  say ipv6_present no
fi

if [ "$OK" = 1 ]; then say overall full; exit 0; fi
say overall partial
exit 1
