#!/bin/bash
# fb-lan-name.sh — publish the box's DNS names on its own resolver.
#
# mDNS (.local) is invisible to Android and unreliable behind some antivirus
# suites, so the box answers plain DNS names. Every client that uses the box as
# its resolver can reach the panel with no per-device configuration.
#
# dns.hosts is the ONLY source: FTL regenerates /etc/pihole/hosts/custom.list
# from it. Writing custom.list by hand raced that regeneration — the .local
# record flapped every 30 s and FTL logged "Permission denied" as it read a
# half-replaced file. This script never touches custom.list.
#
# Usage: fb-lan-name.sh            # long-running publisher (systemd service)
#        fb-lan-name.sh --once     # publish current IP and exit (firstboot/watchdog)
set -u
NAME_MAIN="${FB_DNS_NAME:-filterbox.lan}"
NAME_ALT="${FB_DNS_ALT:-filterbox}"
NAME_LOCAL="${FB_DNS_LOCAL:-filterbox.local}"
NAMES=("$NAME_MAIN" "$NAME_ALT" "$NAME_LOCAL")
INTERVAL="${FB_DNS_INTERVAL:-30}"

log() { echo "$(date -Is) $*"; }

# Prefer the address of the interface that carries the default route: the first
# global address can belong to a WAN/VPN link that LAN clients cannot reach.
current_ip() {
  local iface ip
  iface=$(ip route show default 2>/dev/null | sed -n 's/.* dev \([^ ]*\).*/\1/p' | head -n1)
  if [ -n "$iface" ]; then
    ip=$(ip -4 -o addr show dev "$iface" scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -n1)
    [ -n "$ip" ] && { printf '%s\n' "$ip"; return 0; }
  fi
  ip -4 -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -n1
}

# Read the authoritative array from pihole.toml. `pihole-FTL --config` prints a
# human-formatted list (`[ 1.2.3.4 name, … ]`), not JSON; parsing the toml keeps
# records the owner added instead of silently dropping them.
read_hosts() {
  python3 - <<'PY'
import json, tomllib
try:
    with open('/etc/pihole/pihole.toml', 'rb') as fh:
        d = tomllib.load(fh)
    hosts = d.get('dns', {}).get('hosts', [])
except Exception:
    hosts = []
print(json.dumps(hosts if isinstance(hosts, list) else []))
PY
}

# 0 = every name is present and points at $1
hosts_ok() {  # ip json
  python3 - "$1" "$2" "${NAMES[@]}" <<'PY'
import json, sys
ip, raw, *names = sys.argv[1:]
try:
    hosts = json.loads(raw or '[]')
except Exception:
    hosts = []
have = {}
for e in hosts:
    parts = e.split()
    if len(parts) >= 2:
        have[parts[-1].lower()] = parts[0]
sys.exit(0 if all(have.get(n.lower()) == ip for n in names) else 1)
PY
}

publish() {  # ip
  local ip="$1" cur new
  cur="$(read_hosts)"
  new="$(python3 - "$cur" "$ip" "${NAMES[@]}" <<'PY'
import json, sys
cur_raw, ip, *names = sys.argv[1:]
try:
    cur = json.loads(cur_raw or '[]')
except Exception:
    cur = []
want = {n.lower() for n in names}
keep = [e for e in cur if e.split() and e.split()[-1].lower() not in want]
print(json.dumps(keep + [f"{ip} {n}" for n in names]))
PY
)" || { log "could not build record list"; return 1; }
  [ "$new" = "$cur" ] && return 0
  pihole-FTL --config dns.hosts "$new" >/dev/null 2>&1 || { log "dns.hosts update failed"; return 1; }
  pihole reloaddns >/dev/null 2>&1 || systemctl reload-or-restart pihole-FTL >/dev/null 2>&1 || true
  log "published ${NAMES[*]} -> $ip"
}

if [ "${1:-}" = "--once" ]; then
  ip="$(current_ip)"
  [ -n "$ip" ] || exit 0
  publish "$ip"
  exit $?
fi

LAST=""
log "LAN name publisher starting (${NAMES[*]})"
while :; do
  ip="$(current_ip)"
  if [ -z "$ip" ]; then
    log "no IPv4 yet — waiting"
  elif [ "$ip" != "$LAST" ] || ! hosts_ok "$ip" "$(read_hosts)"; then
    if publish "$ip"; then LAST="$ip"; fi
  fi
  sleep "$INTERVAL"
done
