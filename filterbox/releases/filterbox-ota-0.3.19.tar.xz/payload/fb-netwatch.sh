#!/bin/bash
# fb-netwatch — watchdog for the box's LAN DNS names.
#
# The publisher (fb-lan-name.service) owns dns.hosts; FTL generates
# /etc/pihole/hosts/custom.list from it. This timer exists only to re-assert the
# records if the publisher missed a change (service restart, DHCP flap), so it
# delegates to the same one-shot path instead of editing custom.list by hand —
# a direct write raced FTL's regeneration and made the .local record flap.
set -u
exec /usr/local/lib/filterbox/fb-lan-name.sh --once
